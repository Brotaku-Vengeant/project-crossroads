PROJECT: CROSSROADS - PRIVATE NETWORK TEST
==========================================

This package contains early, controlled Fallout 3 and KotOR multiplayer tests
for trusted testers. Fallout 3 and KotOR servers support up to four players.
KotOR remote-actor rendering is still being expanded beyond its first slot.
Neither is a public server release,
and gameplay synchronization is still incomplete.

REQUIREMENTS
------------
- Windows and the Steam Fallout 3: Game of the Year Edition.
- Your own game patched to Fallout3.exe version 1.7.0.3 with the Fallout
  Anniversary Patcher.
- FOSE 1.2 beta 2 installed beside Fallout3.exe.
- The same Crossroads ZIP version for every player.
- Internet access to the configured Crossroads update channel.
- Adult characters saved in the same outdoor area.
- For the KotOR test: the English Steam release of KotOR 1 and a save in
  Taris - Upper City North (tar_m02ab).

Crossroads does not include or redistribute Fallout 3, FOSE, or the Anniversary
Patcher. Obtain those separately from their original project pages.

FOSE AND 4 GB PATCHERS
----------------------
- Yes, this test currently requires FOSE 1.2 beta 2. The setup checks for
  fose_loader.exe and fose_1_7.dll and copies them into Crossroads' isolated
  runtime.
- Crossroads currently supports the exact Fallout 3 1.7.0.3 executable produced
  by the Fallout Anniversary Patcher. The launcher validates that executable
  before starting a private session.
- Do not apply an additional or arbitrary 4 GB / Large Address Aware patcher to
  the Crossroads runtime. Other executable modifications are not validated or
  supported by this tester and may be rejected by the compatibility check.
- If your normal installation uses another executable patcher, keep a clean
  Anniversary Patcher 1.7.0.3 Fallout3.exe available for Crossroads setup.

UNIFIED LAUNCHER
----------------
- ProjectCrossroadsLauncher.exe opens the shared Crossroads Landing Pad.
- Select Fallout 3, then choose "Open Fallout Tools" for the validated
  diagnostics, private server, and join controls described below.
- The KotOR tab contains its live two-player test server and Join button.
- Other game tabs are visible for readiness and development tracking.
- Network Beacon latency is shown only when the package contains a real MMN
  beacon address and that service replies. Game server rows appear only while
  their corresponding server answers a live status check.

FIRST-TIME SETUP
----------------
1. Extract the entire ZIP to a normal folder. Do not run it inside the ZIP.
2. Open "ProjectCrossroadsLauncher.exe" and accept the initial Crossroads
   update. The small bootstrap package downloads and verifies the complete
   current tester components automatically.
3. After the update reopens the launcher, KotOR-only testers can select KotOR
   and use the online server row.
4. Fallout 3 testers double-click "Prepare Crossroads Test.cmd".
5. Confirm the detected Fallout 3 folder, or choose No and browse to a custom
   installation folder containing Fallout3.exe and the Data folder.
6. When setup succeeds, open "ProjectCrossroadsLauncher.exe".
7. Select Fallout 3 and click "Open Fallout Tools".
8. Click "Network Self-Test". Do not continue unless it passes.

AUTOMATIC UPDATES
-----------------
- This bootstrap package is the last package testers should normally need to
  install manually.
- Each time ProjectCrossroadsLauncher.exe starts, it checks the configured
  Crossroads update channel before opening the launcher.
- Updates are downloaded only over HTTPS and must pass their published SHA-256
  integrity check. If verification or installation fails, the installed build
  is left unchanged.
- Updates replace only Crossroads-owned program files. The isolated Fallout
  runtime, selected installation path, logs, room code, and tester settings are
  preserved.
- Close Fallout and the dedicated server before installing an offered update.

The setup copies required files from your own Fallout installation into this
package's isolated runtime and links its Data folder to your selected installed
Data folder. A custom installation path is supported and does not need to match
the old Bethesda registry entry.

STARTING THE SERVER
-------------------
1. Leave the managed UDP port at its default unless the test coordinator says
   otherwise.
2. Click "Launch Dedicated Server". A separate server console appears.
3. Leave that console open. It does not launch or require Fallout.
4. Return to the shared Crossroads launcher. The official Fallout server
   appears in the browser after it answers the live status check.
5. Make sure UDP, not TCP, on that port is forwarded to the server PC.

The official test route and room are managed by Crossroads updates. Testers do
not type or exchange either value.

The person running the server is not automatically a player and does not use a
player slot. After launching the server, Crossroads automatically switches that
launcher to the local route so the server owner can click "Join Private
Session" exactly like another player.

JOINING
-------
1. Open the shared Crossroads launcher and select Fallout 3.
2. Select the online official test server and click "Join Test Server".
   Crossroads passes the managed route into the Fallout adapter and launches
   Fallout automatically.
3. Load an adult save in the same area. Snapshot streaming begins as soon as
   the loaded player becomes available; no tabbing or confirmation is needed.

CONTROLS
--------
- F10: save a Crossroads screenshot.

Close Fallout normally to disconnect. Crossroads remains connected through the
main menu and loading screens and cleans up automatically when the game exits.

CURRENT LIMITS
--------------
- Fallout 3: four active players maximum, including the host.
- KotOR: four active clients maximum. Players must load Taris - Upper City
  North. A player can join and launch KotOR immediately; Crossroads continues
  waiting in the background and prepares the remote actor whenever the second
  player connects.
- KotOR displays live Crossroads connection state and the current player count
  in the game window's title bar, including while the main menu is open.
- Close KotOR without saving when its movement test ends. Crossroads then
  restores the temporary test files it installed.
- If the KotOR client encounters an error, its window remains open and writes
  details to kotor-client-log.txt beside the launcher.
- Trusted private testing only. Admission is room-code authenticated, but
  gameplay traffic is not encrypted.
- Position, facing, basic motion, actor creation, and cleanup are the present
  focus. Quests, combat, inventory, doors, cells, NPCs, and full animation
  synchronization are not complete.
- Windows Firewall may ask for permission. Allow the launcher only on the
  network type you intend to use.

TROUBLESHOOTING
---------------
If something fails, close Fallout and Crossroads, then send the host:
- startup-log.txt
- diagnostic-report.txt
- A screenshot of the error

Do not distribute modified Crossroads network configuration files.
