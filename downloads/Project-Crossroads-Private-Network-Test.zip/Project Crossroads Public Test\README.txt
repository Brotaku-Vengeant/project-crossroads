PROJECT: CROSSROADS - PRIVATE NETWORK TEST
==========================================

This is an early, controlled Fallout 3 multiplayer test for trusted testers.
It supports one host and up to three joining players. It is not a public server
release, and gameplay synchronization is still incomplete.

REQUIREMENTS
------------
- Windows and the Steam Fallout 3: Game of the Year Edition.
- Your own game patched to Fallout3.exe version 1.7.0.3 with the Fallout
  Anniversary Patcher.
- FOSE 1.2 beta 2 installed beside Fallout3.exe.
- The same Crossroads ZIP version for every player.
- Internet access to the configured Crossroads update channel.
- Adult characters saved in the same outdoor area.

Crossroads does not include or redistribute Fallout 3, FOSE, or the Anniversary
Patcher. Obtain those separately from their original project pages.

FOSE AND 4 GB PATCHERS
----------------------
- Yes, this test currently requires FOSE 1.2 beta 2. The setup checks for
  fose_loader.exe and fose_1_7.dll and copies them into Crossroads' isolated
  runtime.
- Crossroads currently supports the exact Fallout 3 1.7.0.3 executable produced
  by the Fallout Anniversary Patcher. The launcher validates that executable
  before starting a private session.
- Do not apply an additional or arbitrary 4 GB / Large Address Aware patcher to
  the Crossroads runtime. Other executable modifications are not validated or
  supported by this tester and may be rejected by the compatibility check.
- If your normal installation uses another executable patcher, keep a clean
  Anniversary Patcher 1.7.0.3 Fallout3.exe available for Crossroads setup.

FIRST-TIME SETUP
----------------
1. Extract the entire ZIP to a normal folder. Do not run it inside the ZIP.
2. Double-click "Prepare Crossroads Test.cmd".
3. Confirm the detected Fallout 3 folder, or choose No and browse to a custom
   installation folder containing Fallout3.exe and the Data folder.
4. When setup succeeds, open "ProjectCrossroadsLauncher.exe".
5. Click "Network Self-Test". Do not continue unless it passes.

AUTOMATIC UPDATES
-----------------
- This bootstrap package is the last package testers should normally need to
  install manually.
- Each time ProjectCrossroadsLauncher.exe starts, it checks the configured
  Crossroads update channel before opening the launcher.
- Updates are downloaded only over HTTPS and must pass their published SHA-256
  integrity check. If verification or installation fails, the installed build
  is left unchanged.
- Updates replace only Crossroads-owned program files. The isolated Fallout
  runtime, selected installation path, logs, room code, and tester settings are
  preserved.
- Close Fallout and the dedicated server before installing an offered update.

The setup copies required files from your own Fallout installation into this
package's isolated runtime and links its Data folder to your selected installed
Data folder. A custom installation path is supported and does not need to match
the old Bethesda registry entry.

STARTING THE SERVER
-------------------
1. Leave Server IPv4 as 127.0.0.1. Set the UDP port (default: 1500).
2. Click "Launch Dedicated Server". A separate server console appears.
3. Leave that console open. It does not launch or require Fallout.
4. Share your public IPv4 address, port, and displayed room code privately.
5. Make sure UDP, not TCP, on that port is forwarded to the server PC.

The launcher remembers its room code in network-room-code.txt so reopening it
does not silently create a different room from the running server.

The person running the server is not automatically a player and does not use a
player slot. If the server owner wants to play, they join through the launcher
using 127.0.0.1, exactly like another player.

JOINING
-------
1. Enter the host's public IPv4 address, UDP port, and exact room code.
2. Click "Join Private Session". Crossroads launches Fallout and authenticates
   automatically during startup.
3. Load an adult save in the same area. Snapshot streaming begins as soon as
   the loaded player becomes available; no tabbing or confirmation is needed.

CONTROLS
--------
- F10: save a Crossroads screenshot.

Close Fallout normally to disconnect. Crossroads remains connected through the
main menu and loading screens and cleans up automatically when the game exits.

CURRENT LIMITS
--------------
- Four active players maximum, including the host.
- Trusted private testing only. Admission is room-code authenticated, but
  gameplay traffic is not encrypted.
- Position, facing, basic motion, actor creation, and cleanup are the present
  focus. Quests, combat, inventory, doors, cells, NPCs, and full animation
  synchronization are not complete.
- Windows Firewall may ask for permission. Allow the launcher only on the
  network type you intend to use.

TROUBLESHOOTING
---------------
If something fails, close Fallout and Crossroads, then send the host:
- startup-log.txt
- diagnostic-report.txt
- A screenshot of the error

Do not publish the room code or your public IP in an open channel.
