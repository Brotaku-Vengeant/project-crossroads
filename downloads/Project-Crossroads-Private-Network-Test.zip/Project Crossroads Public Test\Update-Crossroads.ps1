[CmdletBinding()]
param(
    [int]$ParentProcessId = 0,
    [switch]$AfterUpdateCheck,
    [switch]$AcceptUpdate,
    [switch]$NoLaunch,

    # Install ONE component instead of the whole package (D33).
    #
    # Empty is the legacy behaviour and stays the default: the whole managed set,
    # checked at launcher start, exactly as before. Every launcher already in the
    # field invokes this script with no -Component and must keep working
    # unchanged -- this script is the only thing that could repair a client it
    # broke, so it must never be what breaks one.
    #
    # A value names a component in the manifest's `games` map (or 'platform').
    # The launcher passes it when the player presses Join, before the join is
    # allowed.
    [string]$Component = '',

    # REPAIR A DAMAGED INSTALL, rather than move it to a newer build.
    #
    # WHY THIS EXISTS. Until 2026-08-14 this script could only ever compare build
    # NUMBERS, so an install at the current build was declared "current" and left
    # alone no matter what was actually on disk. That day a deletion removed
    # `Sign-InToCrossroads.ps1` from an install sitting at 202608132209; the
    # launcher refused to sign in, its dialog said "Run the updater", the updater
    # logged `Build 202608132209 is current` and did nothing. The only way out
    # was hand-editing crossroads-build.txt, which no tester will ever guess.
    #
    # WHAT IT CHANGES, AND IT IS DELIBERATELY ONE THING: whether the run proceeds
    # when the version says there is nothing to do. Everything that makes an
    # install safe still happens exactly as before -- the archive's SHA-256, each
    # payload file's own SHA-256, path confinement, the cross-component ownership
    # check, the process-hold refusal, and the transactional rollback. Repair
    # changes the decision to proceed, never the safety of proceeding.
    #
    # It then compares what is ON DISK against the payload's per-file hashes and
    # rewrites ONLY the files that are missing or wrong. A healthy install is
    # reported as healthy and not touched -- notably crossroads-network.ini is a
    # managed platform file, and a repair that rewrote a server owner's edited
    # config to "fix" it would be doing harm in the name of help.
    [switch]$Repair
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$launcher = Join-Path $root 'ProjectCrossroadsLauncher.exe'
$channelPath = Join-Path $root 'update-channel.json'
$installedBuildPath = Join-Path $root 'crossroads-build.txt'
$logPath = Join-Path $root 'updater-log.txt'

Add-Type -AssemblyName PresentationFramework

function Write-UpdaterLog([string]$message) {
    $line = '{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $message
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

function Show-UpdateError([string]$message) {
    [System.Windows.MessageBox]::Show(
        $message,
        'Project: Crossroads - Updater',
        'OK',
        'Error') | Out-Null
}

function Start-Launcher {
    if ($NoLaunch) {
        return
    }
    if (Test-Path -LiteralPath $launcher -PathType Leaf) {
        Start-Process -FilePath $launcher -ArgumentList '--after-update-check' `
            -WorkingDirectory $root
    }
}

function Read-BuildNumber([string]$path) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return [Int64]0
    }
    $value = (Get-Content -LiteralPath $path -Raw).Trim()
    $parsed = [Int64]0
    if (-not [Int64]::TryParse($value, [ref]$parsed) -or $parsed -lt 0) {
        return [Int64]0
    }
    return $parsed
}

function Resolve-UpdateSource([string]$source, [string]$baseSource) {
    if ([IO.Path]::IsPathRooted($source)) {
        return [IO.Path]::GetFullPath($source)
    }
    $absolute = $null
    if ([Uri]::TryCreate($source, [UriKind]::Absolute, [ref]$absolute)) {
        return $absolute.AbsoluteUri
    }
    $baseUri = $null
    if ([Uri]::TryCreate($baseSource, [UriKind]::Absolute, [ref]$baseUri) -and
        $baseUri.Scheme -in @('http', 'https', 'file')) {
        return ([Uri]::new($baseUri, $source)).AbsoluteUri
    }
    return [IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $baseSource) $source))
}

# Where the launcher looks to find out what is happening. One line, rewritten.
#
# The launcher spawns this script with CREATE_NO_WINDOW and waits, so until now
# a player installing 34.8 MB saw an unchanging window and no indication that
# anything was happening at all -- register item 8.
$progressPath = Join-Path $root 'update-progress.txt'

function Write-UpdateProgress([string]$stage, [long]$done = -1, [long]$total = -1) {
    # Best effort by design. Progress reporting must never be able to fail an
    # update: this is the component that installs executables on other people's
    # machines, and a locked status file is not a reason to abandon an install
    # that is otherwise fine.
    try {
        $line = $stage
        if ($done -ge 0 -and $total -gt 0) {
            $line = '{0}|{1}|{2}' -f $stage, $done, $total
        }
        elseif ($done -ge 0) {
            $line = '{0}|{1}|0' -f $stage, $done
        }
        [IO.File]::WriteAllText($progressPath, $line)
    }
    catch { }
}

# WHAT -TimeoutSec 20 ACTUALLY BOUNDED, measured 2026-08-10 rather than assumed.
#
# Register item 9 said a 20-second timeout applied to the 34.8 MB component
# download. It did not. Two measurements against a local server:
#
#   a body trickled over 34.6 seconds  -> COMPLETED, all bytes written
#   a 40-second stall mid-body         -> COMPLETED, no error
#
# Invoke-WebRequest's -TimeoutSec maps to the time to get a response, not to the
# transfer. So raising it would have changed nothing while looking like a fix,
# and the real defect is the opposite of the one recorded: there was NO bound on
# the body at all. A server that accepted the connection and then went quiet
# hung the updater forever -- with the launcher waiting behind it showing
# nothing, which is item 8 making item 9 invisible.
#
# HttpWebRequest is used directly because it exposes ReadWriteTimeout, which is
# the idle bound that was missing, and because streaming the body is what makes
# progress reporting and resume possible at all. All three register items are
# the same piece of code.
function Get-UpdateFileStreamed([Uri]$uri, [string]$destination, [string]$label,
                                [int]$idleTimeoutMs = 30000,
                                [int]$maximumAttempts = 4) {
    # The two bounds are PARAMETERS with production defaults so the gate can
    # drive them short. Proving that an idle connection is now bounded requires
    # waiting out the bound, and a gate that takes two minutes to say so is a
    # gate people start skipping.
    $partial = $destination + '.part'
    $attempt = 0

    while ($true) {
        $attempt++
        # RESUME (item 10). A failed download used to restart at zero, which on
        # a poor connection is how an update never finishes at all. Whatever
        # arrived last time is offered back to the server as a Range request; a
        # server that ignores Range answers 200 and the file simply starts over,
        # which is the old behaviour rather than a broken one.
        $existing = 0L
        if (Test-Path -LiteralPath $partial -PathType Leaf) {
            $existing = (Get-Item -LiteralPath $partial).Length
        }

        $request = [Net.HttpWebRequest]::Create($uri)
        $request.Method = 'GET'
        $request.Timeout = 20000                  # to the response, as before
        $request.ReadWriteTimeout = $idleTimeoutMs # THE BOUND THAT WAS MISSING
        $request.AllowAutoRedirect = $true
        $request.UserAgent = 'CrossroadsUpdater/1'
        if ($existing -gt 0) {
            $request.AddRange([long]$existing)
        }

        $response = $null
        $responseStream = $null
        $fileStream = $null
        try {
            $response = $request.GetResponse()
            $resuming = ($response.StatusCode -eq [Net.HttpStatusCode]::PartialContent)
            if (-not $resuming) { $existing = 0L }

            $total = $response.ContentLength
            if ($total -ge 0) { $total += $existing }

            $mode = if ($resuming) { [IO.FileMode]::Append } else { [IO.FileMode]::Create }
            $responseStream = $response.GetResponseStream()
            $fileStream = New-Object IO.FileStream($partial, $mode,
                [IO.FileAccess]::Write, [IO.FileShare]::Read)

            $buffer = New-Object byte[] 131072
            $done = $existing
            $lastReport = [DateTime]::UtcNow.AddSeconds(-1)
            Write-UpdateProgress $label $done $total
            while ($true) {
                $read = $responseStream.Read($buffer, 0, $buffer.Length)
                if ($read -le 0) { break }
                $fileStream.Write($buffer, 0, $read)
                $done += $read
                # Rate-limited so a fast local copy does not spend its time
                # writing status lines.
                if (([DateTime]::UtcNow - $lastReport).TotalMilliseconds -ge 250) {
                    Write-UpdateProgress $label $done $total
                    $lastReport = [DateTime]::UtcNow
                }
            }
            $fileStream.Close(); $fileStream = $null
            $responseStream.Close(); $responseStream = $null
            $response.Close(); $response = $null

            if ($total -gt 0 -and $done -ne $total) {
                throw "Transfer ended early: $done of $total bytes."
            }
            Write-UpdateProgress $label $done $total
            Move-Item -LiteralPath $partial -Destination $destination -Force
            return
        }
        catch {
            if ($null -ne $fileStream) { try { $fileStream.Close() } catch { } }
            if ($null -ne $responseStream) { try { $responseStream.Close() } catch { } }
            if ($null -ne $response) { try { $response.Close() } catch { } }
            if ($attempt -ge $maximumAttempts) {
                # The PARTIAL FILE IS KEPT. It is the whole value of resume, and
                # the next run offers it back to the server. It is never handed
                # to the installer -- only the completed file is moved into
                # place -- so a truncated download cannot be mistaken for an
                # artifact.
                Write-UpdateProgress 'failed'
                throw ("Download failed after $attempt attempt(s): " +
                       $_.Exception.Message)
            }
            Write-UpdateProgress ('retrying ' + $label)
            Start-Sleep -Seconds ([Math]::Min(8, [Math]::Pow(2, $attempt)))
        }
    }
}

function Copy-UpdateSource([string]$source, [string]$destination,
                           [string]$label = 'downloading') {
    if (Test-Path -LiteralPath $source -PathType Leaf) {
        Copy-Item -LiteralPath $source -Destination $destination -Force
        return
    }
    $uri = $null
    if ([Uri]::TryCreate($source, [UriKind]::Absolute, [ref]$uri)) {
        if ($uri.Scheme -eq 'https') {
            Get-UpdateFileStreamed $uri $destination $label
            return
        }
        if ($uri.Scheme -eq 'file') {
            Copy-Item -LiteralPath $uri.LocalPath -Destination $destination -Force
            return
        }
        throw 'The update source must use HTTPS.'
    }
    Copy-Item -LiteralPath ([IO.Path]::GetFullPath($source)) `
        -Destination $destination -Force
}

function Test-SafeRelativePath([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path) -or
        [IO.Path]::IsPathRooted($path) -or
        $path.Contains('..') -or
        $path.Contains(':')) {
        return $false
    }
    $normalized = $path.Replace('/', '\').TrimStart('\')
    return -not ($normalized -ieq 'runtime' -or
        $normalized.StartsWith('runtime\', [StringComparison]::OrdinalIgnoreCase) -or
        $normalized -ieq 'startup-log.txt' -or
        $normalized -ieq 'diagnostic-report.txt' -or
        # network-room-code.txt was here until 2026-08-15. It held a Fallout
        # join code written by the retired safe launcher; join codes are gone
        # and nothing writes the file any more.
        $normalized -ieq 'updater-log.txt')
}

# ---- per-component install records (D33) ------------------------------------
#
# ONE FILE PER COMPONENT, recording the build AND the exact files it owns.
#
# The build is what the launcher's Join gate compares against the manifest. The
# file list is what makes ownership knowable locally, which is what lets an
# install refuse to touch a file another component owns -- and what will let an
# uninstall remove exactly what a game put there, rather than guessing from a
# path prefix (Fallout's files are not under a components\fallout3\ prefix at
# all).
#
# Deliberately ONE file rather than a build stamp plus a separate manifest. Two
# pieces of state describing the same thing is how they come to disagree, and a
# disagreement here is invisible until an uninstall removes the wrong file.
$componentStateRoot = Join-Path $root '.crossroads-components'

function Get-ComponentStatePath([string]$id) {
    return Join-Path $componentStateRoot ($id + '.json')
}

function Read-ComponentState([string]$id) {
    $path = Get-ComponentStatePath $id
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return $null
    }
    try {
        return Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    }
    catch {
        # An unreadable record must not be treated as "nothing installed": that
        # would reinstall over files whose ownership we can no longer prove.
        throw "The installed-component record for '$id' is unreadable: $path"
    }
}

function Get-ComponentInstalledBuild([string]$id) {
    $state = Read-ComponentState $id
    if ($null -eq $state) { return [Int64]0 }
    $parsed = [Int64]0
    if (-not [Int64]::TryParse([string]$state.build, [ref]$parsed)) { return [Int64]0 }
    return $parsed
}

# Which OTHER component already owns a path, or '' if nobody does.
function Get-ConflictingOwner([string]$relative, [string]$exceptId) {
    if (-not (Test-Path -LiteralPath $componentStateRoot)) { return '' }
    $needle = $relative.Replace('\', '/').ToLowerInvariant()
    foreach ($file in (Get-ChildItem -LiteralPath $componentStateRoot -Filter '*.json' -ErrorAction SilentlyContinue)) {
        $otherId = [IO.Path]::GetFileNameWithoutExtension($file.Name)
        if ($otherId -ieq $exceptId) { continue }
        $state = Read-ComponentState $otherId
        if ($null -eq $state) { continue }
        foreach ($owned in @($state.files)) {
            if (([string]$owned).Replace('\', '/').ToLowerInvariant() -eq $needle) {
                return $otherId
            }
        }
    }
    return ''
}

if ($ParentProcessId -gt 0) {
    $deadline = [DateTime]::UtcNow.AddSeconds(15)
    while ((Get-Process -Id $ParentProcessId -ErrorAction SilentlyContinue) -and
        [DateTime]::UtcNow -lt $deadline) {
        Start-Sleep -Milliseconds 100
    }
    if (Get-Process -Id $ParentProcessId -ErrorAction SilentlyContinue) {
        Write-UpdaterLog 'The launcher did not exit in time; the update check was skipped.'
        Start-Launcher
        exit 0
    }
}

# ---- -Repair with no component named: repair everything installed -----------
#
# A damaged install does not announce WHICH piece is damaged, so a repair that
# only covered the platform would leave a broken game component unrepairable --
# which is most of the point of having the command.
#
# RE-INVOKED PER COMPONENT RATHER THAN LOOPED INLINE. Everything below this
# block is written for exactly one manifest entry, and this is the highest
# consequence script in the project. Dispatching keeps that proven single
# component path byte for byte and makes repair-all a thin wrapper over it,
# instead of restructuring an installer to gain a loop.
#
# -AcceptUpdate IS DELIBERATELY NOT PASSED. In this script that switch also
# suppresses the process-hold refusal, so passing it would let a repair
# overwrite a file a running process holds open -- the one thing the hold check
# exists to prevent. A component install already skips the prompt without it.
if ($Repair -and $Component -eq '') {
    $targets = New-Object System.Collections.Generic.List[string]
    # Platform first: it carries the launcher, the updater itself, and the
    # sign-in script, so it is both the most likely thing to be broken and the
    # thing a later component repair depends on.
    $targets.Add('platform')
    if (Test-Path -LiteralPath $componentStateRoot) {
        foreach ($file in (Get-ChildItem -LiteralPath $componentStateRoot -Filter '*.json' -ErrorAction SilentlyContinue |
                Sort-Object Name)) {
            $id = [IO.Path]::GetFileNameWithoutExtension($file.Name)
            if ($id -ieq 'platform') { continue }
            $targets.Add($id)
        }
    }

    Write-UpdaterLog ("Repair requested for: " + ($targets -join ', '))
    $powershellPath = (Get-Process -Id $PID).Path
    $worst = 0
    foreach ($id in $targets) {
        Write-Host ("Repairing '$id'...")
        & $powershellPath -NoLogo -NonInteractive -NoProfile -ExecutionPolicy Bypass `
            -File $PSCommandPath -Repair -Component $id -NoLaunch
        $code = $LASTEXITCODE
        # The worst outcome wins, but every target is still attempted: one
        # component refusing to downgrade is not a reason to leave the others
        # damaged.
        if ($code -gt $worst) { $worst = $code }
    }
    Write-UpdaterLog ("Repair finished for " + $targets.Count + " component(s), worst exit $worst.")
    exit $worst
}

if (-not (Test-Path -LiteralPath $channelPath -PathType Leaf)) {
    Start-Launcher
    exit 0
}

try {
    $channel = Get-Content -LiteralPath $channelPath -Raw | ConvertFrom-Json
    $manifestSource = [string]$channel.manifestUrl
    if ([string]::IsNullOrWhiteSpace($manifestSource) -or
        $manifestSource -eq 'UPDATE_SOURCE_NOT_CONFIGURED') {
        Write-UpdaterLog 'No update channel is configured; continuing with the installed build.'
        Start-Launcher
        exit 0
    }

    $tempRoot = Join-Path ([IO.Path]::GetTempPath()) `
        ('project-crossroads-update-' + [Guid]::NewGuid().ToString('N'))
    $downloadRoot = Join-Path $tempRoot 'download'
    $extractRoot = Join-Path $tempRoot 'extracted'
    New-Item -ItemType Directory -Force -Path $downloadRoot, $extractRoot | Out-Null

    $manifestPath = Join-Path $downloadRoot 'update-manifest.json'
    Write-UpdateProgress 'checking'
    Copy-UpdateSource $manifestSource $manifestPath 'checking'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json

    # WHICH ENTRY THIS RUN INSTALLS. Without -Component this is the top-level
    # manifest, unchanged, which is what every launcher in the field reads.
    $entry = $manifest
    if ($Component -ne '') {
        $entry = if ($Component -ieq 'platform') {
            $manifest.platform
        }
        elseif ($null -ne $manifest.games) {
            $manifest.games.$Component
        }
        else {
            $null
        }
        if ($null -eq $entry) {
            # A manifest that predates the split has no `games`. Say so plainly
            # rather than failing on a null property later, because the launcher
            # will surface this to a player who pressed Join.
            throw ("The update manifest has no component named '$Component'. " +
                   'It may predate per-game updates, or this game may not ' +
                   'publish a component.')
        }
    }

    $installedBuild = if ($Component -ne '') {
        Get-ComponentInstalledBuild $Component
    } else {
        Read-BuildNumber $installedBuildPath
    }
    $availableBuild = [Int64]$entry.build
    $what = if ($Component -ne '') { "Component '$Component'" } else { 'Build' }

    # A REPAIR RESTORES FILES; IT NEVER MOVES A VERSION. The three cases are kept
    # apart deliberately, because conflating them is how a repair would leave an
    # install whose files and whose recorded build disagree -- which is worse
    # than the damage it was asked to fix.
    #
    #   published < installed -> REFUSED. Silently replacing someone's files
    #     with older ones is a downgrade wearing the word "repair".
    #   published = installed -> pure repair. Restore damaged files, write no
    #     version state, because the version did not change.
    #   published > installed -> this is an ordinary update and is handled as
    #     one, version record and all. Asking to repair an install that is
    #     simply out of date should bring it up to date rather than refuse.
    $isPureRepair = $false
    if ($Repair) {
        if ($availableBuild -lt $installedBuild) {
            Write-UpdaterLog ("$what REFUSED: installed build $installedBuild is newer " +
                "than the published $availableBuild. Repair will not downgrade.")
            Write-Host ("Refusing to repair '$Component': the installed build " +
                "$installedBuild is NEWER than the published $availableBuild." ) -ForegroundColor Yellow
            Write-Host 'Repairing would replace your files with older ones. Nothing was changed.'
            Remove-Item -LiteralPath $tempRoot -Recurse -Force
            exit 4
        }
        $isPureRepair = ($availableBuild -eq $installedBuild)
    }

    if ($availableBuild -le $installedBuild -and -not $Repair) {
        Write-UpdaterLog "$what $installedBuild is current."
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
        # A component check is invoked by the launcher and must not relaunch it.
        if ($Component -eq '') { Start-Launcher }
        exit 0
    }

    # The launcher owns the Join-time prompt, so a component install never puts
    # up its own dialog on top of it.
    $choice = if ($AcceptUpdate -or $Component -ne '') {
        'Yes'
    }
    else {
        [System.Windows.MessageBox]::Show(
            "A Project: Crossroads update is available.`n`nInstalled build: $installedBuild`nAvailable build: $availableBuild`n`nInstall it now?",
            'Project: Crossroads - Update Available',
            'YesNo',
            'Information')
    }
    if ($choice -ne 'Yes') {
        Write-UpdaterLog "Build $availableBuild was declined."
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
        Start-Launcher
        exit 0
    }

    $archiveSource = Resolve-UpdateSource ([string]$entry.packageUrl) $manifestSource
    $archivePath = Join-Path $downloadRoot 'Project-Crossroads-Update.zip'
    Copy-UpdateSource $archiveSource $archivePath 'downloading'
    Write-UpdateProgress 'verifying'
    $actualHash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash
    if ($actualHash -ine [string]$entry.sha256) {
        # The partial file is deliberately NOT resumed past this point: a hash
        # mismatch means the bytes are wrong, and resuming would append to
        # something already known to be bad.
        Remove-Item -LiteralPath ($archivePath + '.part') -Force -ErrorAction SilentlyContinue
        Write-UpdateProgress 'failed'
        throw 'The downloaded update failed its SHA-256 integrity check. Nothing was installed.'
    }
    Write-UpdateProgress 'installing'

    Expand-Archive -LiteralPath $archivePath -DestinationPath $extractRoot -Force
    $payloadRoot = Join-Path $extractRoot 'Project Crossroads Update'
    $payloadManifestPath = Join-Path $payloadRoot 'managed-files.json'
    if (-not (Test-Path -LiteralPath $payloadManifestPath -PathType Leaf)) {
        throw 'The downloaded update does not contain its managed-file manifest.'
    }
    $managed = Get-Content -LiteralPath $payloadManifestPath -Raw | ConvertFrom-Json
    if ([Int64]$managed.build -ne $availableBuild) {
        throw 'The update package build number does not match the published manifest.'
    }

    # THE PACKAGE MUST BE THE COMPONENT WE ASKED FOR. Same shape as the build
    # cross-check above, and for the same reason: a manifest and its payload
    # disagreeing is precisely how the wrong artifact ships. Without this, a
    # `games.kotor1` entry pointing at the fallout3 archive would install it
    # under KotOR's name and record KotOR's ownership over Fallout's files.
    if ($Component -ne '') {
        $declared = [string]$managed.component
        if ($declared -ine $Component) {
            throw ("The downloaded package declares component " +
                   "'$declared' but '$Component' was requested. Nothing was installed.")
        }
    }

    $files = @($managed.files)
    if ($files.Count -eq 0) {
        throw 'The update package contains no managed files.'
    }
    foreach ($fileEntry in $files) {
        $relative = [string]$fileEntry.path
        if (-not (Test-SafeRelativePath $relative)) {
            throw "The update contains an unsafe or protected path: $relative"
        }
        # CONFINEMENT, CLIENT SIDE (D33). The packager enforces the same rule at
        # publish time; both are needed, because the publisher's check cannot
        # protect against a tampered manifest and the client's cannot stop a bad
        # package being published. A game component overwriting the launcher, or
        # another game's files, is the failure this prevents -- and it would be
        # silent, because every file would still pass its own hash check.
        if ($Component -ne '') {
            $owner = Get-ConflictingOwner $relative $Component
            if ($owner -ne '') {
                throw ("Component '$Component' declares a file already owned by " +
                       "'$owner': $relative. Nothing was installed.")
            }
        }
        $sourceFile = Join-Path $payloadRoot $relative
        if (-not (Test-Path -LiteralPath $sourceFile -PathType Leaf)) {
            throw "The update is missing a declared file: $relative"
        }
        $fileHash = (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256).Hash
        if ($fileHash -ine [string]$fileEntry.sha256) {
            throw "The update file failed verification: $relative"
        }
    }

    # WHAT THIS RUN WILL WRITE. An ordinary update writes every declared file; a
    # pure repair writes only the ones that are actually damaged.
    $filesToInstall = $files
    if ($isPureRepair) {
        # THE HASHES COME FROM THE PUBLISHED ARTIFACT, NOT FROM LOCAL STATE.
        # The per-component records on disk list paths but no hashes, and the
        # platform's record is a bare build number with no file list at all -- so
        # a machine cannot answer "is my install intact" from anything it already
        # holds. The payload's managed-files.json can, and it arrived under the
        # archive's own verified SHA-256, which makes it the one description of a
        # correct install that damage on this disk cannot have altered.
        # A PLAIN ARRAY, not a generic List. `@($list)` on a
        # List[object] throws "Argument types do not match" under PowerShell 5.1,
        # and it does so at the ASSIGNMENT, which reads like a type error in the
        # variable rather than in the conversion. Found by this file's own gate.
        $damaged = @()
        foreach ($fileEntry in $files) {
            $relative = ([string]$fileEntry.path).Replace('/', '\')
            $targetFile = Join-Path $root $relative
            if (-not (Test-Path -LiteralPath $targetFile -PathType Leaf)) {
                Write-UpdaterLog "Repair: MISSING $relative"
                Write-Host ("  missing : " + $relative) -ForegroundColor Yellow
                $damaged += $fileEntry
                continue
            }
            $installedHash = (Get-FileHash -LiteralPath $targetFile -Algorithm SHA256).Hash
            if ($installedHash -ine [string]$fileEntry.sha256) {
                Write-UpdaterLog "Repair: DAMAGED $relative"
                Write-Host ("  damaged : " + $relative) -ForegroundColor Yellow
                $damaged += $fileEntry
            }
        }

        if ($damaged.Count -eq 0) {
            # SAYS SO RATHER THAN SAYING NOTHING. "Nothing to do" and "I did not
            # look" are the same silence, and telling them apart is the reason
            # this command exists at all.
            Write-UpdaterLog ("$what $installedBuild verified: all $($files.Count) " +
                'files match the published build. Nothing to repair.')
            Write-Host ("$what $installedBuild is healthy - all $($files.Count) files verified.") `
                -ForegroundColor Green
            Remove-Item -LiteralPath $tempRoot -Recurse -Force
            exit 0
        }

        # A repair rewrites ONLY what is broken. crossroads-network.ini is a
        # managed platform file, so restoring every declared file would quietly
        # revert a server owner's edited config in the name of fixing it.
        $filesToInstall = $damaged
        Write-UpdaterLog ("Repair: $($damaged.Count) of $($files.Count) files need restoring.")
        Write-Host ("Restoring $($damaged.Count) of $($files.Count) files...")
    }

    # BLOCK ON WHAT THIS UPDATE ACTUALLY TOUCHES, NOT ON EVERYTHING.
    #
    # This used to refuse whenever ANY of six processes was running, whatever
    # the update contained. That is wrong for the person who matters most: the
    # HOST runs CrossroadsKotorServer permanently, so once components split per
    # game (D33) they could never take a kotor1 component update without
    # stopping the server everyone else is connected to -- and the relay's
    # executable is a PLATFORM file that a kotor1 component update does not
    # write. Measured 2026-08-09: the owner pressed Join, the component update
    # was refused for a process holding nothing it would touch, and before the
    # UI-thread fix that refusal took the launcher down with it.
    #
    # The rule is now per file. A process blocks an update only if the update
    # DECLARES a path that process holds open. Two justifications are preserved
    # deliberately:
    #
    #   FILE LOCKS -- an executable cannot be overwritten while it runs.
    #   SESSION COHERENCE -- swapping components under a live session leaves a
    #     mirror from one build talking to a KSE from another, which does not
    #     error, it just silently does nothing (D27, D29). swkotor and the
    #     mirror therefore still block kotor1's component even though the game
    #     holds only its own COPY of those files.
    #
    # A process not listed here has never been blocked and still is not; this
    # narrows the rule, it does not widen it.
    # THE TABLE ITSELF IS NO LONGER HERE.
    #
    # It named swkotor, Fallout3, fose_loader, binkw32.dll and crs_pulse.ncs --
    # per-game knowledge inside the SHARED updater, against the rule in
    # CLAUDE.md that the core never names a game, and one of the eleven places a
    # new game had to be registered by hand.
    #
    # It now ships beside this script as crossroads-games.json, generated at
    # package time from games\<id>\game.json. This script cannot read those
    # manifests directly: it is a distributed file and runs from the tester's
    # install directory, where no games\ tree exists.
    #
    # A MISSING FILE BLOCKS NOTHING, DELIBERATELY. This weakens the check on
    # installs that predate the file, so it is stated plainly rather than buried:
    # every launcher already in the field is one of them. Failing closed would
    # refuse every update for those installs, and this script is the only thing
    # that could deliver the fix -- precisely the unrecoverable state D33's
    # staging exists to avoid.
    #
    # Failing open is safe because this was never the last line of defence. A
    # process that really does hold a declared file open makes the copy fail, and
    # the transaction below rolls the whole install back. What this table buys is
    # a clear message BEFORE that happens, plus the session-coherence refusals
    # that a file lock alone would not catch.
    #
    # Present-but-unreadable is a different situation and throws, matching
    # Read-ComponentState above: a corrupt shipped file means the install is
    # damaged, and saying so beats guessing.
    $processHolds = [ordered]@{}
    $gameDataPath = Join-Path $root 'crossroads-games.json'
    if (Test-Path -LiteralPath $gameDataPath -PathType Leaf) {
        $gameData = $null
        try {
            $gameData = Get-Content -LiteralPath $gameDataPath -Raw | ConvertFrom-Json
        }
        catch {
            throw ("The per-game updater data beside this script is unreadable: " +
                   "$gameDataPath")
        }
        if ([string]$gameData.contract -ne 'crossroads-games-v1') {
            throw ("Unknown per-game updater data contract " +
                   "'$($gameData.contract)' in $gameDataPath.")
        }
        foreach ($game in $gameData.games.PSObject.Properties) {
            foreach ($hold in $game.Value.processHolds.PSObject.Properties) {
                $processHolds[$hold.Name] = @($hold.Value)
            }
        }
    }
    else {
        Write-UpdaterLog ('No crossroads-games.json beside the updater, so no ' +
            'process will block this update. A genuinely locked file still ' +
            'fails its copy and rolls the install back.')
    }
    # $filesToInstall, not $files: a repair that is only restoring one script has
    # no reason to refuse because the relay is running and holds a file it will
    # not touch. That is the same narrowing D33 made when the check went per
    # file, applied one step further.
    $declaredPaths = @{}
    foreach ($fileEntry in $filesToInstall) {
        $declaredPaths[([string]$fileEntry.path).Replace('/', '\').ToLowerInvariant()] = $true
    }
    $blockedBy = @()
    foreach ($processName in $processHolds.Keys) {
        if (-not (Get-Process -Name $processName -ErrorAction SilentlyContinue)) {
            continue
        }
        foreach ($held in $processHolds[$processName]) {
            if ($declaredPaths[$held.ToLowerInvariant()]) {
                $blockedBy += ("$processName (this update replaces $held)")
                break
            }
        }
    }
    if (-not $AcceptUpdate -and $blockedBy.Count -gt 0) {
        throw ("Close these before updating, then try again:`r`n  " +
               ($blockedBy -join "`r`n  "))
    }

    $transactionRoot = Join-Path $root '.crossroads-update-transaction'
    $backupRoot = Join-Path $transactionRoot 'backup'
    if (Test-Path -LiteralPath $transactionRoot) {
        Remove-Item -LiteralPath $transactionRoot -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
    $installed = New-Object System.Collections.Generic.List[string]
    try {
        # $fileEntry, not $entry: $entry is now the manifest entry being
        # installed, and shadowing it here would leave it holding a file record
        # after the loop.
        foreach ($fileEntry in $filesToInstall) {
            $relative = ([string]$fileEntry.path).Replace('/', '\')
            $sourceFile = Join-Path $payloadRoot $relative
            $targetFile = Join-Path $root $relative
            $backupFile = Join-Path $backupRoot $relative
            if (Test-Path -LiteralPath $targetFile -PathType Leaf) {
                New-Item -ItemType Directory -Force `
                    -Path (Split-Path -Parent $backupFile) | Out-Null
                Copy-Item -LiteralPath $targetFile -Destination $backupFile -Force
            }
            New-Item -ItemType Directory -Force `
                -Path (Split-Path -Parent $targetFile) | Out-Null
            Copy-Item -LiteralPath $sourceFile -Destination $targetFile -Force
            $installed.Add($relative)
        }
        if ($isPureRepair) {
            # NO VERSION STATE IS WRITTEN BY A REPAIR, and that is the point of
            # separating the three cases above. The build did not move; only
            # files that had drifted away from it came back. Rewriting a record
            # here could only ever make it disagree with what it already
            # correctly said.
            Write-UpdaterLog ("$what $installedBuild repaired: " +
                "$($filesToInstall.Count) of $($files.Count) files restored.")
            Write-Host ("Repaired $what $installedBuild - " +
                "$($filesToInstall.Count) file(s) restored.") -ForegroundColor Green
        }
        elseif ($Component -ne '') {
            # Written only after every file is in place, so an interrupted
            # install leaves the OLD record standing. A record claiming a build
            # that is only half present would make the Join gate wave through a
            # component that is not actually there.
            New-Item -ItemType Directory -Force -Path $componentStateRoot | Out-Null
            $record = [ordered]@{
                component = $Component
                build = $availableBuild
                files = @($files | ForEach-Object { [string]$_.path })
            }
            [IO.File]::WriteAllText(
                (Get-ComponentStatePath $Component),
                ($record | ConvertTo-Json -Depth 5),
                [Text.UTF8Encoding]::new($false))
            Write-UpdaterLog ("Component '$Component' updated from " +
                "$installedBuild to $availableBuild ($($files.Count) files).")
        }
        else {
            [IO.File]::WriteAllText(
                $installedBuildPath,
                $availableBuild.ToString(),
                [Text.UTF8Encoding]::new($false))
            Write-UpdaterLog "Updated successfully from build $installedBuild to $availableBuild."

            # A PLATFORM UPDATE DOES NOT UPDATE GAME COMPONENTS, AND SAYING
            # NOTHING ABOUT THAT IS HOW A MACHINE SITS ON A STALE BINARY WHILE
            # THE LOG READS "Updated successfully".
            #
            # MEASURED 2026-08-14. A test machine was updated with -NoLaunch,
            # the log said it had moved to the new build, and its kotor1
            # component -- which is where the mirror, the relay client and the
            # payloads live -- stayed a build behind. Components are installed
            # when the player presses Join for that game, so -NoLaunch skips
            # them by construction. Two people then measured the wrong binary
            # and drew a conclusion from it.
            #
            # This does not START a component update: doing that silently would
            # be the opposite mistake, downloading a game's payload on a machine
            # that never asked for it. It states the fact and the exact command,
            # which is all that was missing.
            if (Test-Path -LiteralPath $componentStateRoot) {
                foreach ($stateFile in @(Get-ChildItem -LiteralPath $componentStateRoot `
                        -Filter '*.json' -ErrorAction SilentlyContinue)) {
                    $componentId = [IO.Path]::GetFileNameWithoutExtension($stateFile.Name)
                    $componentBuild = try { Get-ComponentInstalledBuild $componentId } catch { [Int64]0 }
                    if ($componentBuild -gt 0 -and $componentBuild -lt $availableBuild) {
                        $notice = ("Component '$componentId' is still at build $componentBuild " +
                                   "and was NOT updated: components install when you press Join " +
                                   "for that game. To update it now: " +
                                   "Update-Crossroads.ps1 -AcceptUpdate -NoLaunch -Component $componentId")
                        Write-UpdaterLog $notice
                        # Also to the console, because somebody running this by
                        # hand sees only the console and this script otherwise
                        # says nothing at all to them.
                        Write-Host $notice -ForegroundColor Yellow
                    }
                }
            }
        }
        Remove-Item -LiteralPath $transactionRoot -Recurse -Force
    }
    catch {
        foreach ($relative in $installed) {
            $targetFile = Join-Path $root $relative
            $backupFile = Join-Path $backupRoot $relative
            if (Test-Path -LiteralPath $backupFile -PathType Leaf) {
                Copy-Item -LiteralPath $backupFile -Destination $targetFile -Force
            }
            elseif (Test-Path -LiteralPath $targetFile -PathType Leaf) {
                Remove-Item -LiteralPath $targetFile -Force
            }
        }
        throw "The update could not be installed and was rolled back. $($_.Exception.Message)"
    }

    Remove-Item -LiteralPath $tempRoot -Recurse -Force
    if (-not $AcceptUpdate -and $Component -eq '') {
        [System.Windows.MessageBox]::Show(
            "Project: Crossroads was updated to build $availableBuild.",
            'Project: Crossroads - Update Complete',
            'OK',
            'Information') | Out-Null
    }
}
catch {
    Write-UpdaterLog "Update check failed: $($_.Exception.Message)"
    # A component install is a GATE: the launcher is waiting on the exit code to
    # decide whether the player may join. It must fail loudly rather than show a
    # dialog and exit 0, which the launcher would read as success and let a
    # stale adapter connect -- the silent-mismatch class this whole change
    # exists to remove.
    if ($AcceptUpdate -or $Component -ne '') {
        throw
    }
    Show-UpdateError (
        "Crossroads could not complete its update check.`n`n$($_.Exception.Message)`n`nThe installed build was left unchanged."
    )
}

# A component install never relaunches the launcher: it is already running and
# waiting for this to finish.
if ($Component -eq '') {
    Start-Launcher
}
