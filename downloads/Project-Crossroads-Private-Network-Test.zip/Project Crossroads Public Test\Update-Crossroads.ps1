[CmdletBinding()]
param(
    [int]$ParentProcessId = 0,
    [switch]$AfterUpdateCheck,
    [switch]$AcceptUpdate,
    [switch]$NoLaunch
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$launcher = Join-Path $root 'ProjectCrossroadsLauncher.exe'
$channelPath = Join-Path $root 'update-channel.json'
$installedBuildPath = Join-Path $root 'crossroads-build.txt'
$logPath = Join-Path $root 'updater-log.txt'

Add-Type -AssemblyName PresentationFramework

function Write-UpdaterLog([string]$message) {
    $line = '{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $message
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

function Show-UpdateError([string]$message) {
    [System.Windows.MessageBox]::Show(
        $message,
        'Project: Crossroads - Updater',
        'OK',
        'Error') | Out-Null
}

function Start-Launcher {
    if ($NoLaunch) {
        return
    }
    if (Test-Path -LiteralPath $launcher -PathType Leaf) {
        Start-Process -FilePath $launcher -ArgumentList '--after-update-check' `
            -WorkingDirectory $root
    }
}

function Read-BuildNumber([string]$path) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return [Int64]0
    }
    $value = (Get-Content -LiteralPath $path -Raw).Trim()
    $parsed = [Int64]0
    if (-not [Int64]::TryParse($value, [ref]$parsed) -or $parsed -lt 0) {
        return [Int64]0
    }
    return $parsed
}

function Resolve-UpdateSource([string]$source, [string]$baseSource) {
    if ([IO.Path]::IsPathRooted($source)) {
        return [IO.Path]::GetFullPath($source)
    }
    $absolute = $null
    if ([Uri]::TryCreate($source, [UriKind]::Absolute, [ref]$absolute)) {
        return $absolute.AbsoluteUri
    }
    $baseUri = $null
    if ([Uri]::TryCreate($baseSource, [UriKind]::Absolute, [ref]$baseUri) -and
        $baseUri.Scheme -in @('http', 'https', 'file')) {
        return ([Uri]::new($baseUri, $source)).AbsoluteUri
    }
    return [IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $baseSource) $source))
}

function Copy-UpdateSource([string]$source, [string]$destination) {
    if (Test-Path -LiteralPath $source -PathType Leaf) {
        Copy-Item -LiteralPath $source -Destination $destination -Force
        return
    }
    $uri = $null
    if ([Uri]::TryCreate($source, [UriKind]::Absolute, [ref]$uri)) {
        if ($uri.Scheme -eq 'https') {
            Invoke-WebRequest -UseBasicParsing -Uri $uri.AbsoluteUri `
                -OutFile $destination -TimeoutSec 20
            return
        }
        if ($uri.Scheme -eq 'file') {
            Copy-Item -LiteralPath $uri.LocalPath -Destination $destination -Force
            return
        }
        throw 'The update source must use HTTPS.'
    }
    Copy-Item -LiteralPath ([IO.Path]::GetFullPath($source)) `
        -Destination $destination -Force
}

function Test-SafeRelativePath([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path) -or
        [IO.Path]::IsPathRooted($path) -or
        $path.Contains('..') -or
        $path.Contains(':')) {
        return $false
    }
    $normalized = $path.Replace('/', '\').TrimStart('\')
    return -not ($normalized -ieq 'runtime' -or
        $normalized.StartsWith('runtime\', [StringComparison]::OrdinalIgnoreCase) -or
        $normalized -ieq 'startup-log.txt' -or
        $normalized -ieq 'diagnostic-report.txt' -or
        $normalized -ieq 'network-room-code.txt' -or
        $normalized -ieq 'updater-log.txt')
}

if ($ParentProcessId -gt 0) {
    $deadline = [DateTime]::UtcNow.AddSeconds(15)
    while ((Get-Process -Id $ParentProcessId -ErrorAction SilentlyContinue) -and
        [DateTime]::UtcNow -lt $deadline) {
        Start-Sleep -Milliseconds 100
    }
    if (Get-Process -Id $ParentProcessId -ErrorAction SilentlyContinue) {
        Write-UpdaterLog 'The launcher did not exit in time; the update check was skipped.'
        Start-Launcher
        exit 0
    }
}

if (-not (Test-Path -LiteralPath $channelPath -PathType Leaf)) {
    Start-Launcher
    exit 0
}

try {
    $channel = Get-Content -LiteralPath $channelPath -Raw | ConvertFrom-Json
    $manifestSource = [string]$channel.manifestUrl
    if ([string]::IsNullOrWhiteSpace($manifestSource) -or
        $manifestSource -eq 'UPDATE_SOURCE_NOT_CONFIGURED') {
        Write-UpdaterLog 'No update channel is configured; continuing with the installed build.'
        Start-Launcher
        exit 0
    }

    $tempRoot = Join-Path ([IO.Path]::GetTempPath()) `
        ('project-crossroads-update-' + [Guid]::NewGuid().ToString('N'))
    $downloadRoot = Join-Path $tempRoot 'download'
    $extractRoot = Join-Path $tempRoot 'extracted'
    New-Item -ItemType Directory -Force -Path $downloadRoot, $extractRoot | Out-Null

    $manifestPath = Join-Path $downloadRoot 'update-manifest.json'
    Copy-UpdateSource $manifestSource $manifestPath
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json

    $installedBuild = Read-BuildNumber $installedBuildPath
    $availableBuild = [Int64]$manifest.build
    if ($availableBuild -le $installedBuild) {
        Write-UpdaterLog "Build $installedBuild is current."
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
        Start-Launcher
        exit 0
    }

    $choice = if ($AcceptUpdate) {
        'Yes'
    }
    else {
        [System.Windows.MessageBox]::Show(
            "A Project: Crossroads update is available.`n`nInstalled build: $installedBuild`nAvailable build: $availableBuild`n`nInstall it now?",
            'Project: Crossroads - Update Available',
            'YesNo',
            'Information')
    }
    if ($choice -ne 'Yes') {
        Write-UpdaterLog "Build $availableBuild was declined."
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
        Start-Launcher
        exit 0
    }

    $archiveSource = Resolve-UpdateSource ([string]$manifest.packageUrl) $manifestSource
    $archivePath = Join-Path $downloadRoot 'Project-Crossroads-Update.zip'
    Copy-UpdateSource $archiveSource $archivePath
    $actualHash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash
    if ($actualHash -ine [string]$manifest.sha256) {
        throw 'The downloaded update failed its SHA-256 integrity check. Nothing was installed.'
    }

    Expand-Archive -LiteralPath $archivePath -DestinationPath $extractRoot -Force
    $payloadRoot = Join-Path $extractRoot 'Project Crossroads Update'
    $payloadManifestPath = Join-Path $payloadRoot 'managed-files.json'
    if (-not (Test-Path -LiteralPath $payloadManifestPath -PathType Leaf)) {
        throw 'The downloaded update does not contain its managed-file manifest.'
    }
    $managed = Get-Content -LiteralPath $payloadManifestPath -Raw | ConvertFrom-Json
    if ([Int64]$managed.build -ne $availableBuild) {
        throw 'The update package build number does not match the published manifest.'
    }

    $files = @($managed.files)
    if ($files.Count -eq 0) {
        throw 'The update package contains no managed files.'
    }
    foreach ($entry in $files) {
        $relative = [string]$entry.path
        if (-not (Test-SafeRelativePath $relative)) {
            throw "The update contains an unsafe or protected path: $relative"
        }
        $sourceFile = Join-Path $payloadRoot $relative
        if (-not (Test-Path -LiteralPath $sourceFile -PathType Leaf)) {
            throw "The update is missing a declared file: $relative"
        }
        $fileHash = (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256).Hash
        if ($fileHash -ine [string]$entry.sha256) {
            throw "The update file failed verification: $relative"
        }
    }

    $blockedProcesses = @(
        Get-Process -Name 'Fallout3', 'fose_loader', 'swkotor',
            'ProjectCrossroadsServer', 'CrossroadsKotorServer',
            'CrossroadsLiveMirror' -ErrorAction SilentlyContinue
    )
    if (-not $AcceptUpdate -and $blockedProcesses.Count -gt 0) {
        throw 'Close supported games and Crossroads servers, then reopen the launcher to install this update.'
    }

    $transactionRoot = Join-Path $root '.crossroads-update-transaction'
    $backupRoot = Join-Path $transactionRoot 'backup'
    if (Test-Path -LiteralPath $transactionRoot) {
        Remove-Item -LiteralPath $transactionRoot -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
    $installed = New-Object System.Collections.Generic.List[string]
    try {
        foreach ($entry in $files) {
            $relative = ([string]$entry.path).Replace('/', '\')
            $sourceFile = Join-Path $payloadRoot $relative
            $targetFile = Join-Path $root $relative
            $backupFile = Join-Path $backupRoot $relative
            if (Test-Path -LiteralPath $targetFile -PathType Leaf) {
                New-Item -ItemType Directory -Force `
                    -Path (Split-Path -Parent $backupFile) | Out-Null
                Copy-Item -LiteralPath $targetFile -Destination $backupFile -Force
            }
            New-Item -ItemType Directory -Force `
                -Path (Split-Path -Parent $targetFile) | Out-Null
            Copy-Item -LiteralPath $sourceFile -Destination $targetFile -Force
            $installed.Add($relative)
        }
        [IO.File]::WriteAllText(
            $installedBuildPath,
            $availableBuild.ToString(),
            [Text.UTF8Encoding]::new($false))
        Write-UpdaterLog "Updated successfully from build $installedBuild to $availableBuild."
        Remove-Item -LiteralPath $transactionRoot -Recurse -Force
    }
    catch {
        foreach ($relative in $installed) {
            $targetFile = Join-Path $root $relative
            $backupFile = Join-Path $backupRoot $relative
            if (Test-Path -LiteralPath $backupFile -PathType Leaf) {
                Copy-Item -LiteralPath $backupFile -Destination $targetFile -Force
            }
            elseif (Test-Path -LiteralPath $targetFile -PathType Leaf) {
                Remove-Item -LiteralPath $targetFile -Force
            }
        }
        throw "The update could not be installed and was rolled back. $($_.Exception.Message)"
    }

    Remove-Item -LiteralPath $tempRoot -Recurse -Force
    if (-not $AcceptUpdate) {
        [System.Windows.MessageBox]::Show(
            "Project: Crossroads was updated to build $availableBuild.",
            'Project: Crossroads - Update Complete',
            'OK',
            'Information') | Out-Null
    }
}
catch {
    Write-UpdaterLog "Update check failed: $($_.Exception.Message)"
    if ($AcceptUpdate) {
        throw
    }
    Show-UpdateError (
        "Crossroads could not complete its update check.`n`n$($_.Exception.Message)`n`nThe installed build was left unchanged."
    )
}

Start-Launcher
