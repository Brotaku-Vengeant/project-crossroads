PROJECT: CROSSROADS - PRIVATE NETWORK TEST
==========================================

This package contains early, controlled Fallout 3 and KotOR multiplayer tests
for trusted testers. Neither is a public server release, and gameplay
synchronization is still incomplete.

PLEASE KEEP SESSIONS TO 2-3 PLAYERS FOR NOW. There is a known scaling problem
in how appearance and equipment are shared: the cost grows with the square of
the number of players in one area. The servers will accept more than that; the
test will get worse, not better, and the numbers we collect stop meaning
anything. This is the top thing being worked on.

REQUIREMENTS
------------
- Windows and the Steam Fallout 3: Game of the Year Edition.
- Your own game patched to Fallout3.exe version 1.7.0.3 with the Fallout
  Anniversary Patcher.
- FOSE 1.2 beta 2 installed beside Fallout3.exe.
- The same Crossroads ZIP version for every player.
- Internet access to the configured Crossroads update channel.
- Adult characters saved in the same outdoor area.
- For the KotOR test: the English Steam release of KotOR 1, and a save you can
  load into the same area as the other players. Taris - Upper City North
  (tar_m02ab) is the area this project has tested in most.

Crossroads does not include or redistribute Fallout 3, FOSE, or the Anniversary
Patcher. Obtain those separately from their original project pages.

FOSE AND 4 GB PATCHERS
----------------------
- Yes, this test currently requires FOSE 1.2 beta 2. The setup checks for
  fose_loader.exe and fose_1_7.dll and copies them into Crossroads' isolated
  runtime.
- Crossroads currently supports the exact Fallout 3 1.7.0.3 executable produced
  by the Fallout Anniversary Patcher. The launcher validates that executable
  before starting a private session.
- Do not apply an additional or arbitrary 4 GB / Large Address Aware patcher to
  the Crossroads runtime. Other executable modifications are not validated or
  supported by this tester and may be rejected by the compatibility check.
- If your normal installation uses another executable patcher, keep a clean
  Anniversary Patcher 1.7.0.3 Fallout3.exe available for Crossroads setup.

UNIFIED LAUNCHER
----------------
- ProjectCrossroadsLauncher.exe opens the shared Crossroads Landing Pad.
- Select Fallout 3, then choose "Open Fallout Tools" for the validated
  diagnostics, private server, and join controls described below.
- The KotOR tab contains its live test server and Join button.
- Other game tabs are visible for readiness and development tracking only.
  There is no adapter behind them yet.
- Network Beacon latency is shown only when the package contains a real MMN
  beacon address and that service replies. Game server rows appear only while
  their corresponding server answers a live status check.

FIRST-TIME SETUP
----------------
1. Extract the entire ZIP to a normal folder. Do not run it inside the ZIP.
2. Open "ProjectCrossroadsLauncher.exe" and accept the initial Crossroads
   update. The small bootstrap package downloads and verifies the complete
   current tester components automatically.
3. After the update reopens the launcher, KotOR-only testers can select KotOR
   and use the online server row.
4. Fallout 3 testers double-click "Prepare Crossroads Test.cmd".
5. Confirm the detected Fallout 3 folder, or choose No and browse to a custom
   installation folder containing Fallout3.exe and the Data folder.
6. When setup succeeds, open "ProjectCrossroadsLauncher.exe".
7. Select Fallout 3 and click "Open Fallout Tools".
8. Click "Network Self-Test". Do not continue unless it passes.

AUTOMATIC UPDATES
-----------------
- This bootstrap package is the last package testers should normally need to
  install manually.
- Each time ProjectCrossroadsLauncher.exe starts, it checks the configured
  Crossroads update channel before opening the launcher.
- Updates come in two parts: the launcher itself updates when it starts, and a
  game's files are installed the first time you press Join for that game.
- The second part can take a while. The KotOR component is around 35 MB, and
  THE LAUNCHER CURRENTLY GIVES YOU NO PROGRESS INDICATION WHILE IT INSTALLS.
  It is working. Please wait rather than closing it. Better feedback here is a
  known gap and is on the list.
- Updates are downloaded only over HTTPS and must pass their published SHA-256
  integrity check. If verification or installation fails, the installed build
  is left unchanged.
- Updates replace only Crossroads-owned program files. The isolated Fallout
  runtime, selected installation path, logs, room code, and tester settings are
  preserved.
- Close Fallout and the dedicated server before installing an offered update.
  A KotOR component update will ask you to close KotOR and the Crossroads
  KotOR client, but does not require the KotOR server to stop.

The setup copies required files from your own Fallout installation into this
package's isolated runtime and links its Data folder to your selected installed
Data folder. A custom installation path is supported and does not need to match
the old Bethesda registry entry.

STARTING THE SERVER
-------------------
1. Leave the managed UDP port at its default unless the test coordinator says
   otherwise.
2. Click "Launch Dedicated Server". A separate server console appears.
3. Leave that console open. It does not launch or require Fallout.
4. Return to the shared Crossroads launcher. The official Fallout server
   appears in the browser after it answers the live status check.
5. Make sure UDP, not TCP, on that port is forwarded to the server PC.

The official test route and room are managed by Crossroads updates. Testers do
not type or exchange either value.

The person running the server is not automatically a player and does not use a
player slot. After launching the server, Crossroads automatically switches that
launcher to the local route so the server owner can click "Join Private
Session" exactly like another player.

JOINING
-------
1. Open the shared Crossroads launcher and select Fallout 3.
2. Select the online official test server and click "Join Test Server".
   Crossroads passes the managed route into the Fallout adapter and launches
   Fallout automatically.
3. Load an adult save in the same area. Snapshot streaming begins as soon as
   the loaded player becomes available; no tabbing or confirmation is needed.

CONTROLS
--------
- F10: save a Crossroads screenshot.

Close Fallout normally to disconnect. Crossroads remains connected through the
main menu and loading screens and cleans up automatically when the game exits.

WHAT WORKS TODAY
----------------
KotOR:
- Several other players can be visible at once, each as their own character.
- Your character's name, face, appearance and portrait are taken from your own
  save when you join.
- Walking, running and standing still are mirrored, with matching animation.
- Equipment changes reach the right player mid-session. Note that KotOR does
  not draw headgear on characters, so a helmet or mask will not be visible on
  anyone - that is the game, not a sync failure.
- You can walk between areas and still see each other, including on the way
  back.

Fallout 3:
- Two-player movement and visible remote players in the exterior world.
- A fix for players disappearing after cell transitions or tabbing out is
  written but has NOT been released or tested with two players yet. If you see
  that, it is known.

CURRENT LIMITS
--------------
- Keep it to 2-3 players. See the note at the top.
- Fallout 3: four active players maximum, including the host.
- To see each other in KotOR, be in the same area. You can move between areas
  freely once you are both in.
- KotOR displays live Crossroads connection state and the current player count
  in the game window's title bar, including while the main menu is open.
- Close KotOR without saving when its test ends. Crossroads then restores the
  temporary test files it installed. If KotOR closes abnormally, the next join
  cleans up after it.
- If the KotOR client encounters an error, its window remains open and writes
  details to kotor-client-log.txt beside the launcher.
- Trusted private testing only. Admission is room-code authenticated, but
  gameplay traffic is not encrypted.
- Not synchronized in either game: combat, quests, inventory, doors as shared
  objects, NPCs, and dialogue. What you do to the world is yours alone; only
  players are shared.

TROUBLESHOOTING
---------------
If something fails, close Fallout and Crossroads, then send the host:
- startup-log.txt
- diagnostic-report.txt
- updater-log.txt, if the problem happened during an update
- kotor-client-log.txt, for KotOR problems
- A screenshot of the error

If an update fails and rolls itself back, please say so rather than retrying in
a loop. There is a known case where it means "try again in five minutes", and
the log tells us which one it was.

Do not distribute modified Crossroads network configuration files.
