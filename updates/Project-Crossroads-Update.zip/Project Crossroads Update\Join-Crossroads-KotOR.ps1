[CmdletBinding()]
param(
    [string]$GameDirectory = '',

    # WHERE TO JOIN, supplied by the launcher.
    #
    # These exist because the server browser can now list servers this install
    # has never been configured for. Before Stage 5 the destination could only
    # come from crossroads-network.ini, so a browser that showed ten servers
    # could only ever join one of them.
    #
    # BOTH DEFAULT TO THE INI when absent, so an existing invocation -- a
    # tester double-clicking, an older launcher, the diagnostics path -- keeps
    # working unchanged.
    #
    # THERE WAS A THIRD, -ServerSession, AND IT IS GONE (2026-08-15). It carried
    # a join code, which no longer exists anywhere: no config key holds one, no
    # relay checks one, and the mirror has no argument to receive one. An older
    # launcher passing it fails loudly here rather than being quietly ignored,
    # because a launcher old enough to send it is also old enough to be running
    # against a mirror whose command line it no longer matches.
    [string]$ServerHost = '',
    [int]$ServerPort = 0
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$logPath = Join-Path $root 'kotor-client-log.txt'
try {
    Start-Transcript -LiteralPath $logPath -Append -Force | Out-Null
}
catch {
    # Joining can continue even if Windows cannot create the optional log.
}
trap {
    Write-Host ''
    Write-Host 'CROSSROADS KOTOR COULD NOT CONTINUE' -ForegroundColor Red
    Write-Host '===================================' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ''
    Write-Host "Diagnostic log: $logPath"
    $runningKotor = Get-Process 'swkotor' -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if ($runningKotor) {
        Write-Host ''
        Write-Host 'Close KotOR WITHOUT SAVING. Crossroads will clean up automatically.' `
            -ForegroundColor Yellow
        while (Get-Process 'swkotor' -ErrorAction SilentlyContinue) {
            Start-Sleep -Milliseconds 500
        }
    }
    # Closed on the failure path too, and with a reason that says so. Without
    # this, every crashed or refused join would leave a session open until the
    # service's abandoned sweep closed it twelve hours later -- which would make
    # every future playtime figure wrong in the same direction.
    # THE PLAYER'S OWN SAVES COME BACK FIRST ON THIS PATH, AND NOTHING IS
    # UPLOADED. They are parked under another name for the length of a public
    # session; putting them back is a rename and takes no time, while a final
    # upload sweep is megabytes over a tunnel. A player who has just been shown a
    # red error is the one most likely to close the window rather than wait, and
    # the cost of the two choices is not symmetric: losing the last save of a
    # join that already failed is a small loss, and leaving somebody's saves
    # parked under a name they do not know is a large one.
    if (Get-Command Exit-CrossroadsSaveSession -ErrorAction SilentlyContinue) {
        Exit-CrossroadsSaveSession -RestoreOnly
    }
    if (Get-Command Close-CrossroadsSession -ErrorAction SilentlyContinue) {
        Close-CrossroadsSession 'crashed'
    }
    if (Get-Command Restore-OwnedFiles -ErrorAction SilentlyContinue) {
        Restore-OwnedFiles
        Write-Host 'KotOR files restored. This window will close automatically.'
    }
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}

$component = Join-Path $root 'components\kotor1'
$configPath = Join-Path $root 'crossroads-network.ini'
$state = Join-Path $root 'state\kotor1'
$localState = Join-Path $state 'local'
$remoteState = Join-Path $state 'remote'
$backup = Join-Path $state 'backup'
$installRecord = Join-Path $state 'install-state.json'

function Read-IniValue {
    param([string]$Section, [string]$Key)
    $current = ''
    foreach ($line in Get-Content -LiteralPath $configPath) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') {
            $current = $Matches[1]
            continue
        }
        if ($current -eq $Section -and
            $trimmed -match ('^' + [regex]::Escape($Key) + '=(.*)$')) {
            return $Matches[1].Trim()
        }
    }
    throw "Missing [$Section] $Key in crossroads-network.ini."
}

function Read-OptionalIniValue {
    param([string]$Section, [string]$Key)
    try {
        return Read-IniValue $Section $Key
    }
    catch {
        return ''
    }
}

# ---- the session record -----------------------------------------------------
#
# Tells the Crossroads service that this account started playing, and tells it
# again when they stop. Everything an account will ever show -- games played,
# and later playtime -- is derived from these two calls. See
# docs\PLAN_2026-08-13-user-records.md.
#
# NOTHING HERE MAY STOP SOMEBODY PLAYING. Every call is best-effort with a short
# timeout, every failure is logged and swallowed, and none of it is on the path
# that launches the game. A record-keeping feature that can prevent a join would
# be a terrible trade, and it is the kind of thing that only shows up when the
# service is down and everybody is trying to play at once.
#
# IT DOES NOTHING AT ALL when accounts are not configured, which is every install
# in the field. Same switch as the join gate and the launcher's sign-in control.
$script:crossroadsSessionId = ''
# What KIND of server this session is on, as the SERVICE decided it -- never as
# this script guessed. Empty until a session opens, and empty forever on an
# install with no account configured, which is every install in the field. The
# save rule reads this and nothing else.
$script:crossroadsSessionClassification = ''

function Get-CrossroadsAccountToken {
    # Written by Sign-InToCrossroads.ps1, in the per-user profile directory --
    # never beside the executable, which in a managed install is shared.
    $accountPath = Join-Path $env:LOCALAPPDATA 'Project Crossroads\account.ini'
    if (-not (Test-Path -LiteralPath $accountPath -PathType Leaf)) { return '' }
    foreach ($line in (Get-Content -LiteralPath $accountPath)) {
        if ($line.Trim() -match '^token=(.*)$') { return $Matches[1].Trim() }
    }
    return ''
}

function Invoke-CrossroadsRecords {
    param([string]$Path, [hashtable]$Body)
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $null }
    try {
        [Net.ServicePointManager]::SecurityProtocol =
            [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11
    }
    catch { }
    try {
        return Invoke-RestMethod -Uri ($serviceUrl.TrimEnd('/') + $Path) `
            -Method Post -ContentType 'application/json' -TimeoutSec 8 `
            -UseBasicParsing -Body ($Body | ConvertTo-Json -Compress)
    }
    catch {
        # The message, never the body we sent -- that carries the account token.
        Write-Host ("Crossroads could not reach the account service ($Path). " +
                    'Play continues; this session will not be recorded.') `
            -ForegroundColor DarkGray
        return $null
    }
}

function Open-CrossroadsSession {
    param([string]$GameId, [string]$ServerHost, [uint16]$ServerPort)
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return }
    # WHERE they played is recorded; WHAT KIND of server it was is not claimed
    # here. The service decides classification for itself and records
    # `unverified` when it does not recognise the address -- a client that could
    # name its own classification could call itself an official server, and
    # playtime is meant to count official servers only.
    $response = Invoke-CrossroadsRecords '/session/open' @{
        accountToken = $token
        game = $GameId
        serverId = ("{0}:{1}" -f $ServerHost, $ServerPort)
    }
    if ($response -and $response.sessionId) {
        $script:crossroadsSessionId = [string]$response.sessionId
        $script:crossroadsSessionClassification =
            [string]$response.classification
    }
}

function Close-CrossroadsSession {
    param([string]$Reason = 'closed')
    if ([string]::IsNullOrWhiteSpace($script:crossroadsSessionId)) { return }
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return }
    $sessionId = $script:crossroadsSessionId
    # CLEARED FIRST, so this is safe to call twice. It is called from the normal
    # exit AND from the failure path, and those can both run -- a second close
    # would be answered 404 by the service and print a confusing line about the
    # service being unreachable when it is fine.
    $script:crossroadsSessionId = ''
    Invoke-CrossroadsRecords '/session/close' @{
        accountToken = $token
        sessionId = $sessionId
        reason = $Reason
    } | Out-Null
}

# ---- saves on a public server ------------------------------------------------
#
# THE OWNER'S RULE: on official and community-public servers a player may use
# only saves made while connected, and only the five most recent. A sixth deletes
# the oldest. A first public join needs a fresh character. Private and co-op are
# unrestricted. See docs\PLAN_2026-08-13-user-records.md section 6.
#
# HOW THAT IS MADE TRUE ON DISK, because recording saves is not the same as
# enforcing the rule: for the length of a public session the player's own saves
# folder is PARKED under another name and an empty one is put in its place,
# holding only the saves the service has recorded. So:
#
#   - "only saves made while connected are usable" is not a check that can be
#     bypassed; the other saves are not there to load.
#   - "a first public join needs a fresh character" needs no mechanism at all.
#     Nothing is downloaded because nothing is recorded, so the folder is empty
#     and the only thing the player can do is start a new game.
#
# PARKED BY RENAME, NEVER COPIED AND NEVER DELETED. A rename is atomic, it is
# reversible, and it never has two copies of a save that could diverge. The
# player's own saves are the most valuable thing on their disk and nothing here
# writes into them, reads them destructively, or removes them.
#
# AND IT IS RESTORED EVEN IF THIS SCRIPT IS KILLED. The swap is written to a
# record file before it happens, and the next join restores from that record
# before doing anything else -- the same shape as the Override file restore, and
# for the same reason: the abnormal exit is the case that matters.
try {
    # Loaded once, here, rather than at each use. Present in every PowerShell
    # version this project targets, but not loaded by default in 5.1.
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
}
catch {
    # Without it the save rule cannot pack or unpack anything. Not fatal on its
    # own -- the join continues and Enter-CrossroadsSaveSession will fail to
    # unpack, which is reported there rather than stopping a player joining.
    Write-Host 'Crossroads could not load the compression library for saves.' `
        -ForegroundColor DarkGray
}

$script:crossroadsSavesActive = $false
$script:crossroadsSavesFolder = ''
$script:crossroadsSaveFingerprints = @{}
$script:crossroadsSaveUploaded = @{}
$script:crossroadsSaveNextTick = [DateTime]::MinValue
$saveSwapRecord = Join-Path $state 'save-swap.json'
$saveWorkRoot = Join-Path $state 'save-work'

# A slot name arrives from the SERVICE, which stores whatever a client sent as
# display text -- so it is attacker-controlled by the time it comes back, and it
# is about to become a folder name on this machine. Anything that is not a plain
# save-folder name is refused rather than repaired.
$script:crossroadsSlotPattern = '^[A-Za-z0-9][A-Za-z0-9 ._\-]{0,63}$'

# ---- player sync: ONE PATH, NO SWITCH ----------------------------------------
#
# THE OLD LIFECYCLE AND ITS KILL SWITCH ARE DELETED HERE (Stage 1). Owner,
# 2026-08-15: *"we build a new god damn lifecycle"* -- *"delete it, kill the
# switch, build it whole."*
#
# WHAT WENT, AND WHY EACH ONE HAD TO:
#
#   `player_sync` / `identity_from_save`  Developer kill switches from the reset
#       (D62), read from `crossroads-launcher.ini` -- a file that ships in NONE
#       of the update archives. A setting that cannot travel is a setting two
#       machines silently disagree about, each seeing nobody, with "the fix did
#       not work" as the obvious wrong conclusion (register 51). Whether a
#       session replicates players is the SERVER's business, not a per-client
#       preference (D76); until the server says so, there is one path and
#       everyone is on it.
#
#   `Get-PlayerSave` / `New-CappedIdentitySave` / `Get-EquippedItemCount` /
#   `New-GenericIdentity`, the pre-launch identity exchange, and the
#   apply-identity step
#       THE ROOT FAULT, register 39, and the reason the first attempt was reset
#       (D58): they decided which character the world would see by SCANNING THE
#       SAVES FOLDER BEFORE THE GAME STARTED. The character replicated to
#       everybody was never the one the player went on to choose. Nothing here
#       reads a save to decide who anybody is, ever again.
#
#   The PowerShell presence sender ("on the server without syncing anything")
#       It existed only to keep a player on the roster while the sync-off branch
#       ran, and it CANNOT coexist with the mirror. The relay migrates a peer to
#       whichever socket spoke last -- `games/kotor1/server/src/main.cpp`, and
#       the comment there says so deliberately, for the identity helper. Two
#       registrations under one client id from two sockets means the roster
#       address flaps, and every snapshot the relay routes in the gap goes to a
#       socket nothing reads. A quiet, partial, intermittent loss: the worst
#       shape of fault this project keeps buying.
#
#       CONSEQUENCE, STATED RATHER THAN DISCOVERED: while a player is at the
#       menu or on a loading screen, the relay no longer knows they exist, so
#       they are not on its roster and not in the HUD's count. That is exactly
#       what Connected means in PLAN §4 -- on the server, visible to nobody --
#       and nothing today reads that roster for anything else. Playtime is
#       deliberately not reported and waits on the signed ticket regardless.
#
# WHAT REMAINS is one path, run for every join: sign in, record the session,
# apply the save rule, install the extender and the Override payloads, launch
# KotOR, and run the mirror. Who you are comes from the LIVE character through
# the extender -- the one identity-adjacent path that has never had an identity
# problem.
#
# WHERE RULE 1 IS ENFORCED, because it is NOT here. Nothing in this script can
# make a player visible: the mirror registers with the relay only once there is
# a player standing in a known module at a position the engine has actually
# written (`IsPresent`, live_mirror). Launching the game is not being in the
# world, and this script no longer pretends otherwise.

function Test-CrossroadsSaveRuleEnabled {
    # ON by default, per the owner's decision 2026-08-13. The switch exists so it
    # can be turned OFF on one machine without a rebuild, and it is read from
    # crossroads-launcher.ini FIRST because crossroads-network.ini is
    # updater-managed and anything hand-edited there is overwritten by the next
    # update -- the same trap the HUD capacity setting documents further down.
    $launcherConfigPath = Join-Path $root 'crossroads-launcher.ini'
    $configured = ''
    if (Test-Path -LiteralPath $launcherConfigPath -PathType Leaf) {
        $current = ''
        foreach ($line in Get-Content -LiteralPath $launcherConfigPath) {
            $trimmed = $line.Trim()
            if ($trimmed -match '^\[(.+)\]$') { $current = $Matches[1]; continue }
            if ($current -eq 'kotor1' -and $trimmed -match '^save_sync=(.*)$') {
                $configured = $Matches[1].Trim()
                break
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($configured)) {
        $configured = Read-OptionalIniValue 'kotor1' 'save_sync'
    }
    return ($configured -notmatch '^(?i)(off|false|0|no)$')
}

function Test-CrossroadsPublicSession {
    return @('official', 'community-public') -contains
        $script:crossroadsSessionClassification
}

function Get-CrossroadsFolderFingerprint {
    param([string]$Path)
    # Name, length and last-write time of every file, in a fixed order. This is
    # what decides whether a save has stopped being written to; it is NOT a
    # content hash, because hashing six megabytes every ten seconds during play
    # is a cost with no matching benefit -- the upload hashes for real.
    $parts = Get-ChildItem -LiteralPath $Path -File -ErrorAction SilentlyContinue |
        Sort-Object Name |
        ForEach-Object { '{0}|{1}|{2}' -f $_.Name, $_.Length, $_.LastWriteTimeUtc.Ticks }
    return ($parts -join ';')
}

function Invoke-CrossroadsSaveUpload {
    param([string]$SlotName, [string]$ZipPath)
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $false }
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return $false }
    try {
        $bytes = [IO.File]::ReadAllBytes($ZipPath)
        $sha = (Get-FileHash -LiteralPath $ZipPath -Algorithm SHA256).Hash.ToLower()
        $request = [Net.HttpWebRequest]::Create(
            $serviceUrl.TrimEnd('/') + '/save/upload')
        $request.Method = 'POST'
        $request.ContentType = 'application/zip'
        # Generous compared with the session calls: this is megabytes over a
        # tunnel, not a few hundred bytes. Still bounded, because nothing here
        # may hold up a player who is trying to quit.
        $request.Timeout = 60000
        $request.ReadWriteTimeout = 60000
        # THE CREDENTIALS TRAVEL IN HEADERS because the body is the archive.
        # Never in the URL -- that is the part of a request that ends up in
        # access logs and proxy logs.
        $request.Headers.Add('X-Crossroads-Token', $token)
        $request.Headers.Add('X-Crossroads-Session', $script:crossroadsSessionId)
        $request.Headers.Add('X-Crossroads-Game', 'kotor1')
        $request.Headers.Add('X-Crossroads-Slot', $SlotName)
        $request.Headers.Add('X-Crossroads-Sha256', $sha)
        $request.ContentLength = $bytes.Length
        $stream = $request.GetRequestStream()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Close()
        $response = $request.GetResponse()
        $reader = New-Object IO.StreamReader($response.GetResponseStream())
        $answer = $reader.ReadToEnd()
        $reader.Close()
        $response.Close()
        # The service says which slots this upload pushed out of the five, and
        # they are removed from the game folder here. See
        # Remove-CrossroadsEvictedSave for why that is done at all.
        try {
            $parsed = $answer | ConvertFrom-Json
            if ($parsed -and $parsed.evictedSlots) {
                foreach ($gone in @($parsed.evictedSlots)) {
                    Remove-CrossroadsEvictedSave ([string]$gone) $SlotName
                }
            }
        }
        catch { }
        return $true
    }
    catch {
        # The message only, never the request -- that carries the account token.
        Write-Host ("Crossroads could not upload the save '$SlotName'. " +
                    'Play continues; it will be retried.') -ForegroundColor DarkGray
        return $false
    }
}

function Remove-CrossroadsEvictedSave {
    param([string]$SlotName, [string]$JustUploaded)
    # DELETING A PLAYER'S SAVE FILE WHILE THEIR GAME IS RUNNING. That is what
    # this does, so it is worth being plain about why and about every guard.
    #
    # WHY: eviction used to happen only on the service. The owner made six saves
    # in one session and KotOR listed all six, because nothing had removed
    # anything from the game folder -- so "only the five most recent are usable"
    # was true across joins and visibly false within one, and the sixth save was
    # still loadable. The owner chose to make the rule true at all times.
    #
    # THE GUARDS, and each one is load-bearing:
    #
    #  - it does nothing unless a public session is active, so it can never run
    #    against an ordinary single-player saves folder;
    #  - it deletes only inside the SESSION folder, never the parked one holding
    #    the player's own characters;
    #  - the slot name comes back from the service, which stores whatever a
    #    client sent as display text, so it is checked against the same pattern
    #    used when unpacking -- it must be a plain folder name or nothing
    #    happens;
    #  - it refuses to delete the save that was just uploaded. The service does
    #    not report a REWRITTEN slot as evicted, so this should be unreachable;
    #    it is here because the cost of that being wrong once is the player's
    #    newest save, and the check is one comparison.
    if (-not $script:crossroadsSavesActive) { return }
    if ([string]::IsNullOrWhiteSpace($SlotName)) { return }
    if ($SlotName -notmatch $script:crossroadsSlotPattern) { return }
    if ($SlotName -eq $JustUploaded) { return }

    $target = Join-Path $script:crossroadsSavesFolder $SlotName
    if (-not (Test-Path -LiteralPath $target -PathType Container)) { return }
    try {
        Remove-Item -LiteralPath $target -Recurse -Force
        $script:crossroadsSaveFingerprints.Remove($SlotName)
        $script:crossroadsSaveUploaded.Remove($SlotName)
        Write-Host ("Crossroads removed the oldest save '$SlotName' -- this " +
                    'server keeps your five most recent.') -ForegroundColor DarkGray
    }
    catch {
        # A failure here costs nothing: the save is already gone from the
        # service, so it will not come back on the next join either way.
        Write-Host ("Crossroads could not remove the evicted save '$SlotName'.") `
            -ForegroundColor DarkGray
    }
}

function Get-CrossroadsRecordedSaves {
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return @() }
    $listed = Invoke-CrossroadsRecords '/save/list' @{
        accountToken = $token
        game = 'kotor1'
    }
    if (-not $listed -or -not $listed.saves) { return @() }
    return @($listed.saves)
}

function Invoke-CrossroadsSaveFetch {
    param([string]$SaveId, [string]$Destination)
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $false }
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return $false }
    try {
        $request = [Net.HttpWebRequest]::Create(
            $serviceUrl.TrimEnd('/') + '/save/fetch')
        $request.Method = 'POST'
        $request.ContentType = 'application/json'
        $request.Timeout = 60000
        $request.ReadWriteTimeout = 60000
        $payload = [Text.Encoding]::UTF8.GetBytes(
            (@{ accountToken = $token; saveId = $SaveId } | ConvertTo-Json -Compress))
        $request.ContentLength = $payload.Length
        $stream = $request.GetRequestStream()
        $stream.Write($payload, 0, $payload.Length)
        $stream.Close()
        $response = $request.GetResponse()
        $target = [IO.File]::Open($Destination, [IO.FileMode]::Create)
        try { $response.GetResponseStream().CopyTo($target) }
        finally { $target.Close(); $response.Close() }
        return $true
    }
    catch {
        Write-Host 'Crossroads could not download one of your recorded saves.' `
            -ForegroundColor DarkGray
        return $false
    }
}

function Restore-CrossroadsSaves {
    # Put the player's own saves back. Safe to call at any time, including when
    # no swap ever happened, and safe to call twice.
    if (-not (Test-Path -LiteralPath $saveSwapRecord -PathType Leaf)) { return }
    $record = $null
    try {
        $record = Get-Content -LiteralPath $saveSwapRecord -Raw | ConvertFrom-Json
    }
    catch {
        # An unreadable record is not a reason to leave the player's saves
        # parked. Say so loudly -- this is the one failure in the whole feature
        # that a player would notice as "my saves are gone".
        Write-Host ('CROSSROADS COULD NOT READ ITS SAVE RECORD. If your KotOR ' +
                    'saves folder looks empty, the original is beside it under ' +
                    'a name starting "saves.crossroads".') -ForegroundColor Red
        return
    }
    if ($record -and $record.parked -and (Test-Path -LiteralPath $record.parked)) {
        # The SESSION folder goes first, then the rename back. If this is
        # interrupted between the two, the record is still on disk and the next
        # join runs this again.
        if ($record.live -and (Test-Path -LiteralPath $record.live)) {
            Remove-Item -LiteralPath $record.live -Recurse -Force `
                -ErrorAction SilentlyContinue
        }
        try {
            Move-Item -LiteralPath $record.parked -Destination $record.live -Force
            Write-Host 'Crossroads restored your own KotOR saves.'
        }
        catch {
            Write-Host ("CROSSROADS COULD NOT RESTORE YOUR SAVES AUTOMATICALLY. " +
                        "They are safe at: $($record.parked)") -ForegroundColor Red
            return
        }
    }
    Remove-Item -LiteralPath $saveSwapRecord -Force -ErrorAction SilentlyContinue
    $script:crossroadsSavesActive = $false
}

function Enter-CrossroadsSaveSession {
    param([string]$Game)
    if (-not (Test-CrossroadsPublicSession)) { return }
    if (-not (Test-CrossroadsSaveRuleEnabled)) {
        Write-Host ('The public save rule is switched off on this install; ' +
                    'your own saves are being used.') -ForegroundColor Yellow
        return
    }

    $live = Join-Path $Game 'saves'
    $parked = Join-Path $Game 'saves.crossroads-offline'
    if (Test-Path -LiteralPath $parked) {
        # A previous run parked saves and its record was lost. Refuse rather
        # than overwrite: whatever is in there is somebody's character.
        throw ("Crossroads found a parked saves folder from an earlier session " +
               "at $parked. Move or rename it before joining a public server.")
    }

    New-Item -ItemType Directory -Force -Path $saveWorkRoot | Out-Null
    # WRITTEN BEFORE THE RENAME, not after. If this script dies between the two
    # the record describes a swap that did not happen, and the restore finds no
    # parked folder and simply clears the record. The other order would leave a
    # parked folder nothing knows about.
    $record = @{ live = $live; parked = $parked
                 stamped = (Get-Date).ToString('o') } | ConvertTo-Json
    [IO.File]::WriteAllText($saveSwapRecord, $record,
        (New-Object Text.UTF8Encoding($false)))

    if (Test-Path -LiteralPath $live) {
        Move-Item -LiteralPath $live -Destination $parked -Force
    }
    New-Item -ItemType Directory -Force -Path $live | Out-Null
    $script:crossroadsSavesActive = $true
    $script:crossroadsSavesFolder = $live

    Write-Host ''
    Write-Host 'PUBLIC SERVER SAVE RULE' -ForegroundColor Cyan
    Write-Host ('On this server you can use only saves made while connected. ' +
                'Your own saves are parked and come back when you leave.')

    $recorded = Get-CrossroadsRecordedSaves
    $restoredCount = 0
    foreach ($save in $recorded) {
        $slot = [string]$save.slot
        if ($slot -notmatch $script:crossroadsSlotPattern) {
            # The service stores a slot name as text and does not constrain it to
            # something that is safe as a folder name here. Refused rather than
            # sanitised -- a repaired name is a guess, and this one becomes a
            # path on the player's disk.
            Write-Host ('Skipped a recorded save whose name cannot be used as a ' +
                        'folder.') -ForegroundColor DarkGray
            continue
        }
        $archive = Join-Path $saveWorkRoot ('fetch-' + [Guid]::NewGuid().ToString('N') + '.zip')
        if (-not (Invoke-CrossroadsSaveFetch $save.saveId $archive)) { continue }
        try {
            $target = Join-Path $live $slot
            [IO.Compression.ZipFile]::ExtractToDirectory($archive, $target)
            $restoredCount++
            # Remembered as already-sent, so the watcher does not immediately
            # upload back what it just downloaded. The service would not store a
            # duplicate anyway, but a re-zip is not byte-identical to the
            # original -- zip archives carry timestamps -- so its hash check
            # cannot be relied on to catch this. The client has to know.
            $fingerprint = Get-CrossroadsFolderFingerprint $target
            $script:crossroadsSaveFingerprints[$slot] = $fingerprint
            $script:crossroadsSaveUploaded[$slot] = $fingerprint
        }
        catch {
            Write-Host ("Crossroads could not unpack the recorded save '$slot'.") `
                -ForegroundColor DarkGray
        }
        finally {
            Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
        }
    }

    if ($restoredCount -gt 0) {
        Write-Host ("Restored $restoredCount of your recorded save(s) for this server.")
    }
    else {
        Write-Host ('You have no recorded saves on this server yet, so start a ' +
                    'NEW game. Existing characters cannot be brought onto a ' +
                    'public server.')
    }
    Write-Host ''
}

function Update-CrossroadsSaves {
    param([switch]$Final)
    if (-not $script:crossroadsSavesActive) { return }
    if (-not $Final) {
        if ([DateTime]::UtcNow -lt $script:crossroadsSaveNextTick) { return }
        $script:crossroadsSaveNextTick = [DateTime]::UtcNow.AddSeconds(10)
    }

    $folders = Get-ChildItem -LiteralPath $script:crossroadsSavesFolder `
        -Directory -ErrorAction SilentlyContinue
    foreach ($folder in $folders) {
        $slot = $folder.Name
        if ($slot -notmatch $script:crossroadsSlotPattern) { continue }
        $fingerprint = Get-CrossroadsFolderFingerprint $folder.FullName
        if ([string]::IsNullOrWhiteSpace($fingerprint)) { continue }

        if (-not $Final) {
            # QUIESCE. A KotOR save is five files written over some interval, and
            # a folder zipped mid-write produces a torn save that would fail its
            # own hash on the way back in. Upload only what looked identical on
            # two consecutive ticks; anything still changing waits.
            if ($script:crossroadsSaveFingerprints[$slot] -ne $fingerprint) {
                $script:crossroadsSaveFingerprints[$slot] = $fingerprint
                continue
            }
        }
        if ($script:crossroadsSaveUploaded[$slot] -eq $fingerprint) { continue }

        $archive = Join-Path $saveWorkRoot ('send-' + [Guid]::NewGuid().ToString('N') + '.zip')
        try {
            [IO.Compression.ZipFile]::CreateFromDirectory(
                $folder.FullName, $archive,
                [IO.Compression.CompressionLevel]::Optimal, $false)
        }
        catch {
            # Most often the game still holds a handle. Not an error: the next
            # tick tries again.
            Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
            continue
        }
        if (Invoke-CrossroadsSaveUpload $slot $archive) {
            $script:crossroadsSaveUploaded[$slot] = $fingerprint
            $script:crossroadsSaveFingerprints[$slot] = $fingerprint
        }
        Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
    }
}

function Exit-CrossroadsSaveSession {
    param([switch]$RestoreOnly)
    if (-not $script:crossroadsSavesActive) { return }
    # THE FINAL SWEEP RUNS BEFORE THE SESSION IS CLOSED, because an upload needs
    # an open session -- that is what "made while connected" means to the
    # service, and closing first would throw away the last save of the sitting.
    # The quiesce rule is skipped here: the game has exited, so nothing is still
    # being written.
    if (-not $RestoreOnly) { Update-CrossroadsSaves -Final }
    Restore-CrossroadsSaves
    Remove-Item -LiteralPath $saveWorkRoot -Recurse -Force -ErrorAction SilentlyContinue
}

function Test-KotorServerHost {
    param(
        [string]$HostName,
        [uint16]$Port
    )
    if ([string]::IsNullOrWhiteSpace($HostName)) {
        return $false
    }
    $client = [Net.Sockets.UdpClient]::new()
    try {
        $client.Client.ReceiveTimeout = 1200
        $client.Connect($HostName, $Port)
        $nonce = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString('X16')
        $request = [Text.Encoding]::ASCII.GetBytes(
            "CRS_KOTOR_STATUS_V1 $nonce")
        [void]$client.Send($request, $request.Length)
        $remote = [Net.IPEndPoint]::new([Net.IPAddress]::Any, 0)
        $response = [Text.Encoding]::ASCII.GetString(
            $client.Receive([ref]$remote))
        return $response.StartsWith("CRS_KOTOR_STATUS_V1_ACK $nonce ")
    }
    catch {
        return $false
    }
    finally {
        $client.Dispose()
    }
}

function Get-GameDirectory {
    param([string]$ConfiguredDirectory)
    if (-not [string]::IsNullOrWhiteSpace($ConfiguredDirectory)) {
        $configured = $ConfiguredDirectory.Trim('"')
        if (-not (Test-Path -LiteralPath (Join-Path $configured 'swkotor.exe'))) {
            throw 'The KotOR folder supplied by the launcher does not contain swkotor.exe.'
        }
        return (Resolve-Path -LiteralPath $configured).Path
    }
    $default = 'C:\Program Files (x86)\Steam\steamapps\common\swkotor'
    if (Test-Path -LiteralPath (Join-Path $default 'swkotor.exe')) {
        return $default
    }
    $chosen = (Read-Host 'Paste the folder containing swkotor.exe').Trim('"')
    if (-not (Test-Path -LiteralPath (Join-Path $chosen 'swkotor.exe'))) {
        throw 'The selected folder does not contain swkotor.exe.'
    }
    return (Resolve-Path -LiteralPath $chosen).Path
}

function Get-SteamExecutable {
    $runningSteam = Get-Process 'steam' -ErrorAction SilentlyContinue |
        Where-Object { $_.Path -and (Test-Path -LiteralPath $_.Path) } |
        Select-Object -First 1
    if ($runningSteam) {
        return $runningSteam.Path
    }
    $candidates = @()
    try {
        $steamPath = (Get-ItemProperty `
            'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath
        if ($steamPath) {
            $candidates += Join-Path $steamPath 'steam.exe'
        }
    }
    catch {}
    try {
        $steamPath = (Get-ItemProperty `
            'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' `
            -ErrorAction Stop).InstallPath
        if ($steamPath) {
            $candidates += Join-Path $steamPath 'steam.exe'
        }
    }
    catch {}
    $candidates += 'C:\Program Files (x86)\Steam\steam.exe'
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    return ''
}

# Launch the game. Returns TRUE when the launch went through Steam.
#
# THE RETURN VALUE EXISTS SO THE WAIT BELOW CAN BE SIZED HONESTLY. A direct
# launch puts swkotor.exe on the process list within a second or two, because
# this script started it. A Steam launch does not: Steam is asked to start the
# game and returns immediately, and everything after that -- starting Steam
# itself if it was closed, its update check, the game's own startup -- happens on
# Steam's clock, not ours.
function Start-KotorGame {
    param([string]$Game)
    $steam = Get-SteamExecutable
    if ($steam) {
        Write-Host 'Requesting KotOR launch through Steam...'
        Start-Process -FilePath $steam `
            -ArgumentList @('-applaunch', '32370') | Out-Null
        return $true
    }
    Write-Host 'Steam was not detected; using the game executable directly.'
    Start-Process -FilePath (Join-Path $Game 'swkotor.exe') `
        -WorkingDirectory $Game | Out-Null
    return $false
}

function Get-KotorInjectedModules {
    param([int]$ProcessId)

    # KotOR is 32-bit. Ask the built-in 32-bit Windows PowerShell host to
    # enumerate its modules so this check also works when Crossroads itself was
    # launched from 64-bit PowerShell.
    $powershell32 = Join-Path $env:WINDIR `
        'SysWOW64\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $powershell32 -PathType Leaf)) {
        return @()
    }

    $probe = @"
`$process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
if (`$process) {
    `$process.Modules | ForEach-Object { `$_.ModuleName }
}
"@
    $encoded = [Convert]::ToBase64String(
        [Text.Encoding]::Unicode.GetBytes($probe))
    return @(
        & $powershell32 -NoProfile -NonInteractive `
            -EncodedCommand $encoded 2>$null |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )
}

# How many items is the saved character wearing?
#
# WHY THIS EXISTS. CrossroadsBuildIdentity.exe caps the join identity at four
# equipment entries and raises "Join identity supports at most four visible
# equipment slots". The player sees a Python traceback followed by "Crossroads
# could not read the selected player character", which names neither the cause
# nor the remedy. On 2026-08-08 that cost twenty minutes of diagnosis on a
# machine that was working an hour earlier -- an equipment test had left the
# character wearing eight items.
#
# THE MESSAGE IS ALSO WRONG, WHICH IS WHY THE REMEDY IS NOT GUESSABLE. It says
# "visible", but build_remote_template.py iterates the entire Equip_ItemList
# with no visibility filter: implants, belts and armbands count exactly as much
# as armour does. Someone unequipping only what shows on the model strips their
# character and still fails.
#
# FAILS OPEN. Returns -1 on anything it does not understand, and the caller
# then hands the builder the save exactly as before -- so a parser bug here can
# only ever restore the old behaviour, never invent a new refusal.
function Get-ClientId {
    $registry = [Microsoft.Win32.RegistryKey]::OpenBaseKey(
        [Microsoft.Win32.RegistryHive]::LocalMachine,
        [Microsoft.Win32.RegistryView]::Registry64)
    try {
        $cryptography = $registry.OpenSubKey(
            'SOFTWARE\Microsoft\Cryptography', $false)
        if (-not $cryptography) {
            throw 'Windows machine identity registry key was not found.'
        }
        try {
            $machineGuid = [string]$cryptography.GetValue('MachineGuid')
        }
        finally {
            $cryptography.Dispose()
        }
    }
    finally {
        $registry.Dispose()
    }
    if ([string]::IsNullOrWhiteSpace($machineGuid)) {
        throw 'Windows machine identity is unavailable.'
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $hash = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($machineGuid))
    }
    finally {
        $sha.Dispose()
    }
    $id = [BitConverter]::ToUInt32($hash, 0)
    return $(if ($id -eq 0) { [uint32]1 } else { $id })
}

function Backup-OwnedFiles {
    param([string]$Game)
    if (Test-Path -LiteralPath $installRecord) {
        return
    }
    $override = Join-Path $Game 'Override'
    New-Item -ItemType Directory -Force -Path $override,$backup | Out-Null
    # EVERY hash Crossroads has ever shipped for these files, not just the
    # current one.
    #
    # This gate exists to refuse an unrelated mod's file. With a single hash it
    # also refused OUR OWN PREVIOUS BUILD, because a leftover from an earlier
    # session is not the current hash and is therefore "unrelated". Measured
    # 2026-08-07: the heartbeat changed twice in one day and every machine
    # holding a leftover was blocked from joining, with a message that reads
    # like a foreign mod is installed. The tester sees the game fail to start
    # and has no way to know the offending file is ours.
    #
    # So the value is a LIST, appended to whenever a payload file changes.
    # Recognising our own history is what lets the gate keep saying no to
    # somebody else's file while still replacing ours.
    $known = @{
        'cr_orig_hb.ncs' = @(
            # Retail k_def_heartbt01, saved under our name. One value; it is
            # BioWare's file and does not change.
            '1008B0A66E742332A8B7E7BD6E92B9ECF5C686D9DCB21C7A0EC7CC67C4FBF482'
        )
        # crs_dress.ncs -- NEW 2026-08-15, the appearance half of the Stage 1
        # lifecycle. One entry because it has shipped once; this list grows the
        # same way the others did.
        'crs_dress.ncs' = @(
            # 2026-08-15: the peer walk went from 8 to 64 (register 60).
            'C47341454DD6CECA2E808324C656DF770280E8E732C51FE5E42E7E78AD93CB39',
            # The first build that shipped, walking 8.
            '336959A6ABFD8142BD9D3AD6F3322EBF7D33B282141EE680B61DE2A61264885F'
        )
        'crs_pulse.ncs' = @(
            # 2026-08-15, later the same day: the sweep and reconcile walks went
            # from 8 slots to 64 (register 60), so a client is told about up to
            # 64 other players instead of silently 8.
            '994981B60BF4F772ADEDD44E9E12DDBACCC5BD269A777364CBD1E2FD2F1CB3CA',
            # STAGE 1, 2026-08-15: the lifecycle. Publish, check arrival, then
            # either sweep and stop or repair and dress. LISTED FIRST AND LISTED
            # AT ALL because the entry below it records what happens when it is
            # not: the shipped build was missing from this table for a week, and
            # a machine holding a leftover of the CURRENT build was refused the
            # join with a message blaming a foreign mod.
            'F4F9D973416DBC1E32DA832ADA9413070027DEF0258E356744C36C07017E0F12',
            # CURRENT, and it was MISSING until 2026-08-14. The heartbeat below
            # accumulated five entries as it changed; this list kept one and
            # never got its second, so the file Crossroads itself ships was not
            # recognised as its own. A machine holding a leftover of the CURRENT
            # build was refused the join with a message blaming a foreign mod --
            # the exact failure the comment above says this list prevents, live
            # against the shipped file. Recorded OPEN in the player-sync reset
            # findings and fixed here.
            '1867BC9DF6ED688CB450204C02746D942C12DD070B490E2173A5A4A7A819D6ED',
            # The reconcile work KSE drives from the script dispatcher instead
            # of from whatever creature stands near the player. Listed here for
            # the same reason the heartbeat is: this table is how the join
            # recognises its OWN leftovers, so a file it does not know about
            # would be mistaken for another mod's and refuse the join (D36).
            'A8663C04D4AFB4C936B07D1A6A0A2DDCC20EF0FD220A9D5AFDD64D945A61C5C9',
            # MEASUREMENT PROBES, which install themselves over this same name
            # for one run. They are never shipped and never packaged, and they
            # are listed for exactly the reason the dead heartbeat build above
            # is: this gate's job is to recognise our own leftovers so it can
            # replace them, not to judge which of our files a machine ought to
            # be holding. A probe whose harness was killed before it restored
            # leaves one of these behind, and the tester must still be able to
            # join. games\kotor1\tools\Measure-KotorSweepGap.ps1 also repairs
            # its own leftovers on the next run; this is the second line.
            '7C7C4627FDF356B9F3903C5079751817EF660846FA5B9E5BFE13956346626B37',
            '3ADD1E4A151AFEA3106AD00B2F883F722628E33396948C91AF38D5D1BC780889',
            # crs_bakeprobe rebuilt 2026-08-14 to record the player's position
            # on every pulse, which is how register 47 was settled. The OLD hash
            # above stays: this list is append-only because its job is to
            # recognise our own leftovers, and a machine that ran the earlier
            # probe can still be holding one. crs_sweepprobe recompiled
            # byte-identical from unchanged source, so it needs no new entry.
            '3E739628993848C4CA60A81D90F7A719D81FF73A01ADB3B66AE4230B455A322E'
        )
        'k_def_heartbt01.ncs' = @(
            # STAGE 1, 2026-08-15: reduced from 348 lines to one job, 3,967
            # bytes to 406. It used to carry the whole reconcile while writing
            # the SAME KSE block as crs_pulse -- two scripts owning the same
            # bodies on two clocks, which is a race rather than a redundancy. It
            # now only chains the stock creature heartbeat and publishes the
            # local player as a fallback.
            '6101F0ED7C91B44641C20371125EDA3511EBFB38B559EE16B2105B65110CFEB6',
            # Previous: per-peer equipment, compiled with nwnnsscomp (D30).
            # Same source as the entry below it; the difference is the
            # compiler, which is the whole of that incident.
            '60F8D7501572A72110B52829A9621330AEDF8D22171721BB6D3B1592A2521B89',
            # Shipped in 202608080035 and DOES NOT EXECUTE (D30). Listed anyway,
            # and deliberately: this gate's job is to recognise our own history
            # so it can replace our files, not to judge whether a given build
            # worked. A machine left holding this one after an abnormal session
            # must still be allowed to join, or it is locked out by a message
            # that blames a foreign mod.
            'B174A84D17BF27B27273D81FE6FC55AC7F63AA6D2AA6FA52B0685C6E74F132EC',
            # 2026-08-07: + peer loadout application, single actor.
            'C71DA7141B3225686637212F349DCA6D4D72A47D6C3DAC6A3C0A5FCD85495D76',
            # 2026-08-07: + local loadout publication (read half).
            '2A76582E5FE0C07BF5711B4371B2E3161F891574D1EB5411EC06A44FD1289D39',
            # 2026-08-07 and earlier: presence-driven reconciler (D19).
            '0534505A715DC30F0D72638C356196139BEA486026A6F5E85A98DBBD88CA8680'
        )
    }
    $records = @()
    foreach ($name in @(
            'cr_orig_hb.ncs',
            'k_def_heartbt01.ncs',
            'crs_pulse.ncs',
            # MUST BE TRACKED, not just installed. This list is what
            # Restore-OwnedFiles walks on the way out, so a payload file missing
            # from it is one Crossroads writes into somebody's Override and then
            # leaves behind forever.
            'crs_dress.ncs',
            'crossroadsghost.utc')) {
        $target = Join-Path $override $name
        $existed = Test-Path -LiteralPath $target
        $crossroadsOwned = $false
        if ($existed -and $known.ContainsKey($name)) {
            $actual = (Get-FileHash -LiteralPath $target `
                -Algorithm SHA256).Hash
            if ($known[$name] -notcontains $actual) {
                throw ("An unrelated Override\$name is installed. Crossroads " +
                       "will not replace it.`n`nIf you are certain it is not " +
                       "from another mod, delete it and rejoin.`n" +
                       "Found SHA-256: $actual")
            }
            # Past the gate above, the hash IS one of ours.
            $crossroadsOwned = $true
        }
        # crossroadsghost.utc carries no hash list because it is generated from
        # the player's own character, so its bytes differ on every machine and
        # every session. Ownership is settled by the NAME instead: that ResRef
        # is one Crossroads invented, and stock KotOR has no such template, so
        # a file at this path cannot be anybody else's.
        if ($existed -and $name -eq 'crossroadsghost.utc') {
            $crossroadsOwned = $true
        }

        # A FILE WE RECOGNISE AS OUR OWN IS NOT THE PLAYER'S FILE, AND MUST NOT
        # BE RESTORED.
        #
        # Stock KotOR ships k_def_heartbt01 inside a BIF with nothing in
        # Override, and cr_orig_hb.ncs is a name only Crossroads writes. So a
        # recognised file here was left by US -- by a session that ended
        # abnormally, before Restore-OwnedFiles could run.
        #
        # Recording it as pre-existing made that damage permanent AND
        # self-perpetuating: the next join backed our own leftover up as if it
        # were the player's, and every clean exit afterwards faithfully put it
        # back. Measured 2026-08-08 on the development machine, which had been
        # running a 2026-08-07 Crossroads heartbeat (0534505A...) as the
        # default creature heartbeat in single-player for a day, reinstalled
        # after every session, while the installed component shipped a
        # different one. It is also why Assert-CrossroadsKotorInstall reported
        # a heartbeat mismatch after every clean session -- the tool was right
        # and the restore was wrong.
        #
        # "Nothing" is the correct previous state, and recording it makes an
        # abnormal exit self-healing instead of permanent. Both files come back
        # on the next join: cr_orig_hb.ncs is re-extracted from the player's own
        # install, k_def_heartbt01.ncs is copied from the component.
        #
        # This does NOT weaken the foreign-mod gate. An unrecognised file still
        # throws above and is never written to, backed up, or deleted.
        if ($crossroadsOwned) {
            $records += [pscustomobject]@{ name = $name; existed = $false }
            continue
        }
        if ($existed) {
            Copy-Item -LiteralPath $target `
                -Destination (Join-Path $backup $name) -Force
        }
        $records += [pscustomobject]@{ name = $name; existed = $existed }
    }
    $settingsPath = Join-Path $Game 'swkotor.ini'
    if (-not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) {
        throw 'KotOR has no swkotor.ini. Launch the game once before joining Crossroads.'
    }
    Copy-Item -LiteralPath $settingsPath `
        -Destination (Join-Path $backup 'swkotor.ini') -Force
    $gpuPreferencePath =
        'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    $gameExecutable = Join-Path $Game 'swkotor.exe'
    $existingGpuPreference = $null
    $gpuPreferenceExisted = $false
    if (Test-Path -LiteralPath $gpuPreferencePath) {
        try {
            $existingGpuPreference = Get-ItemPropertyValue `
                -LiteralPath $gpuPreferencePath `
                -Name $gameExecutable `
                -ErrorAction Stop
            $gpuPreferenceExisted = $true
        }
        catch {
            $gpuPreferenceExisted = $false
        }
    }
    [pscustomobject]@{
        game = $Game
        files = $records
        settingsBackedUp = $true
        gpuPreference = [pscustomobject]@{
            executable = $gameExecutable
            existed = $gpuPreferenceExisted
            value = $existingGpuPreference
        }
    } |
        ConvertTo-Json -Depth 4 |
        Set-Content -LiteralPath $installRecord -Encoding UTF8
}

function Set-KotorHighPerformanceGpu {
    param([string]$Game)
    $gpuPreferencePath =
        'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    New-Item -Path $gpuPreferencePath -Force | Out-Null
    New-ItemProperty `
        -LiteralPath $gpuPreferencePath `
        -Name (Join-Path $Game 'swkotor.exe') `
        -PropertyType String `
        -Value 'GpuPreference=2;' `
        -Force | Out-Null
}

function Set-KotorCompatibilityProfile {
    param([string]$Game)
    $settingsPath = Join-Path $Game 'swkotor.ini'
    $lines = [Collections.Generic.List[string]]::new()
    $lines.AddRange([string[]](Get-Content -LiteralPath $settingsPath))

    $sectionStart = -1
    for ($index = 0; $index -lt $lines.Count; ++$index) {
        if ($lines[$index].Trim() -ieq '[Graphics Options]') {
            $sectionStart = $index
            break
        }
    }
    if ($sectionStart -lt 0) {
        if ($lines.Count -gt 0 -and $lines[$lines.Count - 1] -ne '') {
            $lines.Add('')
        }
        $lines.Add('[Graphics Options]')
        $sectionStart = $lines.Count - 1
    }

    $sectionEnd = $lines.Count
    for ($index = $sectionStart + 1; $index -lt $lines.Count; ++$index) {
        if ($lines[$index].Trim() -match '^\[.+\]$') {
            $sectionEnd = $index
            break
        }
    }

    foreach ($setting in @(
            [pscustomobject]@{ Key = 'AllowWindowedMode'; Value = '1' },
            [pscustomobject]@{ Key = 'FullScreen'; Value = '0' },
            [pscustomobject]@{ Key = 'Anisotropy'; Value = '0' },
            [pscustomobject]@{ Key = 'Frame Buffer'; Value = '0' },
            [pscustomobject]@{ Key = 'Grass'; Value = '0' })) {
        $found = $false
        for ($index = $sectionStart + 1; $index -lt $sectionEnd; ++$index) {
            if ($lines[$index] -match (
                    '^\s*' + [regex]::Escape($setting.Key) + '\s*=')) {
                $lines[$index] = "$($setting.Key)=$($setting.Value)"
                $found = $true
                break
            }
        }
        if (-not $found) {
            $lines.Insert(
                $sectionEnd,
                "$($setting.Key)=$($setting.Value)")
            ++$sectionEnd
        }
    }

    [IO.File]::WriteAllLines(
        $settingsPath,
        $lines,
        [Text.Encoding]::Default)
}

# Install KSE (K1SE) into the game directory. Crossroads depends on it for
# engine-sourced local-player identity (D12), so it is bundled rather than a
# tester prerequisite (D15).
#
# THE ORDER HERE IS THE WHOLE SAFETY ARGUMENT. KSE installs AS binkw32.dll and
# forwards to the renamed original. binkw32.dll is a real game import: if this
# machine is ever left without one, KotOR does not launch at all -- a worse
# outcome than any sync bug, and one the player cannot diagnose because they
# never reach a menu.
#
# So: COPY the original aside, VERIFY the copy, and only then overwrite. At no
# instant does binkw32.dll fail to exist. A move-first sequence would open a
# window where a crash, a full disk, or antivirus quarantine leaves no game.
#
# We never ship the original. It is RAD Game Tools' Bink -- retail content --
# and the packager refuses to build if a copy reaches an archive. Same rule as
# the stock heartbeat under D11.
#
# UNINSTALL IS DELIBERATE, NOT AUTOMATIC (D15). This is recorded in its own
# state file rather than the per-session install record, because
# Restore-OwnedFiles deletes what it recorded every time KotOR closes. That is
# right for a temporary ghost actor and wrong for a script extender the player
# also uses for their own single-player mods. Uninstall-KSE.ps1 reverses it.
function Install-KSE {
    param([string]$Game)

    $source = Join-Path $component 'kse\binkw32.dll'
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw ('The Crossroads KotOR component is incomplete: kse\binkw32.dll ' +
               'is missing. Restart the launcher to update.')
    }

    $proxy = Join-Path $Game 'binkw32.dll'
    $real = Join-Path $Game 'binkw32_real.dll'
    $record = Join-Path $state 'kse-install-state.json'

    if (-not (Test-Path -LiteralPath $proxy -PathType Leaf)) {
        throw ('Your KotOR folder has no binkw32.dll. Crossroads will not ' +
               'touch it in that state -- verify the game files through Steam ' +
               'first.')
    }

    # Is the proxy already ours? Identify by content, not by name: both files
    # legitimately use this filename, and only their contents distinguish them.
    $proxyText = [Text.Encoding]::ASCII.GetString(
        [IO.File]::ReadAllBytes($proxy))
    $proxyIsKse = $proxyText.Contains('KSE ') -and $proxyText.Contains('STAGE19')
    $sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash

    if ($proxyIsKse) {
        if (-not (Test-Path -LiteralPath $real -PathType Leaf)) {
            throw ('KotOR has a KSE binkw32.dll but no binkw32_real.dll to ' +
                   'forward to. The game cannot start in that state. Verify ' +
                   'the game files through Steam, then rejoin.')
        }
        if ((Get-FileHash -LiteralPath $proxy -Algorithm SHA256).Hash -eq $sourceHash) {
            Write-Host 'Crossroads script extender: already current.'
            return
        }
        # Upgrade in place. The original is already safely aside, so this is a
        # single overwrite with nothing to preserve.
        Copy-Item -LiteralPath $source -Destination $proxy -Force
        Write-Host 'Crossroads script extender: updated.'
        return
    }

    # Fresh install -- but ONLY once $proxy has been positively identified as
    # the retail Bink. It used to be asserted here in a comment and never
    # checked, and the assertion is wrong in exactly the case that matters.
    #
    # THE HOLE THIS CLOSES. The refusal below catches another mod that proxies
    # binkw32.dll only if it also preserved the original under OUR spare name.
    # A third-party extender that renames the original to anything else -- and
    # there is no convention here, the name is ours -- fell straight through to
    # this point, and Crossroads then copied THEIR proxy to binkw32_real.dll,
    # recorded its hash as "the original", and installed over it. The retail
    # Bink then survived only inside their spare file, and Uninstall-KSE.ps1
    # would later restore their proxy and report the game was back to its
    # original DLL. Both installs destroyed, silently, and the report was a lie.
    #
    # `RAD Game Tools` is the discriminator, MEASURED IN BOTH DIRECTIONS on
    # 2026-08-10 rather than assumed: it is present in retail Bink and absent
    # from the KSE proxy. The obvious-looking `Bink` is present in BOTH -- the
    # proxy has to export the same names -- so it identifies nothing. The
    # packager's own ship-time gate relies on the same pair of facts.
    if (Test-Path -LiteralPath $real -PathType Leaf) {
        throw ('KotOR already has a binkw32_real.dll but its binkw32.dll is ' +
               'not KSE. Another mod uses the same mechanism, and Crossroads ' +
               'will not overwrite it.')
    }

    if (-not $proxyText.Contains('RAD Game Tools')) {
        throw ('KotOR''s binkw32.dll is neither the retail file nor the ' +
               'Crossroads script extender, so something else installed it. ' +
               'Crossroads will not overwrite it -- doing so would bury that ' +
               'mod''s file as if it were your original, and neither could be ' +
               'restored afterwards. Uninstall the other mod, or verify the ' +
               'game files through Steam, then rejoin.')
    }

    Copy-Item -LiteralPath $proxy -Destination $real -Force
    $originalHash = (Get-FileHash -LiteralPath $proxy -Algorithm SHA256).Hash
    if ((Get-FileHash -LiteralPath $real -Algorithm SHA256).Hash -ne $originalHash) {
        Remove-Item -LiteralPath $real -Force -ErrorAction SilentlyContinue
        throw ('Crossroads could not safely preserve the original ' +
               'binkw32.dll, so it changed nothing.')
    }

    Copy-Item -LiteralPath $source -Destination $proxy -Force

    [pscustomobject]@{
        game = $Game
        installed = (Get-Date).ToString('o')
        originalSha256 = $originalHash
        proxySha256 = $sourceHash
    } |
        ConvertTo-Json -Depth 3 |
        Set-Content -LiteralPath $record -Encoding UTF8

    Write-Host 'Crossroads script extender installed.' -ForegroundColor Green
    Write-Host ('  Your original binkw32.dll was preserved as ' +
                'binkw32_real.dll. It stays installed after you disconnect; ' +
                'run Uninstall-KSE.ps1 to reverse it.')
}

function Restore-OwnedFiles {
    if (-not (Test-Path -LiteralPath $installRecord)) {
        return
    }
    $record = Get-Content -LiteralPath $installRecord -Raw | ConvertFrom-Json
    $override = Join-Path $record.game 'Override'
    foreach ($file in $record.files) {
        $target = Join-Path $override $file.name
        if ($file.existed) {
            Copy-Item -LiteralPath (Join-Path $backup $file.name) `
                -Destination $target -Force
        }
        elseif (Test-Path -LiteralPath $target) {
            Remove-Item -LiteralPath $target -Force
        }
    }
    if ($record.PSObject.Properties.Name -contains 'settingsBackedUp' -and
        $record.settingsBackedUp) {
        Copy-Item -LiteralPath (Join-Path $backup 'swkotor.ini') `
            -Destination (Join-Path $record.game 'swkotor.ini') -Force
    }
    if ($record.PSObject.Properties.Name -contains 'gpuPreference' -and
        $record.gpuPreference) {
        $gpuPreferencePath =
            'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
        if ($record.gpuPreference.existed) {
            New-Item -Path $gpuPreferencePath -Force | Out-Null
            New-ItemProperty `
                -LiteralPath $gpuPreferencePath `
                -Name $record.gpuPreference.executable `
                -PropertyType String `
                -Value $record.gpuPreference.value `
                -Force | Out-Null
        }
        elseif (Test-Path -LiteralPath $gpuPreferencePath) {
            Remove-ItemProperty `
                -LiteralPath $gpuPreferencePath `
                -Name $record.gpuPreference.executable `
                -ErrorAction SilentlyContinue
        }
    }
    Remove-Item -LiteralPath $installRecord -Force
    if (Test-Path -LiteralPath $backup) {
        Remove-Item -LiteralPath $backup -Recurse -Force
    }
}

if (-not (Test-Path -LiteralPath $component)) {
    throw 'The Crossroads KotOR component is missing. Restart the launcher to update.'
}
if (Get-Process 'swkotor' -ErrorAction SilentlyContinue) {
    throw 'Close KotOR before joining the Crossroads test server.'
}
# Recover automatically from an older interrupted client session. A previous
# build required users to return to its console and press Enter after closing
# KotOR, so abandoned install records may legitimately remain.
if (Test-Path -LiteralPath $installRecord) {
    Restore-OwnedFiles
    Write-Host 'Crossroads restored temporary files from the previous session.'
}
# AND THE SAVES, from a session that was killed rather than closed. Deliberately
# separate from the install record above: the saves swap happens BEFORE
# Backup-OwnedFiles writes that record, so a failure in between would leave saves
# parked with no install record to notice it. Its own record, restored on its own
# terms, and unconditionally -- even a join that is about to fail for some other
# reason must not leave a player's saves under a name they do not know.
Restore-CrossroadsSaves

# THE DESTINATION. Supplied by the launcher when it knows one, from the INI
# when it does not.
#
# The two paths are kept visibly apart rather than merged, because they have
# different fallback rules and merging them is how one quietly acquires the
# other's. A launcher-supplied endpoint is used EXACTLY as given: no LAN
# fallback, no INI overlay, no loopback substitution. The launcher already
# measured that address with the game's own status probe and chose it; second-
# guessing it here would send the player somewhere they did not select.
if (-not [string]::IsNullOrWhiteSpace($ServerHost) -and $ServerPort -gt 0) {
    $hostName = $ServerHost
    $port = [uint16]$ServerPort
    Write-Host ("Joining the server selected in the launcher: {0}:{1}" -f $hostName, $port)
}
else {
    $publicHost = Read-IniValue 'kotor1' 'server_host'
    $lanHost = Read-OptionalIniValue 'kotor1' 'server_lan_host'
    $port = [uint16](Read-IniValue 'kotor1' 'server_port')
    $hostName = ''
    if (Get-Process 'CrossroadsKotorServer' -ErrorAction SilentlyContinue) {
        $hostName = '127.0.0.1'
    }
    elseif (Test-KotorServerHost $publicHost $port) {
        $hostName = $publicHost
    }
    elseif ($lanHost -ne $publicHost -and
        (Test-KotorServerHost $lanHost $port)) {
        $hostName = $lanHost
    }
    if (-not $hostName) {
        throw 'The Crossroads KotOR test server is not reachable.'
    }
}
$game = Get-GameDirectory $GameDirectory

# THE SESSION OPENS BEFORE THE GAME STARTS, which is the property the session
# record wants: an attempt that fails to launch is still an attempt. The save
# rule runs immediately after it, so the saves the player is allowed to load are
# in place before KotOR is given a chance to read any of them.
#
# The ordering paragraph that used to be here explained why the session had to
# open before the saves folder was SCANNED FOR AN IDENTITY. Nothing scans it any
# more -- that was register 39 -- so the constraint is gone with the code.
Open-CrossroadsSession 'kotor1' $hostName $port
Enter-CrossroadsSaveSession $game

$clientId = Get-ClientId
New-Item -ItemType Directory -Force `
    -Path $localState,$remoteState | Out-Null

# Records what is in Override so Restore-OwnedFiles can put it back, and backs up
# swkotor.ini and the GPU preference that the compatibility profile is about to
# change. With nothing installed it records our filenames as absent, so a
# leftover from a session that ended abnormally is CLEANED UP on exit rather than
# left behind.
Backup-OwnedFiles $game
Set-KotorCompatibilityProfile $game
# Must happen before the game launches: KSE is loaded by swkotor.exe at startup
# through the binkw32 import, so installing it afterwards has no effect until the
# next run.
Install-KSE $game

Write-Host ''
Write-Host 'PROJECT: CROSSROADS - KOTOR CLIENT'
Write-Host '================================='
# SAID OUT LOUD, EVERY JOIN, and the two lines are not the same kind of
# statement. The first describes a RULE and is permanent. The second describes
# what is not built yet and comes out when it is.
#
# The reason for both is the one this project keeps relearning: a player who
# cannot see somebody needs to know whether that is a fault or the current state
# of the project, and a console that says nothing invites the wrong answer.
Write-Host 'Other players appear once they are standing in the world.'
Write-Host ('Nobody is visible from the main menu, during character creation, ' +
            'or on a loading screen -- including you, to them.')
Write-Host 'Everyone in this session syncs. There is no per-machine setting.'
Write-Host ''
Write-Host 'STAND-INS ARE NOT DRESSED AS THEIR PLAYER YET.' -ForegroundColor Yellow
Write-Host ('Other players appear in the right place wearing what they are ' +
            'carrying, but with a generic face and body, and without their ' +
            'name above them. That is Stage 1b and is not a fault.') `
    -ForegroundColor Yellow
Write-Host ''
Write-Host 'Connecting to the online KotOR test server...'
Write-Host 'KotOR compatibility profile: windowed; unstable legacy graphics effects disabled.'
Write-Host 'KotOR graphics processor: Windows default selection.'

# ---- the join ---------------------------------------------------------------
#
# THE SYNC-OFF BRANCH AND THE IDENTITY BUILD USED TO SIT HERE. Both are gone.
#
# The branch was a whole second join -- launch the game, hold the roster open,
# wait for KotOR to close -- kept beside the real one so a switch could pick
# between them. With the switch deleted there is one path, and a reader no
# longer has to work out which of two launches they are looking at.
#
# The identity build was `CrossroadsBuildIdentity.exe` reading a save to write
# `crossroadsghost.utc`, so the stand-in everybody else saw was assembled from a
# file on disk before the player had chosen anything. Register 39. What ships in
# its place is the SHIPPED TEMPLATE, installed below and identical on every
# machine, dressed live from the equipment channel once a body exists.
#
# WHAT THAT COSTS TODAY, AND IT IS DELIBERATE (Stage 1b): every stand-in wears
# the same face. Appearance and nameplates are the owner's next stage, and the
# banner above says so to the player rather than leaving them to wonder.

$override = Join-Path $game 'Override'

# cr_orig_hb.ncs is the stock KotOR heartbeat script. Our override chains to it
# so normal game behaviour still runs, so it has to be in Override -- but it is
# BioWare's file, not ours, and Crossroads never ships or transfers retail game
# assets (decision D11 in docs/DECISIONS.md). It is therefore taken from THIS
# machine's own KotOR installation, which the player owns, rather than from the
# download.
#
# The hash is the stock script as Crossroads was built and tested against. A
# mismatch means a modified installation, and the extractor refuses rather than
# writing unexpected bytes into Override.
$retailHeartbeat = Join-Path $override 'cr_orig_hb.ncs'
if (-not (Test-Path -LiteralPath $retailHeartbeat)) {
    $extractor = Join-Path $PSScriptRoot 'Get-KotorRetailResource.ps1'
    if (-not (Test-Path -LiteralPath $extractor -PathType Leaf)) {
        throw ('Get-KotorRetailResource.ps1 is missing from the Crossroads ' +
               'package. Reinstall or repair it.')
    }
    try {
        & $extractor -GameDirectory $game -ResRef 'k_def_heartbt01' `
            -ResourceType 2010 -Destination $retailHeartbeat `
            -ExpectedSha256 `
            '1008B0A66E742332A8B7E7BD6E92B9ECF5C686D9DCB21C7A0EC7CC67C4FBF482' |
            Out-Null
    }
    catch {
        throw ("Crossroads could not read the stock heartbeat script from " +
               "your KotOR installation, so it cannot continue.`n`n" +
               "$($_.Exception.Message)`n`n" +
               'Crossroads does not distribute game files, so it takes this ' +
               'one from your own copy of the game.')
    }
}

Copy-Item -LiteralPath (Join-Path $component 'k_def_heartbt01.ncs') `
    -Destination $override -Force

# crs_pulse.ncs -- the script KSE runs from the engine's dispatcher (~4 Hz)
# instead of waiting for a creature to stand within 25 m of the player. Copied
# only if the component carries it, so an older component still installs.
$pulsePayload = Join-Path $component 'crs_pulse.ncs'
if (Test-Path -LiteralPath $pulsePayload -PathType Leaf) {
    Copy-Item -LiteralPath $pulsePayload -Destination $override -Force
}

# crs_dress.ncs -- the appearance half, called BY NAME from crs_pulse every
# steady-state pulse.
#
# INSTALLED UNCONDITIONALLY, unlike the pulse above it, and the asymmetry is
# deliberate. The pulse is optional because an older component genuinely may not
# carry it and the join must still work. This one is not optional in the same
# way: if crs_pulse is here and this is not, the pulse calls a script that does
# not exist -- which in this engine is SILENT. No error, no log entry, no
# failure. Stand-ins appear in the right place and are never dressed, forever,
# and the only symptom is everybody wearing the template's kit.
#
# So a component carrying the pulse but not the dress is a broken package rather
# than an old one, and it is said out loud here rather than discovered by a
# tester. The packager refuses to build that pair at all
# (Assert-KotorPayloadMatchesExtender); this is the second line, for a component
# assembled some other way.
$dressPayload = Join-Path $component 'crs_dress.ncs'
if (Test-Path -LiteralPath $dressPayload -PathType Leaf) {
    Copy-Item -LiteralPath $dressPayload -Destination $override -Force
}
elseif (Test-Path -LiteralPath $pulsePayload -PathType Leaf) {
    throw ('This Crossroads component carries crs_pulse.ncs without ' +
           "crs_dress.ncs.`n`nThe two are halves of one lifecycle and the " +
           'first calls the second by name. Running with only one of them ' +
           'produces other players who appear correctly and are never dressed, ' +
           "with nothing reported anywhere.`n`n" +
           'Update Crossroads and rejoin.')
}
$installedRemoteActor = Join-Path $override 'crossroadsghost.utc'
# EVERY STAND-IN IS BUILT FROM THIS ONE TEMPLATE, and it must be in place before
# the game launches: KotOR caches a missing ResRef for the lifetime of the
# process, so a template that arrives late never resolves at all for that run.
#
# It used to be a placeholder that `CrossroadsApplyIdentity.exe` overwrote with
# the peer's real appearance once the identity exchange completed. There is no
# exchange now, so this IS the appearance -- the same shipped commoner on every
# machine, dressed live from the equipment channel by crs_dress once a body
# exists. Stage 1b replaces this with something per-player.
Copy-Item -LiteralPath (Join-Path $component 'crossroadsghost.base.utc') `
    -Destination $installedRemoteActor -Force

Write-Host ''
Write-Host 'Launching KotOR...'

$launchedThroughSteam = Start-KotorGame $game
Write-Host 'Load a save or start a new game; other players appear once you are'
Write-Host 'standing in the world, and only those in the same area as you.'

# HOW LONG TO WAIT FOR THE GAME TO APPEAR, AND WHY IT IS NOT FIFTEEN SECONDS.
#
# THIS COST A PLAYER A WHOLE SESSION ON 2026-08-15, silently. A third tester
# joined, their saves were parked and restored, the console printed everything
# above this line -- and then the join THREW, because swkotor.exe had not
# appeared within fifteen seconds of asking Steam to start it. Steam launches the
# game regardless, so they sat in KotOR for the rest of the evening, fully
# playable, with no mirror and no HUD, invisible to everybody and never once in
# the player count. The only trace was a console that stopped mid-way and an
# empty mirror-logs folder.
#
# FIFTEEN SECONDS IS A DIRECT-LAUNCH NUMBER APPLIED TO A STEAM LAUNCH. When this
# script starts swkotor.exe itself the process exists almost immediately. When it
# asks Steam, `-applaunch` returns at once and everything real happens afterwards
# on Steam's clock: starting Steam if it was closed, its update check, the game's
# own startup. On a warm Steam that is a few seconds, which is why this was never
# hit here; on a cold one it is routinely minutes.
#
# SO THE BOUND IS SIZED TO THE ROUTE. The timeout is kept rather than removed --
# waiting forever for a game that will never start is its own failure, and the
# steps below genuinely need a process id -- but a bound that is shorter than the
# thing it is bounding is not a safety check, it is a race.
$gameWaitSeconds = if ($launchedThroughSteam) { 240 } else { 30 }

# AND IT SAYS WHAT IT IS WAITING FOR, on a cadence. The old loop was silent, so a
# player whose join was about to fail saw a console that had simply stopped --
# indistinguishable from one that was working. This is the same rule the mirror's
# discovery loop already follows and for the same reason.
$gameDeadline = [DateTime]::UtcNow.AddSeconds($gameWaitSeconds)
$gameWaitAnnounced = $false
$gameWaitStarted = [DateTime]::UtcNow
do {
    $gameProcess = Get-Process 'swkotor' -ErrorAction SilentlyContinue |
        Sort-Object StartTime -Descending |
        Select-Object -First 1
    if (-not $gameProcess) {
        $waited = ([DateTime]::UtcNow - $gameWaitStarted).TotalSeconds
        if ($waited -ge 10 -and -not $gameWaitAnnounced) {
            $gameWaitAnnounced = $true
            Write-Host ''
            Write-Host ('Waiting for KotOR to start (up to ' +
                        "$gameWaitSeconds seconds)...")
            if ($launchedThroughSteam) {
                Write-Host ('Steam is starting it. A cold Steam, an update ' +
                            'check or a first launch can take a few minutes; ' +
                            'this is normal.')
            }
        }
        Start-Sleep -Milliseconds 250
    }
} while (-not $gameProcess -and [DateTime]::UtcNow -lt $gameDeadline)
if (-not $gameProcess) {
    # THE MESSAGE NAMES THE ROUTE, because the two causes need different actions
    # from the player and the old one named neither.
    $how = if ($launchedThroughSteam) {
        "Crossroads asked Steam to launch it $gameWaitSeconds seconds ago and " +
        "it has not appeared.`n`nIf Steam was closed, updating, or asked you " +
        'to confirm something, start KotOR from Steam first and then press ' +
        'Join again.'
    }
    else {
        "Crossroads started swkotor.exe $gameWaitSeconds seconds ago and it is " +
        'not running.'
    }
    throw ("KotOR did not start, so Crossroads cannot connect you to other " +
           "players.`n`n$how`n`nYour own saves are parked and will be put back " +
           'when you close the game.')
}

$injectedModules = Get-KotorInjectedModules $gameProcess.Id
if ($injectedModules -imatch '^DiscordHook\.dll$') {
    Write-Host ''
    Write-Host 'CROSSROADS STABILITY WARNING' -ForegroundColor Yellow
    Write-Host 'Discord Clips attached its capture hook to KotOR.' `
        -ForegroundColor Yellow
    Write-Host 'Disable Discord Settings > Clips, restart Discord, and restart this session.' `
        -ForegroundColor Yellow
    try { [Console]::Beep(660, 180) } catch {}
}

$hudArguments = @(
    $gameProcess.Id.ToString(),
    $hostName,
    $port.ToString()
)
# Capacity is passed ONLY when this install actually knows one, and the HUD
# prints no denominator at all when it is absent. It used to print a hardcoded
# "/ 4" regardless, which said four while the relay held sixty-four.
#
# server_capacity is optional and is the same key the launcher reads for the
# server browser, so the two cannot disagree about this install's own server.
#
# READ FROM crossroads-launcher.ini FIRST, exactly as the launcher does.
# crossroads-network.ini is UPDATER-MANAGED -- it ships inside the platform
# component, so anything hand-edited there is overwritten by the next update
# and the setting silently reverts. crossroads-launcher.ini is shipped by
# nothing and is where a local override belongs. Reading only the managed file
# here would have meant the launcher honouring an override that the HUD never
# saw, which is precisely the disagreement the comment above claims cannot
# happen.
$launcherConfigPath = Join-Path $root 'crossroads-launcher.ini'
$configuredCapacity = ''
if (Test-Path -LiteralPath $launcherConfigPath -PathType Leaf) {
    $current = ''
    foreach ($line in Get-Content -LiteralPath $launcherConfigPath) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') { $current = $Matches[1]; continue }
        if ($current -eq 'kotor1' -and $trimmed -match '^server_capacity=(.*)$') {
            $configuredCapacity = $Matches[1].Trim()
            break
        }
    }
}
if ([string]::IsNullOrWhiteSpace($configuredCapacity)) {
    $configuredCapacity = Read-OptionalIniValue 'kotor1' 'server_capacity'
}
if ($configuredCapacity -match '^\d+$' -and [int]$configuredCapacity -gt 0) {
    $hudArguments += $configuredCapacity
}
$hudProcess = Start-Process `
    -FilePath (Join-Path $component 'CrossroadsKotorHud.exe') `
    -ArgumentList $hudArguments -PassThru

# THE MIRROR STARTS NOW, NOT WHEN SOMEBODY ELSE TURNS UP.
#
# WHAT WAS HERE: a blocking wait on CrossroadsIdentityExchange.exe, which sat on
# the relay until a peer arrived, then handed back a 132-byte identity that
# CrossroadsApplyIdentity.exe baked into the stand-in template before the mirror
# was allowed to start. A join could therefore spend its whole session waiting
# for a second player, and the first thing it did on getting one was assemble a
# body from an identity read off a save file (register 39).
#
# WHY NOTHING REPLACES THE WAIT. Under the new lifecycle peers are not announced
# -- they are RECONCILED. crs_pulse compares who the relay says is present in
# this area against the bodies actually standing there, every pulse, and fixes
# the difference in both directions. A peer who arrives late, drops out, walks
# through a door or reloads is the same case as a peer who was never there, so
# there is nothing to wait for and nothing to be told. That repair loop is the
# part the plan calls most important and the part that did not exist before.
#
# EARLY EXIT KEPT, AND FIXED WHILE IT MOVED. The old guard here restored files
# and threw, which skipped Close-CrossroadsSession -- leaving the row open until
# the service's twelve-hour abandoned sweep, with every playtime figure derived
# from it wrong in the same direction, and an open session is also a standing
# upload permit. The block this replaces got that right and said why; this now
# does the same thing.
if (-not (Get-Process 'swkotor' -ErrorAction SilentlyContinue)) {
    Exit-CrossroadsSaveSession
    Close-CrossroadsSession 'closed'
    Restore-OwnedFiles
    Write-Host 'KotOR closed before mirroring began. Crossroads restored its temporary files.'
    try { Stop-Transcript | Out-Null } catch {}
    exit 0
}

$gameProcess = Get-Process 'swkotor' -ErrorAction SilentlyContinue |
    Sort-Object StartTime -Descending |
    Select-Object -First 1
$movementArguments = @(
    'network-peer',
    $gameProcess.Id.ToString(),
    $hostName,
    $port.ToString(),
    '86400',
    # NO SESSION ARGUMENT. It sat between the duration and the client id until
    # 2026-08-15 and went with the join-code mechanism. The mirror rejects the
    # old eight-argument form outright, so a mismatched pair of components
    # cannot start and silently sync nothing.
    $clientId.ToString(),
    'execute-crossroads-peer-mirror'
)
$movementExecutable =
    Join-Path $component 'CrossroadsLiveMirror.exe'
$movementAttempt = 0
$movementProcess = $null

# WHY: CrossroadsLiveMirror is the only component that can report whether actor
# discovery actually succeeded, and it reports it on stdout/stderr. Start-Transcript
# hooks the PowerShell host's own output stream, NOT the console handle a native
# child process writes to, so under -NoNewWindow that text reached the screen and
# was never recorded anywhere. 51 mirror restarts across 21 sessions were logged
# with no reason captured. Give each attempt its own pair of capture files and
# echo them back into the transcript so the reason survives the session.
$mirrorLogDirectory = Join-Path $state 'mirror-logs'
New-Item -ItemType Directory -Force -Path $mirrorLogDirectory | Out-Null
$mirrorRunStamp = [DateTime]::Now.ToString('yyyyMMdd-HHmmss')
$mirrorLaunchCount = 0

function Write-MirrorCapture {
    param([string]$Label, [string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Write-Host "    [$Label] (no file)"
        return
    }
    $captured = @(Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)
    if ($captured.Count -eq 0) {
        Write-Host "    [$Label] (empty)"
        return
    }
    # A long successful run emits one line per movement-state change. The
    # discovery block sits at the top and the failure reason at the bottom, so
    # keep both ends rather than truncating one of them away.
    if ($captured.Count -le 200) {
        $shown = $captured
    }
    else {
        $shown = $captured[0..119] +
            "... $($captured.Count - 180) line(s) omitted ..." +
            $captured[-60..-1]
    }
    Write-Host "    [$Label] $($captured.Count) line(s):"
    foreach ($line in $shown) {
        Write-Host "      $line"
    }
}

Write-Host 'Starting Crossroads actor mirroring...'

# Actor discovery and placement are allowed to recover independently from the
# player's server session. A transient area load, stale actor, or rejected
# placement must never terminate the wrapper and remove the player from the
# server roster. Restarting within the server's five-second registration window
# preserves the same client identity and session.
while (Get-Process -Id $gameProcess.Id -ErrorAction SilentlyContinue) {
    ++$mirrorLaunchCount
    $mirrorOutPath = Join-Path $mirrorLogDirectory (
        "mirror-$mirrorRunStamp-{0:d3}-out.txt" -f $mirrorLaunchCount)
    $mirrorErrPath = Join-Path $mirrorLogDirectory (
        "mirror-$mirrorRunStamp-{0:d3}-err.txt" -f $mirrorLaunchCount)
    $mirrorStarted = [DateTime]::UtcNow
    $movementProcess = try {
        Start-Process `
            -FilePath $movementExecutable `
            -ArgumentList $movementArguments -NoNewWindow -PassThru `
            -RedirectStandardOutput $mirrorOutPath `
            -RedirectStandardError $mirrorErrPath
    }
    catch {
        $null
    }

    # WHY: Start-Process -PassThru hands back a Process object that has not
    # cached the OS process handle, so .ExitCode reads back as $null forever --
    # measured on this project's own binaries, not assumed. Touching .Handle once
    # makes the runtime cache it and the real exit code becomes readable. Without
    # this the mirror's exit codes (5 = discovery, 9 = ghost changed underneath,
    # 12/13 = write failure) are permanently unavailable to the wrapper.
    if ($movementProcess) {
        try { $null = $movementProcess.Handle } catch {}
    }

    if (-not $movementProcess) {
        ++$movementAttempt
        Write-Host (
            'Crossroads could not start actor mirroring. ' +
            'The server connection is staying active; retrying in one second.'
        ) -ForegroundColor Yellow
        Start-Sleep -Seconds 1
        continue
    }

    while ((Get-Process -Id $gameProcess.Id -ErrorAction SilentlyContinue) -and
        -not $movementProcess.HasExited) {
        Start-Sleep -Milliseconds 250
        $movementProcess.Refresh()
        # The save watcher rides this loop rather than owning a thread or a
        # process of its own. It rate-limits itself to one pass every ten
        # seconds and does nothing at all unless this is a public session, so on
        # every other join it costs one comparison per quarter second.
        Update-CrossroadsSaves
    }

    if (-not (Get-Process -Id $gameProcess.Id -ErrorAction SilentlyContinue)) {
        break
    }

    $movementProcess.WaitForExit()
    $movementProcess.Refresh()
    # WHY: [int]$null evaluates to 0 in PowerShell and does NOT throw, so the
    # previous `try { [int]$_.ExitCode } catch { $null }` silently converted an
    # UNAVAILABLE exit code into a reported 0, which reads as success. The live
    # mirror's only genuine 0 requires completing its full 86400-second run, so
    # every "exit code 0" in earlier logs actually meant "code unknown" and hid a
    # restart loop. Read the raw value and null-check it BEFORE casting.
    $movementExit = $null
    try {
        $rawMovementExit = $movementProcess.ExitCode
        if ($null -ne $rawMovementExit) {
            $movementExit = [int]$rawMovementExit
        }
    }
    catch {
        $movementExit = $null
    }
    $reportedMovementExit = if ($null -eq $movementExit) {
        'unavailable'
    }
    else {
        $movementExit.ToString()
    }
    $mirrorSeconds = [Math]::Round(
        ([DateTime]::UtcNow - $mirrorStarted).TotalSeconds, 1)
    ++$movementAttempt

    # SOME FAILURES CAN NEVER SUCCEED ON A RETRY, AND RETRYING THEM HID ONE FOR
    # A DAY. Exit 1 is "usage printed" and exit 2 is "one or more execution
    # arguments are invalid" -- both are decided entirely by the argument list,
    # which is built once before this loop and never changes. Retrying is
    # therefore guaranteed to fail in exactly the same way, forever.
    #
    # MEASURED 2026-08-14: a join ran this loop 155 times in a row, every
    # attempt dying instantly on exit 2, writing 155 pairs of log files and
    # printing 155 reassuring "retrying automatically" lines. The player is told
    # sync is starting, the wrapper says it is recovering, and nothing will ever
    # happen. That is worse than stopping, because it looks like progress.
    #
    # It does NOT end the session or close the game. The player stays connected
    # and keeps playing -- exactly what happens with sync off -- and the reason
    # is stated once, where somebody will read it.
    # EXIT 3 JOINED THIS LIST ON 2026-08-15, and it belonged here from the day
    # the list was written.
    #
    # 3 is "could not open KotOR" -- Windows refused the mirror permission to
    # read the game process. On a tester's machine that was ERROR_ACCESS_DENIED
    # because the game was running elevated and the launcher was not, and this
    # loop respawned the mirror ONCE A SECOND for as long as the game was open:
    # the same Windows error number every time, a fresh pair of empty log files
    # every time, and nothing anywhere saying what to do about it. The player
    # noticed the file spam before they noticed the message.
    #
    # It is the same shape as 1 and 2 and fails the same test: a permission
    # refusal at one second is a permission refusal at the next. Nothing about
    # waiting changes elevation or an antivirus rule. The mirror now prints what
    # the two causes are and how to fix each; this stops the loop so somebody can
    # read it.
    if ($movementExit -eq 1 -or $movementExit -eq 2 -or $movementExit -eq 3) {
        $why = if ($movementExit -eq 3) {
            'Windows refused Crossroads permission to read KotOR. That is a ' +
            'permission problem on this machine -- see the reason below -- and ' +
            'it cannot clear by itself.'
        }
        else {
            'this is a problem with how the mirror was invoked, not a transient ' +
            'fault.'
        }
        Write-Host (
            "[$([DateTime]::Now.ToString('HH:mm:ss'))] " +
            "Crossroads actor mirroring cannot start (exit code $reportedMovementExit) " +
            "after $mirrorSeconds second(s), and retrying cannot help: $why"
        ) -ForegroundColor Red
        Write-MirrorCapture 'mirror stdout' $mirrorOutPath
        Write-MirrorCapture 'mirror stderr' $mirrorErrPath
        Write-Host (
            'You are still connected and can keep playing; other players will ' +
            'not appear. Attempts: ' + $movementAttempt + '.') -ForegroundColor Yellow
        break
    }

    Write-Host (
        "[$([DateTime]::Now.ToString('HH:mm:ss'))] " +
        "Crossroads actor mirroring paused (exit code $reportedMovementExit) " +
        "after $mirrorSeconds second(s). " +
        'You remain connected; retrying automatically in one second.'
    ) -ForegroundColor Yellow
    Write-MirrorCapture 'mirror stdout' $mirrorOutPath
    Write-MirrorCapture 'mirror stderr' $mirrorErrPath
    Start-Sleep -Seconds 1
}

if ($movementProcess -and -not $movementProcess.HasExited) {
    Stop-Process -Id $movementProcess.Id -Force
    $movementProcess.WaitForExit()
}
# BEFORE the session closes: the final upload sweep needs an open session,
# because "made while connected" is enforced by the service as "there is a
# session open for you right now". This also puts the player's own saves back.
Exit-CrossroadsSaveSession
Close-CrossroadsSession 'closed'
Restore-OwnedFiles
Write-Host 'KotOR closed. Crossroads disconnected and restored its temporary files.'
try { Stop-Transcript | Out-Null } catch {}
exit 0
