# Advertises a player's own co-op server in the Crossroads browser.
#
# ---------------------------------------------------------------------------
# WHY THIS IS A SCRIPT AND NOT PART OF THE LAUNCHER
# ---------------------------------------------------------------------------
#
# The launcher deliberately has no HTTP client, no JSON parser and no OAuth
# surface -- D39 states that plainly and says it "is not being walked back".
# Sign-In-To-Crossroads.ps1 exists for the same reason. So the launcher starts
# this and this talks to the service.
#
# ---------------------------------------------------------------------------
# THE CONTRACT IS NOT INVENTED HERE
# ---------------------------------------------------------------------------
#
# Every field, the cadence and the expiry come from
# `docs/launcher/ACCOUNTS_AND_REGISTRATION.md`, "Registering a server": a
# heartbeat every 30 seconds carrying contract, accountToken, game, name, port,
# capacity and password; no heartbeat for 90 seconds and the row disappears.
# The service enforces its own side -- `HEARTBEAT_MIN_INTERVAL_SECONDS = 10`
# refuses anything faster, and `HEARTBEAT_EXPIRY_SECONDS = 90` is the deadline
# this cadence sits comfortably inside.
#
# THERE IS NO `host` FIELD AND ADDING ONE WOULD BE A DEFECT. The service takes
# the address from the packet source. The document's words: it "is what lets a
# host register somebody else's machine, and it turns the directory into a way
# to point every launcher on the network at a third party."
#
# THE SERVICE DECIDES WHAT KIND OF SERVER THIS IS. A registration cannot claim
# `official` or `community-public` -- self-registered rows are `coop`, by
# construction, in the service. This script could not advertise a public server
# if it tried, which is the property that keeps public servers the owner's.
#
# ---------------------------------------------------------------------------
# IT STOPS ON ITS OWN
# ---------------------------------------------------------------------------
#
# The launcher starts this beside the server and has no "stop advertising"
# button. So this watches the server PROCESS and exits when it is gone -- and
# because the row expires 90 seconds after the last heartbeat, a crashed host,
# a closed console or a killed launcher all stop being advertised without
# anybody tidying up. That is the documented behaviour: "a crashed host stops
# being advertised on its own."

[CmdletBinding()]
param(
    # The catalog id, e.g. kotor1. Travels in the heartbeat as `game`.
    [Parameter(Mandatory = $true)][string]$Game,

    # The UDP port the server is bound to.
    [Parameter(Mandatory = $true)][int]$Port,

    # What the browser will call this row.
    [Parameter(Mandatory = $true)][string]$Name,

    # What the row says it holds. The launcher passes the manifest's own
    # player limit; the service clamps it to the game's declared maximum.
    [int]$Capacity = 0,

    # The process this advertisement belongs to. When it is gone, so is this.
    [Parameter(Mandatory = $true)][string]$ServerProcessName,

    # Where crossroads-network.ini lives. Defaults to beside this script, which
    # is where a deployed install puts both.
    [string]$ConfigPath = '',

    # Seconds between heartbeats. The default is the documented 30; the service
    # refuses anything under 10 and the row expires at 90.
    [int]$IntervalSeconds = 30,

    # Stop after this many heartbeats. For gates only -- 0 means run until the
    # server exits.
    [int]$MaxHeartbeats = 0
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $ConfigPath = Join-Path $PSScriptRoot 'crossroads-network.ini'
}

# A CADENCE OUTSIDE THE SERVICE'S WINDOW IS REFUSED HERE RATHER THAN BY A 429.
# Below 10 seconds every heartbeat after the first is rejected and the row
# expires anyway; above 90 the row is gone between beats. Either way the
# server looks offline while running, which is the failure shape this project
# keeps paying for, so it is caught at the start where it can be read.
if ($IntervalSeconds -lt 10 -or $IntervalSeconds -gt 60) {
    Write-Host ("A heartbeat interval of $IntervalSeconds seconds is outside " +
                'the service window: faster than 10 is refused, and slower ' +
                'than 90 lets the row expire between beats.') -ForegroundColor Red
    exit 2
}

function Read-IniValue {
    param([string]$Section, [string]$Key)
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { return '' }
    $current = ''
    foreach ($line in (Get-Content -LiteralPath $ConfigPath)) {
        $text = $line.Trim()
        if ($text -match '^\[(?<name>[^\]]+)\]$') {
            $current = $Matches['name']
            continue
        }
        if ($current -ne $Section) { continue }
        if ($text -match "^$([regex]::Escape($Key))=(?<value>.*)$") {
            return $Matches['value'].Trim()
        }
    }
    return ''
}

# The same file and the same key Join-Crossroads-KotOR.ps1 reads, reached the
# same way: the per-user profile, never beside the executable.
function Get-CrossroadsAccountToken {
    $accountPath = Join-Path $env:LOCALAPPDATA 'Project Crossroads\account.ini'
    if (-not (Test-Path -LiteralPath $accountPath -PathType Leaf)) { return '' }
    foreach ($line in (Get-Content -LiteralPath $accountPath)) {
        if ($line.Trim() -match '^token=(.*)$') { return $Matches[1].Trim() }
    }
    return ''
}

$serviceUrl = Read-IniValue 'accounts' 'service_url'
if ([string]::IsNullOrWhiteSpace($serviceUrl)) {
    # NOT AN ERROR, and this is the same rule the sign-in flow follows: an
    # install with no [accounts] section is simply not configured for the
    # service. Advertising is the part that does not happen; the server itself
    # runs perfectly well unlisted, and friends can still be given its address.
    Write-Host 'No account service is configured, so this server will not be listed.'
    exit 0
}

$token = Get-CrossroadsAccountToken
if ([string]::IsNullOrWhiteSpace($token)) {
    Write-Host ('Not signed in, so this server will not be listed. Sign in ' +
                'from the launcher and start the server again.')
    exit 3
}

try {
    [Net.ServicePointManager]::SecurityProtocol =
        [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11
}
catch { }

$endpoint = $serviceUrl.TrimEnd('/') + '/register'
$body = @{
    contract     = 'crossroads-registration-v1'
    accountToken = $token
    game         = $Game
    name         = $Name
    port         = $Port
    password     = $false
}
if ($Capacity -gt 0) { $body['capacity'] = $Capacity }

Write-Host ("Advertising '$Name' on port $Port every $IntervalSeconds seconds.")
Write-Host 'It disappears from the browser 90 seconds after this stops.'

$beats = 0
$consecutiveFailures = 0
while ($true) {
    if (-not (Get-Process -Name $ServerProcessName -ErrorAction SilentlyContinue)) {
        Write-Host 'The co-op server has stopped, so advertising stops too.'
        break
    }

    try {
        $response = Invoke-RestMethod -Uri $endpoint -Method Post `
            -ContentType 'application/json' -TimeoutSec 8 -UseBasicParsing `
            -Body ($body | ConvertTo-Json -Compress)
        if ($beats -eq 0) {
            Write-Host 'Listed. Friends can now find this server in the browser.'
        }
        $consecutiveFailures = 0
    }
    catch {
        # THE MESSAGE, NEVER THE BODY. The body carries the account token, and
        # this console belongs to a player who may well screenshot it. Same
        # rule the join script states where it posts.
        $consecutiveFailures++
        $reason = $_.Exception.Message
        # A refusal is worth saying ONCE rather than every 30 seconds. The
        # common ones are worth naming: a server limit reached means this
        # account already has one listed, which is the rule and not a fault.
        if ($consecutiveFailures -eq 1) {
            Write-Host ("Could not list this server: $reason") -ForegroundColor Yellow
            Write-Host ('The server is still running and still joinable by ' +
                        'anyone who has its address.') -ForegroundColor DarkGray
        }
    }

    $beats++
    if ($MaxHeartbeats -gt 0 -and $beats -ge $MaxHeartbeats) { break }
    Start-Sleep -Seconds $IntervalSeconds
}

exit 0
