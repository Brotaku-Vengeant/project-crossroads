# Sends one of the operator's launcher edits to the Crossroads service, then
# refreshes this install's directory cache so the edit shows at once.
#
# ---------------------------------------------------------------------------
# WHY A SCRIPT
# ---------------------------------------------------------------------------
#
# The launcher has no HTTP client, no JSON parser and no OAuth surface (D39), so
# the same pattern as Register-CoopServer.ps1 and the sign-in script: the
# launcher writes what the operator typed to a small JSON request file and
# starts this, and this talks to the service.
#
# THE REQUEST TRAVELS IN A FILE, NOT ON THE COMMAND LINE. What the operator
# typed is free text -- quotes, ampersands, anything -- and building a command
# line out of it is how text becomes code. The launcher writes the file, this
# reads it as data and deletes it.
#
# ---------------------------------------------------------------------------
# WHO MAY EDIT IS NOT DECIDED HERE
# ---------------------------------------------------------------------------
#
# This sends the player's own sign-in token; the service decides, from the
# account behind it, whether that account may edit (state/admins.json on the
# service's machine). A player who runs this by hand is told no by the service.
#
# EXIT CODES, read by the launcher to say what happened:
#   0  the edit was accepted and the cache refreshed
#   2  the request file was missing or unreadable
#   3  not signed in, or no service configured
#   4  the service refused the edit (the reason is printed)
#   5  the service could not be reached
#
# The launcher shows this script's last printed line in its message, so each
# failure path ends with one plain sentence.

[CmdletBinding()]
param(
    # The JSON request the launcher wrote: action, key / id / field, value.
    [Parameter(Mandatory = $true)][string]$RequestPath,

    # Where crossroads-network.ini lives. Defaults to beside this script.
    [string]$ConfigPath = ''
)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $ConfigPath = Join-Path $PSScriptRoot 'crossroads-network.ini'
}

function Read-IniValue([string]$path, [string]$section, [string]$key) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return '' }
    $current = ''
    foreach ($line in (Get-Content -LiteralPath $path)) {
        $text = $line.Trim()
        if ($text -match '^\[(?<name>[^\]]+)\]$') { $current = $Matches['name']; continue }
        if ($current -ne $section) { continue }
        if ($text -match "^$([regex]::Escape($key))=(?<value>.*)$") {
            return $Matches['value'].Trim()
        }
    }
    return ''
}

$request = $null
try {
    $request = Get-Content -LiteralPath $RequestPath -Raw -Encoding UTF8 | ConvertFrom-Json
}
catch {
    Write-Host 'The edit could not be read, so nothing was sent.'
    exit 2
}
finally {
    # Removed whatever happened: it is a one-shot hand-over.
    try { [IO.File]::Delete($RequestPath) } catch { }
}

$serviceUrl = Read-IniValue $ConfigPath 'accounts' 'service_url'
$token = Read-IniValue (Join-Path $env:LOCALAPPDATA 'Project Crossroads\account.ini') 'account' 'token'
if ([string]::IsNullOrWhiteSpace($serviceUrl)) {
    Write-Host 'No Crossroads service is configured, so the edit was not sent.'
    exit 3
}
if ([string]::IsNullOrWhiteSpace($token)) {
    Write-Host 'You are not signed in, so the edit was not sent.'
    exit 3
}

try {
    [Net.ServicePointManager]::SecurityProtocol =
        [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11
}
catch { }

$body = @{ accountToken = $token }
foreach ($field in @('action', 'key', 'id', 'field', 'value', 'name')) {
    if ($null -ne $request.$field) { $body[$field] = [string]$request.$field }
}

$status = 0
$reason = ''
try {
    $null = Invoke-RestMethod -Uri ($serviceUrl.TrimEnd('/') + '/admin/edit') -Method Post `
        -ContentType 'application/json; charset=utf-8' -TimeoutSec 15 -UseBasicParsing `
        -Body ([Text.Encoding]::UTF8.GetBytes(($body | ConvertTo-Json -Compress)))
    $status = 200
}
catch [System.Net.WebException] {
    $response = $_.Exception.Response
    if ($null -eq $response) {
        Write-Host ('The Crossroads service could not be reached: ' + $_.Exception.Message)
        exit 5
    }
    $status = [int]$response.StatusCode
    try {
        $reader = New-Object IO.StreamReader($response.GetResponseStream())
        $reason = [string](($reader.ReadToEnd() | ConvertFrom-Json).error)
        $reader.Close()
    }
    catch { }
}

if ($status -ne 200) {
    # THE MESSAGE, NEVER THE BODY: the body carries the account token.
    if ($status -eq 403) {
        Write-Host 'The service says this account may not edit the launcher.'
    }
    elseif ($reason) {
        Write-Host ("The service refused the edit: $reason")
    }
    else {
        Write-Host ("The service refused the edit (HTTP $status).")
    }
    exit 4
}

# THE CACHE IS REFRESHED AT ONCE, through the rate limit, so the operator sees
# the edit now rather than at the next timed refresh.
$fetcher = Join-Path $PSScriptRoot 'Get-CrossroadsDirectory.ps1'
if (Test-Path -LiteralPath $fetcher -PathType Leaf) {
    & $fetcher -Force | Out-Null
}
Write-Host 'Saved. Every launcher shows it from its next refresh.'
exit 0
