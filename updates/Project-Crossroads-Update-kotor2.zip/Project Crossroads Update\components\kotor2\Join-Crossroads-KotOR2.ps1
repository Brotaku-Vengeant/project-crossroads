[CmdletBinding()]
param(
    [string]$GameDirectory = '',

    # WHERE TO JOIN, supplied by the launcher.
    #
    # These exist because the server browser can now list servers this install
    # has never been configured for. Before Stage 5 the destination could only
    # come from crossroads-network.ini, so a browser that showed ten servers
    # could only ever join one of them.
    #
    # BOTH DEFAULT TO THE INI when absent, so an existing invocation -- a
    # tester double-clicking, an older launcher, the diagnostics path -- keeps
    # working unchanged.
    #
    # THERE WAS A THIRD, -ServerSession, AND IT IS GONE (2026-08-15). It carried
    # a join code, which no longer exists anywhere: no config key holds one, no
    # relay checks one, and the mirror has no argument to receive one. An older
    # launcher passing it fails loudly here rather than being quietly ignored,
    # because a launcher old enough to send it is also old enough to be running
    # against a mirror whose command line it no longer matches.
    [string]$ServerHost = '',
    [int]$ServerPort = 0,

    # THIS MACHINE IS HOSTING THE SESSION IT IS JOINING (D85, 2026-10-21).
    #
    # TOLD BY THE LAUNCHER, NOT WORKED OUT HERE. The host half of the save
    # handoff used to be gated on "the directory classified this `coop` AND a
    # relay is running locally" -- two inferences that are usually right. Since
    # the owner's rule bound the relay's lifetime to the game's, the launcher is
    # the thing that STARTED the relay a moment ago, so it knows for certain.
    #
    # ABSENT MEANS NOT HOSTING, which keeps every existing invocation working:
    # an older launcher, a tester double-clicking, the diagnostics path.
    [switch]$CoopHost,

    # WHAT GUESTS SEE THE SERVER AS -- deliberately not $ServerHost.
    #
    # A host connects to 127.0.0.1, because that always works whatever the
    # network is doing. But a guest's handoff request is filed against the
    # address IT used, so the host has to look under that address to find
    # anybody waiting. These are two different things and treating them as one
    # is the bug: a host on loopback would poll for requests against
    # "127.0.0.1:39131" and never find the ones filed against its real address.
    #
    # EMPTY IS LEGITIMATE. A server nobody has listed has no public address, so
    # nothing can be waiting for it and there is nothing to poll for.
    [string]$CoopServerId = '',

    # ANYTHING THIS BUILD DOES NOT KNOW, SWALLOWED RATHER THAN FATAL.
    #
    # MEASURED 2026-10-22, the first real co-op launch. The launcher updated to
    # 202610211354 and began passing -CoopHost and -CoopServerId; the kotor1
    # COMPONENT was still 202610201933 and had neither parameter. PowerShell
    # binds parameters BEFORE the script body runs, so Start-Transcript never
    # executed, NOTHING was written to the log, the console flashed shut, and
    # the game never appeared -- while the relay kept running, which made it
    # look like the server had started correctly.
    #
    # WHY THIS IS THE RIGHT SHAPE AND NOT JUST A PATCH. The platform and each
    # game are separate update tracks (D33), so a NEWER launcher meeting an
    # OLDER join is a permanent possibility, not a one-off. CLAUDE.md's ACCEPT
    # BEFORE EMIT rule asks one question before shipping: *what does an OLD
    # client do when it meets this?* The answer here was "dies before it can
    # say anything", which is the worst of the three outcomes the rule names.
    # With this, the answer becomes "ignores what it does not understand and
    # runs" -- and says so, because a silently dropped argument is how a
    # feature appears to be on while doing nothing.
    #
    # IT IS NOT A LICENCE TO BE SLOPPY. The launcher still updates the component
    # before launching (EnsureGameComponent), so this is the floor rather than
    # the plan.
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$UnknownArguments = @()
)

$ErrorActionPreference = 'Stop'

# ---- WHERE THIS SCRIPT IS, AND WHERE THE LAUNCHER IS ------------------------
#
# These were the same directory until 2026-10-07 and the script treated them as
# one thing. They are about to stop being the same.
#
# WHY. This file ships in the PLATFORM archive, so every edit to it moves the
# manifest's top-level build -- and that build is what every launcher compares
# itself against, so a KotOR-only change prompts every player of every game to
# take a launcher update. That is exactly what D33's split exists to prevent, and
# this file is the only one of the three KotOR files still in platform that
# actually churns: thirteen commits in the six weeks to 2026-09-30, against none
# since early August for the other two. So it moves to components\kotor1 and the
# other two stay.
#
# SIX THINGS WERE RESOLVED FROM ONE VARIABLE, and moving the file would have
# broken all of them -- `components\kotor1` (a CHILD of the launcher root),
# `crossroads-network.ini`, `state\kotor1`, `crossroads-launcher.ini`, this log,
# and `Get-KotorRetailResource.ps1`. Two of those fail SILENTLY rather than
# loudly: a missing crossroads-launcher.ini means every setting in it is ignored
# with no message, which `CLAUDE.md` already records as a trap, and a wrong
# `state\kotor1` means the save-swap record and the backups are written somewhere
# nothing will look for them.
#
# SO THE TWO ARE SEPARATED HERE, AND THIS WORKS IN EITHER LOCATION. $here is this
# script; $root is the launcher. A copy sitting in the launcher root -- which is
# where it still is as this ships -- gets the same answer it always did, so this
# change is verifiable BEFORE the file moves rather than only after.
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = $here
$hereLeaf = Split-Path -Leaf $here
$hereParentLeaf = Split-Path -Leaf (Split-Path -Parent $here)
if ($hereLeaf -eq 'kotor2' -and $hereParentLeaf -eq 'components') {
    # Two levels up from components\kotor1 is the launcher directory.
    $root = Split-Path -Parent (Split-Path -Parent $here)
}

# WHERE Get-KotorRetailResource.ps1 ACTUALLY IS, resolved once.
#
# THIS WAS A LIVE DEFECT, measured 2026-10-20: every KotOR join failed with
# "Get-KotorRetailResource.ps1 is missing from the Crossroads package" on any
# machine whose Override lacked cr_orig_hb.ncs -- which is every fresh install,
# and every machine after one failed join, because the failure cleanup removes
# that file and the next join then needs the extractor again. A permanent loop.
#
# THE CAUSE WAS AN ASSUMPTION WRITTEN DOWN AND THEN FALSIFIED BY PACKAGING. The
# 2026-10-07 split (ca5c49f0) moved five of six resolutions to $root and left
# this one on $here, with a comment saying the extractor "moves with it". The
# header comment eleven lines above said the opposite -- that the other two
# KotOR files STAY in platform -- and packaging followed the header. So the
# script moved to components\kotor1 and the extractor did not, and two comments
# in one file disagreed while the code followed the wrong one.
#
# $root FIRST, $here SECOND, because that order is true in every layout that
# exists or is planned: the extractor ships at the launcher root today, and if
# it is ever moved in beside this script the sibling lookup finds it without
# another edit. Neither found leaves this $null and the caller reports it.
$retailResourceScript = $null
foreach ($candidate in @(
        (Join-Path $root 'Get-KotorRetailResource.ps1'),
        (Join-Path $here 'Get-KotorRetailResource.ps1'))) {
    if (Test-Path -LiteralPath $candidate -PathType Leaf) {
        $retailResourceScript = $candidate
        break
    }
}
# CROSSROADS-PATH-PROLOGUE-END -- do not remove or move this line.
# tools\Test-KotorStage1Lifecycle.ps1 lifts everything from the $here
# assignment down to here and RUNS it against fake directory trees, so the
# layout that ships is exercised rather than reasoned about. The marker exists
# because the gate first tried to find the end of this block by counting braces
# and got it wrong the moment the shape changed.

$logPath = Join-Path $root 'kotor-client-log.txt'
# THE PREVIOUS SESSION'S LAST LINES, read BEFORE this session starts appending
# to the same file, so they are the last session's and not this one's. Sent to
# the service at the start of a co-op join -- see Send-CrossroadsLastSessionReport.
$script:lastJoinLogTail = ''
try {
    if (Test-Path -LiteralPath $logPath) {
        $script:lastJoinLogTail =
            (Get-Content -LiteralPath $logPath -Tail 60 -ErrorAction Stop) -join "`n"
    }
}
catch { }
try {
    Start-Transcript -LiteralPath $logPath -Append -Force | Out-Null
}
catch {
    # Joining can continue even if Windows cannot create the optional log.
}
trap {
    $trapError = $_
    Write-Host ''
    Write-Host 'CROSSROADS KOTOR COULD NOT CONTINUE' -ForegroundColor Red
    Write-Host '===================================' -ForegroundColor Red
    Write-Host $trapError.Exception.Message -ForegroundColor Red
    Write-Host ''
    Write-Host "Diagnostic log: $logPath"

    # AND OVER THE WIRE, FROM HERE, BECAUSE A FAILING JOIN NEVER REACHES THE
    # NORMAL SEND (2026-10-27). PC3's join died on every attempt with one red
    # line and a window that closed before it could be read; the previous-session
    # report goes out much later in the script, so it never went at all. This is
    # self-contained on purpose: a trap can fire before any helper function in
    # this script has been defined, so it reads the token and the service URL
    # itself. Best effort, and it says which way it went.
    try {
        $trapToken = ''
        $trapAccount = Join-Path $env:LOCALAPPDATA 'Project Crossroads\account.ini'
        if (Test-Path -LiteralPath $trapAccount) {
            foreach ($trapLine in (Get-Content -LiteralPath $trapAccount)) {
                if ($trapLine.Trim() -match '^token=(.*)$') { $trapToken = $Matches[1].Trim() }
            }
        }
        $trapService = ''
        $trapIni = Join-Path $root 'crossroads-network.ini'
        if (Test-Path -LiteralPath $trapIni) {
            $trapInAccounts = $false
            foreach ($trapLine in (Get-Content -LiteralPath $trapIni)) {
                $trapTrimmed = $trapLine.Trim()
                if ($trapTrimmed -match '^\[(.+)\]$') {
                    $trapInAccounts = ($Matches[1] -eq 'accounts'); continue
                }
                if ($trapInAccounts -and $trapTrimmed -match '^service_url\s*=\s*(.+)$') {
                    $trapService = $Matches[1].Trim()
                }
            }
        }
        if ($trapToken -and $trapService) {
            $trapText = ("role=failed-join sent={0:s}`n== THIS JOIN STOPPED: {1}`n== at:{2}`n" +
                         "== script stack:`n{3}`n== this join's log so far:`n") -f
                (Get-Date), $trapError.Exception.Message,
                $trapError.InvocationInfo.PositionMessage, $trapError.ScriptStackTrace
            $trapText += ((Get-Content -LiteralPath $logPath -Tail 40 -ErrorAction SilentlyContinue) -join "`n")
            # Cut from the END: the error and where it happened come first.
            if ($trapText.Length -gt 9000) { $trapText = $trapText.Substring(0, 9000) }
            Invoke-WebRequest -Uri ($trapService.TrimEnd('/') + '/diag/report') `
                -Method Post -ContentType 'application/json' -TimeoutSec 15 `
                -UseBasicParsing -Body (@{
                    accountToken = $trapToken; source = 'kotor2-join-failed'
                    report = $trapText } | ConvertTo-Json -Compress) | Out-Null
            Write-Host 'This failure was sent to the Crossroads service.'
        }
        else {
            Write-Host 'This failure was NOT sent: this machine is not signed in to Crossroads.' `
                -ForegroundColor DarkYellow
        }
    }
    catch {
        Write-Host "Could not send this failure to the Crossroads service: $($_.Exception.Message)" `
            -ForegroundColor DarkYellow
    }
    $runningKotor = Get-Process 'swkotor2' -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if ($runningKotor) {
        Write-Host ''
        Write-Host 'Close KotOR WITHOUT SAVING. Crossroads will clean up automatically.' `
            -ForegroundColor Yellow
        while (Get-Process 'swkotor2' -ErrorAction SilentlyContinue) {
            Start-Sleep -Milliseconds 500
        }
    }
    # Closed on the failure path too, and with a reason that says so. Without
    # this, every crashed or refused join would leave a session open until the
    # service's abandoned sweep closed it twelve hours later -- which would make
    # every future playtime figure wrong in the same direction.
    # THE PLAYER'S OWN SAVES COME BACK FIRST ON THIS PATH, AND NOTHING IS
    # UPLOADED. They are parked under another name for the length of a public
    # session; putting them back is a rename and takes no time, while a final
    # upload sweep is megabytes over a tunnel. A player who has just been shown a
    # red error is the one most likely to close the window rather than wait, and
    # the cost of the two choices is not symmetric: losing the last save of a
    # join that already failed is a small loss, and leaving somebody's saves
    # parked under a name they do not know is a large one.
    if (Get-Command Exit-CrossroadsSaveSession -ErrorAction SilentlyContinue) {
        Exit-CrossroadsSaveSession -RestoreOnly
    }
    if (Get-Command Close-CrossroadsSession -ErrorAction SilentlyContinue) {
        Close-CrossroadsSession 'crashed'
    }
    if (Get-Command Restore-OwnedFiles -ErrorAction SilentlyContinue) {
        Restore-OwnedFiles
        Write-Host 'KotOR files restored. This window will close automatically.'
    }
    try { Stop-Transcript | Out-Null } catch {}
    # LONG ENOUGH TO READ (2026-10-27). The owner, watching PC3: "one line of
    # bold red text then closed before I could see what it said". A timed wait
    # rather than a key press: the launcher can run this without a console
    # anyone is sitting at, and a prompt there would hold the join open for ever.
    Write-Host ''
    Write-Host 'This window closes in 60 seconds.'
    Start-Sleep -Seconds 60
    exit 1
}

$component = Join-Path $root 'components\kotor2'
$configPath = Join-Path $root 'crossroads-network.ini'
$state = Join-Path $root 'state\kotor2'
$localState = Join-Path $state 'local'
$remoteState = Join-Path $state 'remote'
$backup = Join-Path $state 'backup'
$installRecord = Join-Path $state 'install-state.json'

function Read-IniValue {
    param([string]$Section, [string]$Key)
    $current = ''
    foreach ($line in Get-Content -LiteralPath $configPath) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') {
            $current = $Matches[1]
            continue
        }
        if ($current -eq $Section -and
            $trimmed -match ('^' + [regex]::Escape($Key) + '=(.*)$')) {
            return $Matches[1].Trim()
        }
    }
    throw "Missing [$Section] $Key in crossroads-network.ini."
}

function Read-OptionalIniValue {
    param([string]$Section, [string]$Key)
    try {
        return Read-IniValue $Section $Key
    }
    catch {
        return ''
    }
}

# ---- the session record -----------------------------------------------------
#
# Tells the Crossroads service that this account started playing, and tells it
# again when they stop. Everything an account will ever show -- games played,
# and later playtime -- is derived from these two calls. See
# docs\PLAN_2026-08-13-user-records.md.
#
# NOTHING HERE MAY STOP SOMEBODY PLAYING. Every call is best-effort with a short
# timeout, every failure is logged and swallowed, and none of it is on the path
# that launches the game. A record-keeping feature that can prevent a join would
# be a terrible trade, and it is the kind of thing that only shows up when the
# service is down and everybody is trying to play at once.
#
# IT DOES NOTHING AT ALL when accounts are not configured, which is every install
# in the field. Same switch as the join gate and the launcher's sign-in control.
$script:crossroadsSessionId = ''
# What KIND of server this session is on, as the SERVICE decided it -- never as
# this script guessed. Empty until a session opens, and empty forever on an
# install with no account configured, which is every install in the field. The
# save rule reads this and nothing else.
$script:crossroadsSessionClassification = ''

function Get-CrossroadsAccountToken {
    # Written by Sign-InToCrossroads.ps1, in the per-user profile directory --
    # never beside the executable, which in a managed install is shared.
    $accountPath = Join-Path $env:LOCALAPPDATA 'Project Crossroads\account.ini'
    if (-not (Test-Path -LiteralPath $accountPath -PathType Leaf)) { return '' }
    foreach ($line in (Get-Content -LiteralPath $accountPath)) {
        if ($line.Trim() -match '^token=(.*)$') { return $Matches[1].Trim() }
    }
    return ''
}

function Invoke-CrossroadsRecords {
    param([string]$Path, [hashtable]$Body)
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $null }
    try {
        [Net.ServicePointManager]::SecurityProtocol =
            [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11
    }
    catch { }
    try {
        return Invoke-RestMethod -Uri ($serviceUrl.TrimEnd('/') + $Path) `
            -Method Post -ContentType 'application/json' -TimeoutSec 8 `
            -UseBasicParsing -Body ($Body | ConvertTo-Json -Compress)
    }
    catch {
        # The message, never the body we sent -- that carries the account token.
        Write-Host ("Crossroads could not reach the account service ($Path). " +
                    'Play continues; this session will not be recorded.') `
            -ForegroundColor DarkGray
        return $null
    }
}

function Open-CrossroadsSession {
    param([string]$GameId, [string]$ServerHost, [uint16]$ServerPort)
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return }
    # WHERE they played is recorded; WHAT KIND of server it was is not claimed
    # here. The service decides classification for itself and records
    # `unverified` when it does not recognise the address -- a client that could
    # name its own classification could call itself an official server, and
    # playtime is meant to count official servers only.
    $response = Invoke-CrossroadsRecords '/session/open' @{
        accountToken = $token
        game = $GameId
        serverId = ("{0}:{1}" -f $ServerHost, $ServerPort)
    }
    if ($response -and $response.sessionId) {
        $script:crossroadsSessionId = [string]$response.sessionId
        $script:crossroadsSessionClassification =
            [string]$response.classification
    }
}

function Close-CrossroadsSession {
    param([string]$Reason = 'closed')
    if ([string]::IsNullOrWhiteSpace($script:crossroadsSessionId)) { return }
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return }
    $sessionId = $script:crossroadsSessionId
    # CLEARED FIRST, so this is safe to call twice. It is called from the normal
    # exit AND from the failure path, and those can both run -- a second close
    # would be answered 404 by the service and print a confusing line about the
    # service being unreachable when it is fine.
    $script:crossroadsSessionId = ''
    Invoke-CrossroadsRecords '/session/close' @{
        accountToken = $token
        sessionId = $sessionId
        reason = $Reason
    } | Out-Null
}

# ---- saves on a public server ------------------------------------------------
#
# THE OWNER'S RULE: on official and community-public servers a player may use
# only saves made while connected, and only the five most recent. A sixth deletes
# the oldest. A first public join needs a fresh character. Private and co-op are
# unrestricted. See docs\PLAN_2026-08-13-user-records.md section 6.
#
# HOW THAT IS MADE TRUE ON DISK, because recording saves is not the same as
# enforcing the rule: for the length of a public session the player's own saves
# folder is PARKED under another name and an empty one is put in its place,
# holding only the saves the service has recorded. So:
#
#   - "only saves made while connected are usable" is not a check that can be
#     bypassed; the other saves are not there to load.
#   - "a first public join needs a fresh character" needs no mechanism at all.
#     Nothing is downloaded because nothing is recorded, so the folder is empty
#     and the only thing the player can do is start a new game.
#
# PARKED BY RENAME, NEVER COPIED AND NEVER DELETED. A rename is atomic, it is
# reversible, and it never has two copies of a save that could diverge. The
# player's own saves are the most valuable thing on their disk and nothing here
# writes into them, reads them destructively, or removes them.
#
# AND IT IS RESTORED EVEN IF THIS SCRIPT IS KILLED. The swap is written to a
# record file before it happens, and the next join restores from that record
# before doing anything else -- the same shape as the Override file restore, and
# for the same reason: the abnormal exit is the case that matters.
try {
    # Loaded once, here, rather than at each use. Present in every PowerShell
    # version this project targets, but not loaded by default in 5.1.
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
}
catch {
    # Without it the save rule cannot pack or unpack anything. Not fatal on its
    # own -- the join continues and Enter-CrossroadsSaveSession will fail to
    # unpack, which is reported there rather than stopping a player joining.
    Write-Host 'Crossroads could not load the compression library for saves.' `
        -ForegroundColor DarkGray
}

$script:crossroadsSavesActive = $false
$script:crossroadsSavesFolder = ''
$script:crossroadsSaveFingerprints = @{}
$script:crossroadsSaveUploaded = @{}
$script:crossroadsSaveNextTick = [DateTime]::MinValue
$saveSwapRecord = Join-Path $state 'save-swap.json'
$saveWorkRoot = Join-Path $state 'save-work'

# A slot name arrives from the SERVICE, which stores whatever a client sent as
# display text -- so it is attacker-controlled by the time it comes back, and it
# is about to become a folder name on this machine. Anything that is not a plain
# save-folder name is refused rather than repaired.
$script:crossroadsSlotPattern = '^[A-Za-z0-9][A-Za-z0-9 ._\-]{0,63}$'

# ---- player sync: ONE PATH, NO SWITCH ----------------------------------------
#
# THE OLD LIFECYCLE AND ITS KILL SWITCH ARE DELETED HERE (Stage 1). Owner,
# 2026-08-15: *"we build a new god damn lifecycle"* -- *"delete it, kill the
# switch, build it whole."*
#
# WHAT WENT, AND WHY EACH ONE HAD TO:
#
#   `player_sync` / `identity_from_save`  Developer kill switches from the reset
#       (D62), read from `crossroads-launcher.ini` -- a file that ships in NONE
#       of the update archives. A setting that cannot travel is a setting two
#       machines silently disagree about, each seeing nobody, with "the fix did
#       not work" as the obvious wrong conclusion (register 51). Whether a
#       session replicates players is the SERVER's business, not a per-client
#       preference (D76); until the server says so, there is one path and
#       everyone is on it.
#
#   `Get-PlayerSave` / `New-CappedIdentitySave` / `Get-EquippedItemCount` /
#   `New-GenericIdentity`, the pre-launch identity exchange, and the
#   apply-identity step
#       THE ROOT FAULT, register 39, and the reason the first attempt was reset
#       (D58): they decided which character the world would see by SCANNING THE
#       SAVES FOLDER BEFORE THE GAME STARTED. The character replicated to
#       everybody was never the one the player went on to choose. Nothing here
#       reads a save to decide who anybody is, ever again.
#
#   The PowerShell presence sender ("on the server without syncing anything")
#       It existed only to keep a player on the roster while the sync-off branch
#       ran, and it CANNOT coexist with the mirror. The relay migrates a peer to
#       whichever socket spoke last -- `games/kotor1/server/src/main.cpp`, and
#       the comment there says so deliberately, for the identity helper. Two
#       registrations under one client id from two sockets means the roster
#       address flaps, and every snapshot the relay routes in the gap goes to a
#       socket nothing reads. A quiet, partial, intermittent loss: the worst
#       shape of fault this project keeps buying.
#
#       CONSEQUENCE, STATED RATHER THAN DISCOVERED: while a player is at the
#       menu or on a loading screen, the relay no longer knows they exist, so
#       they are not on its roster and not in the HUD's count. That is exactly
#       what Connected means in PLAN §4 -- on the server, visible to nobody --
#       and nothing today reads that roster for anything else. Playtime is
#       deliberately not reported and waits on the signed ticket regardless.
#
# WHAT REMAINS is one path, run for every join: sign in, record the session,
# apply the save rule, install the extender and the Override payloads, launch
# KotOR, and run the mirror. Who you are comes from the LIVE character through
# the extender -- the one identity-adjacent path that has never had an identity
# problem.
#
# WHERE RULE 1 IS ENFORCED, because it is NOT here. Nothing in this script can
# make a player visible: the mirror registers with the relay only once there is
# a player standing in a known module at a position the engine has actually
# written (`IsPresent`, live_mirror). Launching the game is not being in the
# world, and this script no longer pretends otherwise.

function Test-CrossroadsSaveRuleEnabled {
    # ON by default, per the owner's decision 2026-08-13. The switch exists so it
    # can be turned OFF on one machine without a rebuild, and it is read from
    # crossroads-launcher.ini FIRST because crossroads-network.ini is
    # updater-managed and anything hand-edited there is overwritten by the next
    # update -- the same trap the HUD capacity setting documents further down.
    $launcherConfigPath = Join-Path $root 'crossroads-launcher.ini'
    $configured = ''
    if (Test-Path -LiteralPath $launcherConfigPath -PathType Leaf) {
        $current = ''
        foreach ($line in Get-Content -LiteralPath $launcherConfigPath) {
            $trimmed = $line.Trim()
            if ($trimmed -match '^\[(.+)\]$') { $current = $Matches[1]; continue }
            if ($current -eq 'kotor2' -and $trimmed -match '^save_sync=(.*)$') {
                $configured = $Matches[1].Trim()
                break
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($configured)) {
        $configured = Read-OptionalIniValue 'kotor2' 'save_sync'
    }
    return ($configured -notmatch '^(?i)(off|false|0|no)$')
}

function Test-CrossroadsPublicSession {
    return @('official', 'community-public') -contains
        $script:crossroadsSessionClassification
}

function Get-CrossroadsFolderFingerprint {
    param([string]$Path)
    # Name, length and last-write time of every file, in a fixed order. This is
    # what decides whether a save has stopped being written to; it is NOT a
    # content hash, because hashing six megabytes every ten seconds during play
    # is a cost with no matching benefit -- the upload hashes for real.
    $parts = Get-ChildItem -LiteralPath $Path -File -ErrorAction SilentlyContinue |
        Sort-Object Name |
        ForEach-Object { '{0}|{1}|{2}' -f $_.Name, $_.Length, $_.LastWriteTimeUtc.Ticks }
    return ($parts -join ';')
}

function Invoke-CrossroadsSaveUpload {
    param([string]$SlotName, [string]$ZipPath)
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $false }
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return $false }
    try {
        $bytes = [IO.File]::ReadAllBytes($ZipPath)
        $sha = (Get-FileHash -LiteralPath $ZipPath -Algorithm SHA256).Hash.ToLower()
        $request = [Net.HttpWebRequest]::Create(
            $serviceUrl.TrimEnd('/') + '/save/upload')
        $request.Method = 'POST'
        $request.ContentType = 'application/zip'
        # Generous compared with the session calls: this is megabytes over a
        # tunnel, not a few hundred bytes. Still bounded, because nothing here
        # may hold up a player who is trying to quit.
        $request.Timeout = 60000
        $request.ReadWriteTimeout = 60000
        # THE CREDENTIALS TRAVEL IN HEADERS because the body is the archive.
        # Never in the URL -- that is the part of a request that ends up in
        # access logs and proxy logs.
        $request.Headers.Add('X-Crossroads-Token', $token)
        $request.Headers.Add('X-Crossroads-Session', $script:crossroadsSessionId)
        $request.Headers.Add('X-Crossroads-Game', 'kotor2')
        $request.Headers.Add('X-Crossroads-Slot', $SlotName)
        $request.Headers.Add('X-Crossroads-Sha256', $sha)
        $request.ContentLength = $bytes.Length
        $stream = $request.GetRequestStream()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Close()
        $response = $request.GetResponse()
        $reader = New-Object IO.StreamReader($response.GetResponseStream())
        $answer = $reader.ReadToEnd()
        $reader.Close()
        $response.Close()
        # The service says which slots this upload pushed out of the five, and
        # they are removed from the game folder here. See
        # Remove-CrossroadsEvictedSave for why that is done at all.
        try {
            $parsed = $answer | ConvertFrom-Json
            if ($parsed -and $parsed.evictedSlots) {
                foreach ($gone in @($parsed.evictedSlots)) {
                    Remove-CrossroadsEvictedSave ([string]$gone) $SlotName
                }
            }
        }
        catch { }
        return $true
    }
    catch {
        # The message only, never the request -- that carries the account token.
        Write-Host ("Crossroads could not upload the save '$SlotName'. " +
                    'Play continues; it will be retried.') -ForegroundColor DarkGray
        return $false
    }
}

function Remove-CrossroadsEvictedSave {
    param([string]$SlotName, [string]$JustUploaded)
    # DELETING A PLAYER'S SAVE FILE WHILE THEIR GAME IS RUNNING. That is what
    # this does, so it is worth being plain about why and about every guard.
    #
    # WHY: eviction used to happen only on the service. The owner made six saves
    # in one session and KotOR listed all six, because nothing had removed
    # anything from the game folder -- so "only the five most recent are usable"
    # was true across joins and visibly false within one, and the sixth save was
    # still loadable. The owner chose to make the rule true at all times.
    #
    # THE GUARDS, and each one is load-bearing:
    #
    #  - it does nothing unless a public session is active, so it can never run
    #    against an ordinary single-player saves folder;
    #  - it deletes only inside the SESSION folder, never the parked one holding
    #    the player's own characters;
    #  - the slot name comes back from the service, which stores whatever a
    #    client sent as display text, so it is checked against the same pattern
    #    used when unpacking -- it must be a plain folder name or nothing
    #    happens;
    #  - it refuses to delete the save that was just uploaded. The service does
    #    not report a REWRITTEN slot as evicted, so this should be unreachable;
    #    it is here because the cost of that being wrong once is the player's
    #    newest save, and the check is one comparison.
    if (-not $script:crossroadsSavesActive) { return }
    if ([string]::IsNullOrWhiteSpace($SlotName)) { return }
    if ($SlotName -notmatch $script:crossroadsSlotPattern) { return }
    if ($SlotName -eq $JustUploaded) { return }

    $target = Join-Path $script:crossroadsSavesFolder $SlotName
    if (-not (Test-Path -LiteralPath $target -PathType Container)) { return }
    try {
        Remove-Item -LiteralPath $target -Recurse -Force
        $script:crossroadsSaveFingerprints.Remove($SlotName)
        $script:crossroadsSaveUploaded.Remove($SlotName)
        Write-Host ("Crossroads removed the oldest save '$SlotName' -- this " +
                    'server keeps your five most recent.') -ForegroundColor DarkGray
    }
    catch {
        # A failure here costs nothing: the save is already gone from the
        # service, so it will not come back on the next join either way.
        Write-Host ("Crossroads could not remove the evicted save '$SlotName'.") `
            -ForegroundColor DarkGray
    }
}

function Get-CrossroadsRecordedSaves {
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return @() }
    $listed = Invoke-CrossroadsRecords '/save/list' @{
        accountToken = $token
        game = 'kotor2'
    }
    if (-not $listed -or -not $listed.saves) { return @() }
    return @($listed.saves)
}

function Invoke-CrossroadsSaveFetch {
    param([string]$SaveId, [string]$Destination)
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $false }
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return $false }
    try {
        $request = [Net.HttpWebRequest]::Create(
            $serviceUrl.TrimEnd('/') + '/save/fetch')
        $request.Method = 'POST'
        $request.ContentType = 'application/json'
        $request.Timeout = 60000
        $request.ReadWriteTimeout = 60000
        $payload = [Text.Encoding]::UTF8.GetBytes(
            (@{ accountToken = $token; saveId = $SaveId } | ConvertTo-Json -Compress))
        $request.ContentLength = $payload.Length
        $stream = $request.GetRequestStream()
        $stream.Write($payload, 0, $payload.Length)
        $stream.Close()
        $response = $request.GetResponse()
        $target = [IO.File]::Open($Destination, [IO.FileMode]::Create)
        try { $response.GetResponseStream().CopyTo($target) }
        finally { $target.Close(); $response.Close() }
        return $true
    }
    catch {
        Write-Host 'Crossroads could not download one of your recorded saves.' `
            -ForegroundColor DarkGray
        return $false
    }
}

function Restore-CrossroadsSaves {
    # Put the player's own saves back. Safe to call at any time, including when
    # no swap ever happened, and safe to call twice.
    if (-not (Test-Path -LiteralPath $saveSwapRecord -PathType Leaf)) { return }
    $record = $null
    try {
        $record = Get-Content -LiteralPath $saveSwapRecord -Raw | ConvertFrom-Json
    }
    catch {
        # An unreadable record is not a reason to leave the player's saves
        # parked. Say so loudly -- this is the one failure in the whole feature
        # that a player would notice as "my saves are gone".
        Write-Host ('CROSSROADS COULD NOT READ ITS SAVE RECORD. If your KotOR ' +
                    'saves folder looks empty, the original is beside it under ' +
                    'a name starting "saves.crossroads".') -ForegroundColor Red
        return
    }
    if ($record -and $record.parked -and (Test-Path -LiteralPath $record.parked)) {
        # The SESSION folder goes first, then the rename back. If this is
        # interrupted between the two, the record is still on disk and the next
        # join runs this again.
        if ($record.live -and (Test-Path -LiteralPath $record.live)) {
            Remove-Item -LiteralPath $record.live -Recurse -Force `
                -ErrorAction SilentlyContinue
        }
        try {
            Move-Item -LiteralPath $record.parked -Destination $record.live -Force
            Write-Host 'Crossroads restored your own KotOR saves.'
        }
        catch {
            Write-Host ("CROSSROADS COULD NOT RESTORE YOUR SAVES AUTOMATICALLY. " +
                        "They are safe at: $($record.parked)") -ForegroundColor Red
            return
        }
    }
    Remove-Item -LiteralPath $saveSwapRecord -Force -ErrorAction SilentlyContinue
    $script:crossroadsSavesActive = $false
}

function Enter-CrossroadsSaveSession {
    param([string]$Game)
    if (-not (Test-CrossroadsPublicSession)) { return }
    if (-not (Test-CrossroadsSaveRuleEnabled)) {
        Write-Host ('The public save rule is switched off on this install; ' +
                    'your own saves are being used.') -ForegroundColor Yellow
        return
    }

    $live = Join-Path $Game 'saves'
    $parked = Join-Path $Game 'saves.crossroads-offline'
    if (Test-Path -LiteralPath $parked) {
        # A previous run parked saves and its record was lost. Refuse rather
        # than overwrite: whatever is in there is somebody's character.
        throw ("Crossroads found a parked saves folder from an earlier session " +
               "at $parked. Move or rename it before joining a public server.")
    }

    New-Item -ItemType Directory -Force -Path $saveWorkRoot | Out-Null
    # WRITTEN BEFORE THE RENAME, not after. If this script dies between the two
    # the record describes a swap that did not happen, and the restore finds no
    # parked folder and simply clears the record. The other order would leave a
    # parked folder nothing knows about.
    $record = @{ live = $live; parked = $parked
                 stamped = (Get-Date).ToString('o') } | ConvertTo-Json
    [IO.File]::WriteAllText($saveSwapRecord, $record,
        (New-Object Text.UTF8Encoding($false)))

    if (Test-Path -LiteralPath $live) {
        Move-Item -LiteralPath $live -Destination $parked -Force
    }
    New-Item -ItemType Directory -Force -Path $live | Out-Null
    $script:crossroadsSavesActive = $true
    $script:crossroadsSavesFolder = $live

    Write-Host ''
    Write-Host 'PUBLIC SERVER SAVE RULE' -ForegroundColor Cyan
    Write-Host ('On this server you can use only saves made while connected. ' +
                'Your own saves are parked and come back when you leave.')

    $recorded = Get-CrossroadsRecordedSaves
    $restoredCount = 0
    foreach ($save in $recorded) {
        $slot = [string]$save.slot
        if ($slot -notmatch $script:crossroadsSlotPattern) {
            # The service stores a slot name as text and does not constrain it to
            # something that is safe as a folder name here. Refused rather than
            # sanitised -- a repaired name is a guess, and this one becomes a
            # path on the player's disk.
            Write-Host ('Skipped a recorded save whose name cannot be used as a ' +
                        'folder.') -ForegroundColor DarkGray
            continue
        }
        $archive = Join-Path $saveWorkRoot ('fetch-' + [Guid]::NewGuid().ToString('N') + '.zip')
        if (-not (Invoke-CrossroadsSaveFetch $save.saveId $archive)) { continue }
        try {
            $target = Join-Path $live $slot
            [IO.Compression.ZipFile]::ExtractToDirectory($archive, $target)
            $restoredCount++
            # Remembered as already-sent, so the watcher does not immediately
            # upload back what it just downloaded. The service would not store a
            # duplicate anyway, but a re-zip is not byte-identical to the
            # original -- zip archives carry timestamps -- so its hash check
            # cannot be relied on to catch this. The client has to know.
            $fingerprint = Get-CrossroadsFolderFingerprint $target
            $script:crossroadsSaveFingerprints[$slot] = $fingerprint
            $script:crossroadsSaveUploaded[$slot] = $fingerprint
        }
        catch {
            Write-Host ("Crossroads could not unpack the recorded save '$slot'.") `
                -ForegroundColor DarkGray
        }
        finally {
            Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
        }
    }

    if ($restoredCount -gt 0) {
        Write-Host ("Restored $restoredCount of your recorded save(s) for this server.")
    }
    else {
        Write-Host ('You have no recorded saves on this server yet, so start a ' +
                    'NEW game. Existing characters cannot be brought onto a ' +
                    'public server.')
    }
    Write-Host ''
}

function Update-CrossroadsSaves {
    param([switch]$Final)
    if (-not $script:crossroadsSavesActive) { return }
    if (-not $Final) {
        if ([DateTime]::UtcNow -lt $script:crossroadsSaveNextTick) { return }
        $script:crossroadsSaveNextTick = [DateTime]::UtcNow.AddSeconds(10)
    }

    $folders = Get-ChildItem -LiteralPath $script:crossroadsSavesFolder `
        -Directory -ErrorAction SilentlyContinue
    foreach ($folder in $folders) {
        $slot = $folder.Name
        if ($slot -notmatch $script:crossroadsSlotPattern) { continue }
        $fingerprint = Get-CrossroadsFolderFingerprint $folder.FullName
        if ([string]::IsNullOrWhiteSpace($fingerprint)) { continue }

        if (-not $Final) {
            # QUIESCE. A KotOR save is five files written over some interval, and
            # a folder zipped mid-write produces a torn save that would fail its
            # own hash on the way back in. Upload only what looked identical on
            # two consecutive ticks; anything still changing waits.
            if ($script:crossroadsSaveFingerprints[$slot] -ne $fingerprint) {
                $script:crossroadsSaveFingerprints[$slot] = $fingerprint
                continue
            }
        }
        if ($script:crossroadsSaveUploaded[$slot] -eq $fingerprint) { continue }

        $archive = Join-Path $saveWorkRoot ('send-' + [Guid]::NewGuid().ToString('N') + '.zip')
        try {
            [IO.Compression.ZipFile]::CreateFromDirectory(
                $folder.FullName, $archive,
                [IO.Compression.CompressionLevel]::Optimal, $false)
        }
        catch {
            # Most often the game still holds a handle. Not an error: the next
            # tick tries again.
            Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
            continue
        }
        if (Invoke-CrossroadsSaveUpload $slot $archive) {
            $script:crossroadsSaveUploaded[$slot] = $fingerprint
            $script:crossroadsSaveFingerprints[$slot] = $fingerprint
        }
        Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
    }
}

function Exit-CrossroadsSaveSession {
    param([switch]$RestoreOnly)
    if (-not $script:crossroadsSavesActive) { return }
    # THE FINAL SWEEP RUNS BEFORE THE SESSION IS CLOSED, because an upload needs
    # an open session -- that is what "made while connected" means to the
    # service, and closing first would throw away the last save of the sitting.
    # The quiesce rule is skipped here: the game has exited, so nothing is still
    # being written.
    if (-not $RestoreOnly) { Update-CrossroadsSaves -Final }
    Restore-CrossroadsSaves
    Remove-Item -LiteralPath $saveWorkRoot -Recurse -Force -ErrorAction SilentlyContinue
}


# =============================================================================
# THE CO-OP SAVE HANDOFF (D85) -- the client halves.
#
# WHY IT EXISTS, in one line: a guest that loads its OWN save is in its own
# world, so possession takes one of its OWN companions and the two machines
# share a module only by luck. Measured 2026-10-20/21 -- the role gate and
# possession both work and the result was still two parallel games.
#
# The owner's instruction: *"ENFORCE THE GUEST TO HAVE TO LOAD A CURATED SAVE
# FROM THE HOST MADE AT THE TIME OF JOIN."*
#
# WHY THE SAVE TRAVELS OVER HTTP AND NOT THE RELAY. At the moment the guest
# needs it, the guest's GAME IS NOT RUNNING -- it is sitting here, before
# Start-KotorGame. There is no mirror and so no relay connection to carry
# anything, and the relay is fixed-size UDP parsed in C++ from hostile input,
# which is the worst place in this project for a multi-megabyte transfer.
#
# THIS PHASE ASKS THE HOST TO PRESS SAVE. Calling the engine's own save routine
# is unbuilt and carries real risk -- the save path runs through ResMan over CRT
# stdio and no single call both names the file and writes it. Asking proves the
# whole remaining chain at no engine risk, and automating it later changes one
# step rather than the design.
# =============================================================================

$script:crossroadsHandoffId = ''
$script:crossroadsHandoffHostNextTick = [DateTime]::MinValue
$script:crossroadsHandoffAnswered = @{}
$script:crossroadsHandoffZipReported = $false

# The slot the host's save lands in on the guest. A HIGH NUMBER so KotOR's load
# list shows it last, and a name the player cannot mistake for their own -- they
# are about to be told to load it by name.
$script:crossroadsHandoffSlot = '000999 - CROSSROADS CO-OP'

function Get-CrossroadsHudAlertPath {
    Join-Path $env:LOCALAPPDATA 'KSE2\hud_alert.txt'
}

function Set-CrossroadsHudAlert {
    param([string]$Text)
    # WRITTEN WITHOUT A BOM. The HUD skips one if it finds it, but a BOM here
    # would be the third time this project shipped one into a file another
    # program reads -- it broke the extender's role comparison and killed every
    # curated server row on 2026-09-28.
    #
    # NEVER FATAL. An alert that could stop a session would be a worse bug than
    # a missing alert.
    try {
        $path = Get-CrossroadsHudAlertPath
        $directory = Split-Path -Parent $path
        if (-not (Test-Path -LiteralPath $directory)) {
            New-Item -ItemType Directory -Path $directory -Force | Out-Null
        }
        [IO.File]::WriteAllText($path, $Text, (New-Object Text.UTF8Encoding($false)))
    }
    catch {
        Write-Host ("Crossroads could not raise the in-game alert: " +
                    $_.Exception.Message) -ForegroundColor DarkGray
    }
}

function Clear-CrossroadsHudAlert {
    try {
        Remove-Item -LiteralPath (Get-CrossroadsHudAlertPath) -Force `
            -ErrorAction SilentlyContinue
    }
    catch { }
}

function Invoke-CrossroadsHandoff {
    <#
        One JSON call to the handoff endpoints. Returns the parsed body, or
        $null, with the status in $script:crossroadsHandoffStatus so a caller
        can tell "still waiting" (202) from "gone" (404).
    #>
    param([string]$Path, [hashtable]$Body)
    $script:crossroadsHandoffStatus = 0
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $null }
    try {
        $response = Invoke-WebRequest -Uri ($serviceUrl.TrimEnd('/') + $Path) `
            -Method Post -ContentType 'application/json' -TimeoutSec 15 `
            -UseBasicParsing -Body ($Body | ConvertTo-Json -Compress)
        $script:crossroadsHandoffStatus = [int]$response.StatusCode
        if ($response.Content) { return ($response.Content | ConvertFrom-Json) }
        return $null
    }
    catch [System.Net.WebException] {
        $webResponse = $_.Exception.Response
        if ($null -ne $webResponse) {
            $script:crossroadsHandoffStatus = [int]$webResponse.StatusCode
            try {
                $reader = New-Object IO.StreamReader($webResponse.GetResponseStream())
                $raw = $reader.ReadToEnd(); $reader.Close()
                if ($raw) { return ($raw | ConvertFrom-Json) }
            }
            catch { }
        }
        return $null
    }
    catch { return $null }
}

# ---- WHAT HAPPENED LAST TIME, SENT OVER THE WIRE (2026-10-27) --------------
#
# MEASURED 2026-10-27: a third PC's KotOR died the moment it joined, every time.
# Its mirror never connected, so the relay's diagnostic channel never opened,
# and the only records -- Windows' event log, the extender's log, this script's
# own log -- were on that PC. The owner's rule: information comes over the
# wire, never from them running commands on another machine.
#
# THE JOIN OUTLIVES THE GAME and already talks to the service for the co-op
# save, so it is the one part that can always speak. At the start of a co-op
# join it sends what happened LAST time. It never goes to the relay (Stage 1:
# the join opens no socket to the relay), only to the service, and only when
# signed in. Best effort: a report about a failure must not become one.
function Send-CrossroadsLastSessionReport {
    param([string]$Role)
    try {
        $token = Get-CrossroadsAccountToken
        if ([string]::IsNullOrWhiteSpace($token)) { return }

        $head = New-Object System.Collections.Generic.List[string]
        $head.Add(('role={0} sent={1:s}' -f $Role, (Get-Date)))
        $events = @(Get-WinEvent -FilterHashtable @{
                LogName = 'Application'; Id = 1000, 1002
                StartTime = (Get-Date).AddDays(-2)
            } -MaxEvents 50 -ErrorAction SilentlyContinue |
            Where-Object { $_.Message -match 'swkotor2' } | Select-Object -First 2)
        if ($events.Count -eq 0) {
            $head.Add('== Windows has no crash (1000) or hang (1002) record for swkotor2.exe in the last two days.')
        }
        foreach ($event in $events) {
            $message = [string]$event.Message
            $head.Add(('== Windows event {0} at {1:s}:' -f $event.Id, $event.TimeCreated))
            $head.Add($message.Substring(0, [Math]::Min(700, $message.Length)))
        }
        $kseLog = Join-Path $env:LOCALAPPDATA 'KSE2\kse.log'
        if (Test-Path -LiteralPath $kseLog) {
            $kseItem = Get-Item -LiteralPath $kseLog
            $head.Add(('== kse.log last written {0:s}, last lines:' -f $kseItem.LastWriteTime))
            $head.Add(((Get-Content -LiteralPath $kseLog -Tail 12 -ErrorAction SilentlyContinue) -join "`n"))
        }
        else {
            $head.Add('== no kse.log on this machine.')
        }
        $report = ($head -join "`n") + "`n== the previous join's last lines:`n"
        # THE SERVICE KEEPS 12,000 CHARACTERS of a 16 KiB body; escaping can
        # grow the text, so this stays well under. The join's own tail is what
        # gets cut, from its START, because its last lines are the ones that
        # say where it stopped.
        $room = 9000 - $report.Length
        $tail = [string]$script:lastJoinLogTail
        if ($room -le 0) { $tail = '' }
        elseif ($tail.Length -gt $room) { $tail = $tail.Substring($tail.Length - $room) }
        $report += $tail

        $null = Invoke-CrossroadsHandoff '/diag/report' @{
            accountToken = $token; source = 'kotor2-join'; report = $report
        }
        if ($script:crossroadsHandoffStatus -eq 200) {
            Write-Host 'Sent the last session''s report to the Crossroads service.'
        }
        else {
            # Once, and only here: an older service answers 404, which is not a
            # fault on this machine.
            Write-Host ("The Crossroads service did not take the last session's report " +
                        "(status $script:crossroadsHandoffStatus). Joining anyway.") `
                -ForegroundColor DarkYellow
        }
    }
    catch {
        Write-Host "Could not send the last session's report: $($_.Exception.Message)" `
            -ForegroundColor DarkYellow
    }
}

# ---- THE GUEST HALF ---------------------------------------------------------

function Request-CrossroadsHandoffSave {
    <#
        Ask the host for a save, wait for it, and put it where the player can
        load it. Returns $true when a save is in place.

        REFUSES TO CONTINUE SILENTLY ON FAILURE -- see the caller. A guest that
        joined without the host's save is the exact fault this whole mechanism
        exists to remove, and letting it through would reproduce it while
        looking like a success.
    #>
    param([string]$GameId, [string]$ServerId, [string]$GameDirectory,
          [int]$TimeoutSeconds = 300)

    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) {
        Write-Host ''
        Write-Host 'CO-OP NEEDS YOU SIGNED IN' -ForegroundColor Yellow
        Write-Host ('The host has to hand you their save, and the service will ' +
                    'only do that for a signed-in account. Sign in from the ' +
                    'launcher and press Join again.')
        return $false
    }

    $opened = Invoke-CrossroadsHandoff '/coop/handoff/request' @{
        accountToken = $token; game = $GameId; serverId = $ServerId
    }
    if (-not $opened -or -not $opened.handoffId) {
        Write-Host ''
        Write-Host 'CROSSROADS COULD NOT ASK THE HOST FOR THEIR SAVE' `
            -ForegroundColor Yellow
        Write-Host ("The service answered $script:crossroadsHandoffStatus. " +
                    'Nothing was changed on this machine.')
        return $false
    }
    $script:crossroadsHandoffId = [string]$opened.handoffId

    Write-Host ''
    Write-Host 'WAITING FOR THE HOST TO SAVE' -ForegroundColor Cyan
    Write-Host ('In co-op you play in the host''s world, so you load THEIR ' +
                'save rather than your own.')
    Write-Host ('They have been asked in game to save. This waits up to ' +
                "$([int]($TimeoutSeconds / 60)) minutes.")
    Write-Host ''

    # SAME HOLE AS THE HOST'S, same measurement: $saveWorkRoot is created by the
    # public-save path and by Install-CrossroadsHandoffSave, and the download
    # below happens BEFORE either. -OutFile into a directory that does not exist
    # fails, and the loop would simply never see a 200.
    New-Item -ItemType Directory -Force -Path $saveWorkRoot | Out-Null
    $archive = Join-Path $saveWorkRoot ('handoff-' + [Guid]::NewGuid().ToString('N') + '.zip')
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    $publisher = ''
    $companion = ''
    $got = $false
    while ([DateTime]::UtcNow -lt $deadline) {
        try {
            $response = Invoke-WebRequest `
                -Uri ((Read-OptionalIniValue 'accounts' 'service_url').TrimEnd('/') + '/coop/handoff/fetch') `
                -Method Post -ContentType 'application/json' -TimeoutSec 60 `
                -UseBasicParsing -OutFile $archive -PassThru `
                -Body (@{ accountToken = $token
                          handoffId = $script:crossroadsHandoffId } |
                       ConvertTo-Json -Compress)
            # 202 CARRIES A JSON BODY, NOT AN ARCHIVE. -OutFile wrote it to the
            # archive path, so the status decides what that file is -- treating
            # it as a zip would hand the player a save made of the word
            # "waiting".
            if ([int]$response.StatusCode -eq 200) {
                $publisher = [string]$response.Headers['X-Crossroads-Publisher']
                $companion = ([string]$response.Headers['X-Crossroads-Companion']).Trim().ToLowerInvariant()
                $got = $true
                break
            }
        }
        catch { }
        Write-Host '  still waiting for the host...' -ForegroundColor DarkGray
        Start-Sleep -Seconds 5
    }

    if (-not $got) {
        Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
        Write-Host ''
        Write-Host 'THE HOST DID NOT SAVE IN TIME' -ForegroundColor Yellow
        Write-Host ('Nothing was changed on this machine. Ask them to save and ' +
                    'press Join again.')
        return $false
    }

    # WHICH COMPANION THIS GUEST PLAYS, CHOSEN BY THE HOST (2026-10-27). The
    # owner's rule: "There shouldn't be time where multiple players occupy the
    # same companion." The host picks from the companions nobody is playing and
    # sends the choice with the save; the extender takes exactly that one. An
    # older host sends nothing, and the file is left absent so the extender
    # keeps the behaviour that shipped before this.
    if ($companion -eq 'none') {
        Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
        Write-Host ''
        Write-Host 'NO COMPANION IS FREE FOR YOU' -ForegroundColor Yellow
        Write-Host ('Every companion in the host''s party is already being played. ' +
                    'The host needs another companion in their party before you can ' +
                    'join. Nothing was changed on this machine.')
        return $false
    }
    if ($companion -match '^[a-z0-9_]{1,32}$') {
        $assignedPath = Join-Path $env:LOCALAPPDATA 'KSE2\coop_companion.txt'
        [IO.File]::WriteAllText($assignedPath, "$companion`n", [Text.UTF8Encoding]::new($false))
        Write-Host ("The host has given you this companion to play: $companion")
    }
    else {
        # SAID, NOT SILENT (2026-10-28). On 2026-10-27 a guest's assignment went
        # missing and the join printed nothing about it, so nobody could tell
        # "the host sent none" from "it was lost on the way". The service now
        # logs what it stored and served; this is the guest's end of that trail.
        Write-Host ('No companion was given by the host (the save arrived without ' +
                    'one), so this machine picks one itself as before.') -ForegroundColor Yellow
    }

    Write-Host ''
    Write-Host 'The host''s save has arrived.' -ForegroundColor Green
    if ($publisher) {
        # NAMED, because the service cannot PROVE the publisher was the host --
        # it says so itself. The player is the last check, so they are told
        # whose save they are about to load rather than it happening silently.
        Write-Host ("It was offered by: $publisher")
    }

    try {
        if (-not (Install-CrossroadsHandoffSave $archive $GameDirectory)) {
            return $false
        }
    }
    finally {
        Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
    }
    return $true
}

function Install-CrossroadsHandoffSave {
    <#
        Park the guest's own saves and put the host's in their place.

        THE SAME SHAPE AS THE PUBLIC SAVE RULE, deliberately, and it reuses that
        rule's record so a crash between the two steps is recoverable the same
        way. It is a SEPARATE path rather than a flag on that one: a public
        session and a co-op session are two tracks (D52) and collapsing them is
        how one grows a condition the other has to work around.
    #>
    param([string]$Archive, [string]$GameDirectory)

    $live = Join-Path $GameDirectory 'saves'
    $parked = Join-Path $GameDirectory 'saves.crossroads-offline'
    if (Test-Path -LiteralPath $parked) {
        # WHATEVER IS IN THERE IS SOMEBODY'S CHARACTER. The public rule refuses
        # here for the same reason and this must not be the softer path.
        Write-Host ''
        Write-Host 'CROSSROADS FOUND PARKED SAVES FROM AN EARLIER SESSION' `
            -ForegroundColor Yellow
        Write-Host ("Move or rename $parked before joining. Nothing was changed.")
        return $false
    }

    New-Item -ItemType Directory -Force -Path $saveWorkRoot | Out-Null
    $record = @{ live = $live; parked = $parked
                 stamped = (Get-Date).ToString('o') } | ConvertTo-Json
    [IO.File]::WriteAllText($saveSwapRecord, $record,
        (New-Object Text.UTF8Encoding($false)))

    if (Test-Path -LiteralPath $live) {
        Move-Item -LiteralPath $live -Destination $parked -Force
    }
    New-Item -ItemType Directory -Force -Path $live | Out-Null
    $script:crossroadsSavesActive = $true
    $script:crossroadsSavesFolder = $live

    $target = Join-Path $live $script:crossroadsHandoffSlot
    try {
        [IO.Compression.ZipFile]::ExtractToDirectory($Archive, $target)
    }
    catch {
        Write-Host ''
        Write-Host 'CROSSROADS COULD NOT UNPACK THE HOST''S SAVE' -ForegroundColor Yellow
        Write-Host ("  " + $_.Exception.Message)
        # The parked folder comes back rather than being left behind: the player
        # must not lose their own saves to a failed handoff.
        Exit-CrossroadsSaveSession -RestoreOnly
        return $false
    }

    # MARKED AS ALREADY SENT so the public-save watcher, if it is also running,
    # does not upload the host's save back as if it were this player's -- the
    # same reasoning Enter-CrossroadsSaveSession records for a restored save.
    $fingerprint = Get-CrossroadsFolderFingerprint $target
    $script:crossroadsSaveFingerprints[$script:crossroadsHandoffSlot] = $fingerprint
    $script:crossroadsSaveUploaded[$script:crossroadsHandoffSlot] = $fingerprint

    Write-Host ''
    Write-Host 'LOAD THIS SAVE WHEN THE GAME OPENS' -ForegroundColor Cyan
    Write-Host ("  $script:crossroadsHandoffSlot")
    Write-Host ('It is the host''s world. Your own saves are parked and come ' +
                'back when you leave.')
    Write-Host ''
    return $true
}

# ---- THE HOST HALF ----------------------------------------------------------

function Update-CrossroadsHandoffHost {
    <#
        Ask whether anybody is waiting, tell the host in game, and send the save
        once they have made one.

        RIDES THE SESSION LOOP, like the save watcher beside it, and rate-limits
        itself. On any session that is not a co-op host it costs one comparison.
    #>
    param([string]$ServerId, [string]$GameDirectory)

    if ([DateTime]::UtcNow -lt $script:crossroadsHandoffHostNextTick) { return }
    $script:crossroadsHandoffHostNextTick = [DateTime]::UtcNow.AddSeconds(5)

    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return }

    $pending = Invoke-CrossroadsHandoff '/coop/handoff/pending' @{
        accountToken = $token; serverId = $ServerId
    }
    if (-not $pending) { return }

    $waiting = @($pending.waiting | Where-Object { -not $_.answered })
    if ($waiting.Count -eq 0) {
        Clear-CrossroadsHudAlert
        return
    }

    $who = [string]$waiting[0].requestedName
    if ([string]::IsNullOrWhiteSpace($who)) { $who = 'A player' }
    Set-CrossroadsHudAlert ("$who is joining - SAVE YOUR GAME")

    # ONLY A SAVE MADE SINCE THE REQUEST WILL DO. The owner's words were "a
    # curated save from the host MADE AT THE TIME OF JOIN": sending whatever was
    # already on disk would put the guest somewhere the host no longer is, which
    # is the fault this replaces rather than a lesser version of it.
    $requestedAgo = [double]$waiting[0].waitingSeconds
    $cutoff = [DateTime]::UtcNow.AddSeconds(-1 * ($requestedAgo + 5))

    $live = Join-Path $GameDirectory 'saves'
    $folders = @(Get-ChildItem -LiteralPath $live -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match $script:crossroadsSlotPattern } |
        Sort-Object LastWriteTimeUtc -Descending)
    if ($folders.Count -eq 0) { return }
    $newest = $folders[0]
    if ($newest.LastWriteTimeUtc -lt $cutoff) { return }

    # QUIESCE BEFORE ZIPPING. A KotOR save is five files written over an
    # interval, and a folder zipped mid-write is a torn save that fails its own
    # hash at the other end. This is the save watcher's rule and it was learned
    # the hard way there.
    $fingerprint = Get-CrossroadsFolderFingerprint $newest.FullName
    if ([string]::IsNullOrWhiteSpace($fingerprint)) { return }
    $key = 'handoff:' + $newest.Name
    if ($script:crossroadsSaveFingerprints[$key] -ne $fingerprint) {
        $script:crossroadsSaveFingerprints[$key] = $fingerprint
        return
    }

    foreach ($request in $waiting) {
        $handoffId = [string]$request.handoffId
        if ($script:crossroadsHandoffAnswered.ContainsKey($handoffId)) { continue }

        # THE WORK DIRECTORY HAS TO EXIST, and on this path nothing was creating
        # it. MEASURED 2026-10-22, twice: $saveWorkRoot is created inside
        # Enter-CrossroadsSaveSession (public sessions only) and inside
        # Install-CrossroadsHandoffSave (the guest). A CO-OP HOST is neither --
        # its session classifies `unverified` because it connects to loopback --
        # so the directory never existed, CreateFromDirectory threw every tick,
        # and the catch below returned without saying anything. The host polled
        # for a waiting guest forever and never sent a byte.
        New-Item -ItemType Directory -Force -Path $saveWorkRoot | Out-Null

        $archive = Join-Path $saveWorkRoot ('offer-' + [Guid]::NewGuid().ToString('N') + '.zip')
        try {
            [IO.Compression.ZipFile]::CreateFromDirectory(
                $newest.FullName, $archive,
                [IO.Compression.CompressionLevel]::Optimal, $false)
        }
        catch {
            # THE FIRST FAILURE IS SAID OUT LOUD, and the repeats are not.
            #
            # This used to return in silence on every tick. The usual cause is
            # benign -- the game still holds a handle on a save it just wrote,
            # and the next tick succeeds -- but a PERMANENT cause looks exactly
            # the same from outside, and one cost two two-machine runs before
            # anybody could see it. A retry that never reports is
            # indistinguishable from a feature that was never wired up.
            if (-not $script:crossroadsHandoffZipReported) {
                $script:crossroadsHandoffZipReported = $true
                Write-Host ('Crossroads could not package your save yet: ' +
                            $_.Exception.Message) -ForegroundColor Yellow
                Write-Host ('  Retrying every few seconds. If this repeats, the ' +
                            'save is being held open.') -ForegroundColor DarkGray
            }
            Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
            return
        }

        $companion = Select-CrossroadsCompanion ([string]$request.requestedName)
        $sent = Send-CrossroadsHandoffSave $handoffId $archive $companion
        Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
        if ($sent) {
            $script:crossroadsHandoffAnswered[$handoffId] = $true
            Write-Host ("Sent your save to $($request.requestedName)" +
                        $(if ($companion -eq 'none') { ' -- with NO free companion, so they cannot join' }
                          elseif ($companion) { " -- they will play $companion" }
                          else { '' }) + '.') `
                -ForegroundColor Green
            Set-CrossroadsHudAlert ("Save sent to $($request.requestedName)")
            # Left on screen briefly rather than cleared instantly, so the host
            # sees that the thing they were asked to do worked.
            $script:crossroadsHandoffHostNextTick = [DateTime]::UtcNow.AddSeconds(8)
        }
    }
}

# ---- WHICH COMPANION A NEW GUEST PLAYS (2026-10-27) -------------------------
#
# The owner's design: when the host hands its save to a guest, look at who is
# playing what and give the guest a companion nobody has, so two players never
# share one -- not even for a moment. Three inputs, all on this machine:
#   coop_party.txt   the companions in the host's party, in PARTY-SLOT order
#                    (written by the extender from crs_party, once a second;
#                    never sorted since 2026-10-28 -- the lowest free slot wins)
#   peer_roster.txt  each connected guest's announced companion, as a tag hash
#                    (written by the mirror; guests silent 30 s drop out)
#   this session's own choices, so two guests asking at once get two answers
# The hash is FNV-1a over the lowercase tag, the same in the extender and the
# mirror; a tag never travels on the game wire, only its hash.
$script:crossroadsCompanionGiven = @{}

function Get-CrossroadsTagHash([string]$Tag) {
    [uint64]$hash = 2166136261
    foreach ($byte in [Text.Encoding]::ASCII.GetBytes($Tag.ToLowerInvariant())) {
        $hash = ($hash -bxor $byte)
        $hash = ($hash * 16777619) % 4294967296
    }
    return [uint32]$hash
}

function Select-CrossroadsCompanion([string]$RequestedName) {
    try {
        $kse = Join-Path $env:LOCALAPPDATA 'KSE2'
        $partyFile = Join-Path $kse 'coop_party.txt'
        # AN OLDER EXTENDER WRITES NO PARTY FILE: no choice is sent, and the
        # guest keeps the behaviour that shipped before this.
        if (-not (Test-Path -LiteralPath $partyFile)) { return '' }
        $tags = @(Get-Content -LiteralPath $partyFile |
            ForEach-Object { $_.Trim().ToLowerInvariant() } |
            Where-Object { $_ -match '^[a-z0-9_]{1,32}$' })
        if ($tags.Count -eq 0) { return 'none' }

        $now = [DateTime]::UtcNow
        # The same guest asking again (a retry, a rejoin) keeps its companion.
        $mine = $script:crossroadsCompanionGiven[$RequestedName]
        if ($mine -and $tags -contains $mine.Tag) {
            $mine.At = $now
            return $mine.Tag
        }

        $taken = @{}
        $rosterFile = Join-Path $kse 'peer_roster.txt'
        if (Test-Path -LiteralPath $rosterFile) {
            foreach ($line in (Get-Content -LiteralPath $rosterFile)) {
                if ($line -match '^peer=\d+ host=0 companion=(\d+)') {
                    $taken[[uint32]$Matches[1]] = $true
                }
            }
        }
        # Given out within the last five minutes and not yet connected: still
        # spoken for. Older than that, the guest gave up and it is free again.
        foreach ($name in @($script:crossroadsCompanionGiven.Keys)) {
            $given = $script:crossroadsCompanionGiven[$name]
            if (($now - $given.At).TotalMinutes -gt 5) {
                $script:crossroadsCompanionGiven.Remove($name); continue
            }
            if ($name -ne $RequestedName) { $taken[(Get-CrossroadsTagHash $given.Tag)] = $true }
        }
        # THE LOWEST FREE PARTY SLOT (2026-10-28). The file is in the host's
        # party-slot order, never sorted -- the owner: "never by name". Said in
        # the host's window, so a wrong pick can be read against the slots.
        $slotText = (@(for ($i = 0; $i -lt $tags.Count; $i++) {
            "slot $($i + 1)=$($tags[$i])" +
            $(if ($taken.ContainsKey((Get-CrossroadsTagHash $tags[$i]))) { ' (taken)' } else { '' })
        }) -join ', ')
        Write-Host ("Your companions by party slot: $slotText") -ForegroundColor DarkGray
        foreach ($tag in $tags) {
            if (-not $taken.ContainsKey((Get-CrossroadsTagHash $tag))) {
                $script:crossroadsCompanionGiven[$RequestedName] =
                    [pscustomobject]@{ Tag = $tag; At = $now }
                return $tag
            }
        }
        return 'none'
    }
    catch {
        Write-Host "Could not choose a companion for $RequestedName`: $($_.Exception.Message)" `
            -ForegroundColor DarkYellow
        return ''
    }
}

function Send-CrossroadsHandoffSave {
    param([string]$HandoffId, [string]$Archive, [string]$Companion = '')
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return $false }
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $false }
    try {
        $bytes = [IO.File]::ReadAllBytes($Archive)
        $sha = (Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash.ToLower()
        # THE CREDENTIALS AND THE ID ARE HEADERS, not query parameters: the body
        # is the archive so there is nowhere else for them, and a URL is the part
        # of a request that ends up in logs. The service documents the same
        # reasoning on its side.
        $headers = @{
            'X-Crossroads-Token' = $token
            'X-Crossroads-Handoff' = $HandoffId
            'X-Crossroads-Sha256' = $sha
        }
        # THE HOST'S CHOICE OF COMPANION FOR THIS GUEST. Left off when there is
        # no choice to make (an older extender), so an older service is not
        # handed a header it would ignore anyway.
        if ($Companion) { $headers['X-Crossroads-Companion'] = $Companion }
        Invoke-WebRequest -Uri ($serviceUrl.TrimEnd('/') + '/coop/handoff/publish') `
            -Method Post -ContentType 'application/zip' -TimeoutSec 120 `
            -UseBasicParsing -Body $bytes -Headers $headers | Out-Null
        return $true
    }
    catch {
        Write-Host ("Crossroads could not send your save: " +
                    $_.Exception.Message) -ForegroundColor DarkGray
        return $false
    }
}

function Test-KotorServerHost {
    param(
        [string]$HostName,
        [uint16]$Port
    )
    if ([string]::IsNullOrWhiteSpace($HostName)) {
        return $false
    }
    $client = [Net.Sockets.UdpClient]::new()
    try {
        $client.Client.ReceiveTimeout = 1200
        $client.Connect($HostName, $Port)
        $nonce = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString('X16')
        $request = [Text.Encoding]::ASCII.GetBytes(
            "CRS_KOTOR2_STATUS_V1 $nonce")
        [void]$client.Send($request, $request.Length)
        $remote = [Net.IPEndPoint]::new([Net.IPAddress]::Any, 0)
        $response = [Text.Encoding]::ASCII.GetString(
            $client.Receive([ref]$remote))
        return $response.StartsWith("CRS_KOTOR2_STATUS_V1_ACK $nonce ")
    }
    catch {
        return $false
    }
    finally {
        $client.Dispose()
    }
}

function Get-GameDirectory {
    param([string]$ConfiguredDirectory)
    if (-not [string]::IsNullOrWhiteSpace($ConfiguredDirectory)) {
        $configured = $ConfiguredDirectory.Trim('"')
        if (-not (Test-Path -LiteralPath (Join-Path $configured 'swkotor2.exe'))) {
            throw 'The KotOR folder supplied by the launcher does not contain swkotor2.exe.'
        }
        return (Resolve-Path -LiteralPath $configured).Path
    }
    $default = 'C:\Program Files (x86)\Steam\steamapps\common\Knights of the Old Republic II'
    if (Test-Path -LiteralPath (Join-Path $default 'swkotor2.exe')) {
        return $default
    }
    $chosen = (Read-Host 'Paste the folder containing swkotor2.exe').Trim('"')
    if (-not (Test-Path -LiteralPath (Join-Path $chosen 'swkotor2.exe'))) {
        throw 'The selected folder does not contain swkotor2.exe.'
    }
    return (Resolve-Path -LiteralPath $chosen).Path
}

function Get-SteamExecutable {
    $runningSteam = Get-Process 'steam' -ErrorAction SilentlyContinue |
        Where-Object { $_.Path -and (Test-Path -LiteralPath $_.Path) } |
        Select-Object -First 1
    if ($runningSteam) {
        return $runningSteam.Path
    }
    $candidates = @()
    try {
        $steamPath = (Get-ItemProperty `
            'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath
        if ($steamPath) {
            $candidates += Join-Path $steamPath 'steam.exe'
        }
    }
    catch {}
    try {
        $steamPath = (Get-ItemProperty `
            'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' `
            -ErrorAction Stop).InstallPath
        if ($steamPath) {
            $candidates += Join-Path $steamPath 'steam.exe'
        }
    }
    catch {}
    $candidates += 'C:\Program Files (x86)\Steam\steam.exe'
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    return ''
}

# Launch the game. Returns TRUE when the launch went through Steam.
#
# THE RETURN VALUE EXISTS SO THE WAIT BELOW CAN BE SIZED HONESTLY. A direct
# launch puts swkotor.exe on the process list within a second or two, because
# this script started it. A Steam launch does not: Steam is asked to start the
# game and returns immediately, and everything after that -- starting Steam
# itself if it was closed, its update check, the game's own startup -- happens on
# Steam's clock, not ours.
function Start-KotorGame {
    param([string]$Game)
    $steam = Get-SteamExecutable
    if ($steam) {
        Write-Host 'Requesting KotOR launch through Steam...'
        Start-Process -FilePath $steam `
            -ArgumentList @('-applaunch', '208580') | Out-Null
        return $true
    }
    Write-Host 'Steam was not detected; using the game executable directly.'
    Start-Process -FilePath (Join-Path $Game 'swkotor2.exe') `
        -WorkingDirectory $Game | Out-Null
    return $false
}

function Get-KotorInjectedModules {
    param([int]$ProcessId)

    # KotOR is 32-bit. Ask the built-in 32-bit Windows PowerShell host to
    # enumerate its modules so this check also works when Crossroads itself was
    # launched from 64-bit PowerShell.
    $powershell32 = Join-Path $env:WINDIR `
        'SysWOW64\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $powershell32 -PathType Leaf)) {
        return @()
    }

    $probe = @"
`$process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
if (`$process) {
    `$process.Modules | ForEach-Object { `$_.ModuleName }
}
"@
    $encoded = [Convert]::ToBase64String(
        [Text.Encoding]::Unicode.GetBytes($probe))
    return @(
        & $powershell32 -NoProfile -NonInteractive `
            -EncodedCommand $encoded 2>$null |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )
}

# How many items is the saved character wearing?
#
# WHY THIS EXISTS. CrossroadsBuildIdentity.exe caps the join identity at four
# equipment entries and raises "Join identity supports at most four visible
# equipment slots". The player sees a Python traceback followed by "Crossroads
# could not read the selected player character", which names neither the cause
# nor the remedy. On 2026-08-08 that cost twenty minutes of diagnosis on a
# machine that was working an hour earlier -- an equipment test had left the
# character wearing eight items.
#
# THE MESSAGE IS ALSO WRONG, WHICH IS WHY THE REMEDY IS NOT GUESSABLE. It says
# "visible", but build_remote_template.py iterates the entire Equip_ItemList
# with no visibility filter: implants, belts and armbands count exactly as much
# as armour does. Someone unequipping only what shows on the model strips their
# character and still fails.
#
# FAILS OPEN. Returns -1 on anything it does not understand, and the caller
# then hands the builder the save exactly as before -- so a parser bug here can
# only ever restore the old behaviour, never invent a new refusal.
function Get-ClientId {
    $registry = [Microsoft.Win32.RegistryKey]::OpenBaseKey(
        [Microsoft.Win32.RegistryHive]::LocalMachine,
        [Microsoft.Win32.RegistryView]::Registry64)
    try {
        $cryptography = $registry.OpenSubKey(
            'SOFTWARE\Microsoft\Cryptography', $false)
        if (-not $cryptography) {
            throw 'Windows machine identity registry key was not found.'
        }
        try {
            $machineGuid = [string]$cryptography.GetValue('MachineGuid')
        }
        finally {
            $cryptography.Dispose()
        }
    }
    finally {
        $registry.Dispose()
    }
    if ([string]::IsNullOrWhiteSpace($machineGuid)) {
        throw 'Windows machine identity is unavailable.'
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $hash = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($machineGuid))
    }
    finally {
        $sha.Dispose()
    }
    $id = [BitConverter]::ToUInt32($hash, 0)
    return $(if ($id -eq 0) { [uint32]1 } else { $id })
}

function Backup-OwnedFiles {
    param([string]$Game)
    if (Test-Path -LiteralPath $installRecord) {
        return
    }
    $override = Join-Path $Game 'Override'
    New-Item -ItemType Directory -Force -Path $override,$backup | Out-Null
    # EVERY hash Crossroads has ever shipped for these files, not just the
    # current one.
    #
    # This gate exists to refuse an unrelated mod's file. With a single hash it
    # also refused OUR OWN PREVIOUS BUILD, because a leftover from an earlier
    # session is not the current hash and is therefore "unrelated". Measured
    # 2026-08-07: the heartbeat changed twice in one day and every machine
    # holding a leftover was blocked from joining, with a message that reads
    # like a foreign mod is installed. The tester sees the game fail to start
    # and has no way to know the offending file is ours.
    #
    # So the value is a LIST, appended to whenever a payload file changes.
    # Recognising our own history is what lets the gate keep saying no to
    # somebody else's file while still replacing ours.
    # KOTOR II (games/kotor2/PLAN_2026-11-15-adapting-the-base.md, step 9). KotOR I's
    # table listed every KotOR I build ever shipped; NONE of those can be in a KotOR II
    # Override, so this starts fresh with KotOR II's own. The rule is KotOR I's and
    # stays: APPEND-ONLY, because a leftover of OUR OWN from an earlier build is not a
    # foreign mod and must not lock a player out.
    #
    # These are the 2026-11-15 compiles (KotOR II's nwscript.nss, the scripting tool's
    # k2 compiler). NOT YET SHIPPED: the packager's hash tool must append the shipped
    # builds' hashes here before the first KotOR II publish.
    $known = @{
        'cr_orig_hb.ncs' = @(
            # KotOR II's retail k_def_heartbt01 (scripts.bif, 735 bytes), saved under
            # our name. BioWare's file; it does not change.
            'A9701608C46A8166C9B68A519BA1C7985EE3E354DF3A2AF1DA8B20041107A50C'
        )
        'k_def_heartbt01.ncs' = @(
            # 406 bytes -- byte-identical to KotOR I's current build: it uses only
            # routines both games share, below 768.
            '6101F0ED7C91B44641C20371125EDA3511EBFB38B559EE16B2105B65110CFEB6'
        )
        'crs_pulse.ncs' = @(
            # 4457 bytes: eleven equipment slots (K2-D12).
            'F69C7E4B5EA9D657E5A195705CD028625D715B906C882B7E9BBFAF0B749CA692'
        )
        'crs_dress.ncs' = @(
            # 5402 bytes: also clears the second weapon set (18, 19).
            'ED8D6CD81E1FDD816EAC454623632731BDF77B59D4C5B98DDA375B06AFFE4B04'
        )
        'crs_act.ncs' = @(
            # 9084 bytes.
            '22F2069AF3DE2332242542CFB70D346AB251B7F2E70ED4BB12B49B716F7A24A5'
        )
        'crs_health.ncs' = @(
            # 3020 bytes: KotOR II's twelve companions, the main character at 12.
            'E8C042E98F7EEC1C6EF3D8C3811F3F793E94C30C40517BA6079EF3503ADC4728'
        )
        'crs_party.ncs' = @(
            # 2483 bytes: walks companions 0..11.
            '90BBD37548357DFC8389A81F3D867B65CDCBDAD57B0649159CA7579FBEB69201'
        )
        'crs_bag.ncs' = @(
            # 1275 bytes.
            'A4BBE13D5D6443697FD7784C4658BD7E9462C201D8FE385A429FC0A61A35ADDC'
        )
    }
    $records = @()
    foreach ($name in @(
            'cr_orig_hb.ncs',
            'k_def_heartbt01.ncs',
            'crs_pulse.ncs',
            # MUST BE TRACKED, not just installed. This list is what
            # Restore-OwnedFiles walks on the way out, so a payload file missing
            # from it is one Crossroads writes into somebody's Override and then
            # leaves behind forever.
            'crs_dress.ncs',
            # spells.2da IS DIFFERENT FROM EVERY OTHER FILE HERE, and getting
            # this wrong would damage somebody's install.
            #
            # Every other name in this list is one Crossroads invented, so a
            # file at that path can only be ours. spells.2da is a STOCK GAME
            # TABLE, and a player may legitimately have a modded one. It is
            # therefore backed up and restored like the retail heartbeat, not
            # treated as ours to delete -- and the copy we install is DERIVED
            # from whatever was already there, so a mod's rows survive.
            'spells.2da',
            # crs_act.ncs -- NEW 2026-09-08, Stage 3. It PERFORMS a peer's
            # action on this engine, and it is here for the same reason
            # crs_dress is: a payload file missing from this walk is one
            # Crossroads writes into somebody's Override and leaves forever.
            'crs_act.ncs',
            # crs_health.ncs -- 2026-10-29, in this walk for crs_act's reason.
            'crs_health.ncs',
            # crs_bag.ncs -- co-op Phase 2, 2026-10-26. In this walk for crs_act's
            # reason: a payload file missing from it is one Crossroads writes into
            # somebody's Override and leaves there forever.
            'crs_bag.ncs',
            # crs_party.ncs -- 2026-10-26, for the same reason as crs_bag.
            'crs_party.ncs',
            'crossroadsghost.utc',
            # The eight per-peer slot templates. Restored to this walk with
            # the block that creates them -- they are written on every join
            # and were, for three weeks, in nobody's restore walk.
            'crsghost0.utc', 'crsghost1.utc', 'crsghost2.utc',
            'crsghost3.utc', 'crsghost4.utc', 'crsghost5.utc',
            'crsghost6.utc', 'crsghost7.utc')) {
        $target = Join-Path $override $name
        $existed = Test-Path -LiteralPath $target
        $crossroadsOwned = $false
        if ($existed -and $known.ContainsKey($name)) {
            $actual = (Get-FileHash -LiteralPath $target `
                -Algorithm SHA256).Hash
            if ($known[$name] -notcontains $actual) {
                throw ("An unrelated Override\$name is installed. Crossroads " +
                       "will not replace it.`n`nIf you are certain it is not " +
                       "from another mod, delete it and rejoin.`n" +
                       "Found SHA-256: $actual")
            }
            # Past the gate above, the hash IS one of ours.
            $crossroadsOwned = $true
        }
        # crossroadsghost.utc carries no hash list because it is generated from
        # the player's own character, so its bytes differ on every machine and
        # every session. Ownership is settled by the NAME instead: that ResRef
        # is one Crossroads invented, and stock KotOR has no such template, so
        # a file at this path cannot be anybody else's.
        # The slot templates are owned by NAME, like crossroadsghost.utc: the
        # mirror rewrites their bytes per session with each peer's appearance,
        # so no hash list can ever describe them, and crsghost<N> is a ResRef
        # Crossroads invented -- a file at that path cannot be anybody else's.
        if ($existed -and ($name -eq 'crossroadsghost.utc' -or
                $name -match '^crsghost[0-7]\.utc$')) {
            $crossroadsOwned = $true
        }

        # A FILE WE RECOGNISE AS OUR OWN IS NOT THE PLAYER'S FILE, AND MUST NOT
        # BE RESTORED.
        #
        # Stock KotOR ships k_def_heartbt01 inside a BIF with nothing in
        # Override, and cr_orig_hb.ncs is a name only Crossroads writes. So a
        # recognised file here was left by US -- by a session that ended
        # abnormally, before Restore-OwnedFiles could run.
        #
        # Recording it as pre-existing made that damage permanent AND
        # self-perpetuating: the next join backed our own leftover up as if it
        # were the player's, and every clean exit afterwards faithfully put it
        # back. Measured 2026-08-08 on the development machine, which had been
        # running a 2026-08-07 Crossroads heartbeat (0534505A...) as the
        # default creature heartbeat in single-player for a day, reinstalled
        # after every session, while the installed component shipped a
        # different one. It is also why Assert-CrossroadsKotorInstall reported
        # a heartbeat mismatch after every clean session -- the tool was right
        # and the restore was wrong.
        #
        # "Nothing" is the correct previous state, and recording it makes an
        # abnormal exit self-healing instead of permanent. Both files come back
        # on the next join: cr_orig_hb.ncs is re-extracted from the player's own
        # install, k_def_heartbt01.ncs is copied from the component.
        #
        # This does NOT weaken the foreign-mod gate. An unrecognised file still
        # throws above and is never written to, backed up, or deleted.
        if ($crossroadsOwned) {
            $records += [pscustomobject]@{ name = $name; existed = $false }
            continue
        }
        if ($existed) {
            Copy-Item -LiteralPath $target `
                -Destination (Join-Path $backup $name) -Force
        }
        $records += [pscustomobject]@{ name = $name; existed = $existed }
    }
    $settingsPath = Join-Path $Game 'swkotor2.ini'
    if (-not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) {
        throw 'KotOR has no swkotor2.ini. Launch the game once before joining Crossroads.'
    }
    Copy-Item -LiteralPath $settingsPath `
        -Destination (Join-Path $backup 'swkotor2.ini') -Force
    $gpuPreferencePath =
        'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    $gameExecutable = Join-Path $Game 'swkotor2.exe'
    $existingGpuPreference = $null
    $gpuPreferenceExisted = $false
    if (Test-Path -LiteralPath $gpuPreferencePath) {
        try {
            $existingGpuPreference = Get-ItemPropertyValue `
                -LiteralPath $gpuPreferencePath `
                -Name $gameExecutable `
                -ErrorAction Stop
            $gpuPreferenceExisted = $true
        }
        catch {
            $gpuPreferenceExisted = $false
        }
    }
    [pscustomobject]@{
        game = $Game
        files = $records
        settingsBackedUp = $true
        gpuPreference = [pscustomobject]@{
            executable = $gameExecutable
            existed = $gpuPreferenceExisted
            value = $existingGpuPreference
        }
    } |
        ConvertTo-Json -Depth 4 |
        Set-Content -LiteralPath $installRecord -Encoding UTF8
}

function Set-KotorHighPerformanceGpu {
    param([string]$Game)
    $gpuPreferencePath =
        'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    New-Item -Path $gpuPreferencePath -Force | Out-Null
    New-ItemProperty `
        -LiteralPath $gpuPreferencePath `
        -Name (Join-Path $Game 'swkotor2.exe') `
        -PropertyType String `
        -Value 'GpuPreference=2;' `
        -Force | Out-Null
}

# THE WINDOW KOTOR SHOULD OPEN AT: the WHOLE primary screen, borderless (owner's
# choice, 2026-10-28). Windowed because the alert asking the host to save is a
# window of its own, and drawing it over exclusive fullscreen changed the game's
# resolution; borderless and screen-sized because the owner wants it to fill the
# screen ("It's useless if it only works for mine").
#
# IT HAS TO BE ONE OF THE SCREEN'S OWN DISPLAY MODES. KotOR looks the ini size up
# in the mode list at start-up and drops to 800x600 when it is not there --
# MEASURED on PC1: a work-area fit of 2536x1472 opened at 800x600. The screen's
# CURRENT mode is always in that list, so that is what is returned, with its
# refresh rate, which KotOR matches on as well. KSE then takes the frame off
# ([Graphics Options] CrossroadsBorderless=1) and lays the window over the screen.
#
# IN REAL PIXELS. KSE makes KotOR DPI-aware, so its size means real screen
# pixels; a display mode is always reported in real pixels whatever this
# PowerShell's own DPI awareness, which is why the mode is asked for rather than
# the screen's bounds.
#
# $null WHEN IT CANNOT BE MEASURED, and the caller then leaves the size alone
# rather than guessing one.
function Get-KotorWindowFit {
    try {
        if (-not ('CrossroadsDisplayMode' -as [type])) {
            Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class CrossroadsDisplayMode {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct DEVMODE {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
        public short dmSpecVersion, dmDriverVersion, dmSize, dmDriverExtra;
        public int dmFields, dmPositionX, dmPositionY, dmDisplayOrientation, dmDisplayFixedOutput;
        public short dmColor, dmDuplex, dmYResolution, dmTTOption, dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel, dmPelsWidth, dmPelsHeight, dmDisplayFlags, dmDisplayFrequency;
        public int dmICMMethod, dmICMIntent, dmMediaType, dmDitherType, dmReserved1, dmReserved2;
        public int dmPanningWidth, dmPanningHeight;
    }
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern bool EnumDisplaySettings(string device, int mode, ref DEVMODE devMode);
    // ENUM_CURRENT_SETTINGS of the primary display (a null device name).
    public static int[] Current() {
        DEVMODE mode = new DEVMODE();
        mode.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
        if (!EnumDisplaySettings(null, -1, ref mode)) return null;
        return new int[] { mode.dmPelsWidth, mode.dmPelsHeight, mode.dmDisplayFrequency };
    }
}
"@ -ErrorAction Stop
        }
        $mode = [CrossroadsDisplayMode]::Current()
        if ($null -eq $mode) { return $null }
        $width = [int]$mode[0]
        $height = [int]$mode[1]
        $refresh = [int]$mode[2]
        if ($width -lt 800 -or $height -lt 600) { return $null }
        return [pscustomobject]@{ Width = $width; Height = $height; RefreshRate = $refresh }
    }
    catch {
        Write-Host ("Could not read the screen's resolution for KotOR's window, so " +
            "its size is left as it was: $($_.Exception.Message)") -ForegroundColor DarkGray
        return $null
    }
}

function Set-KotorCompatibilityProfile {
    param([string]$Game)
    $settingsPath = Join-Path $Game 'swkotor2.ini'
    $lines = [Collections.Generic.List[string]]::new()
    $lines.AddRange([string[]](Get-Content -LiteralPath $settingsPath))

    $sectionStart = -1
    for ($index = 0; $index -lt $lines.Count; ++$index) {
        if ($lines[$index].Trim() -ieq '[Graphics Options]') {
            $sectionStart = $index
            break
        }
    }
    if ($sectionStart -lt 0) {
        if ($lines.Count -gt 0 -and $lines[$lines.Count - 1] -ne '') {
            $lines.Add('')
        }
        $lines.Add('[Graphics Options]')
        $sectionStart = $lines.Count - 1
    }

    $sectionEnd = $lines.Count
    for ($index = $sectionStart + 1; $index -lt $lines.Count; ++$index) {
        if ($lines[$index].Trim() -match '^\[.+\]$') {
            $sectionEnd = $index
            break
        }
    }

    # WINDOWED, SIZED TO THE SCREEN (owner, 2026-10-28). Fullscreen was handed
    # back to the player earlier the same evening and then found to break: the
    # in-game alert that asks the host to save when a guest joins is a window of
    # its own, and drawing it over exclusive fullscreen changed the game's
    # resolution. So a join is windowed again -- the D-entry's "where a game
    # cannot be drawn over in exclusive fullscreen, that game requires windowed"
    # -- but at the screen's size rather than KotOR's small default, which is
    # what made the old windowed mode a small square in the middle.
    #
    # The file is backed up before this and restored after the session, so the
    # player's own display settings come back when they stop playing.
    $fit = Get-KotorWindowFit
    $displaySettings = @(
        [pscustomobject]@{ Key = 'AllowWindowedMode'; Value = '1' },
        [pscustomobject]@{ Key = 'FullScreen'; Value = '0' })
    if ($fit) {
        $displaySettings += [pscustomobject]@{ Key = 'Width'; Value = [string]$fit.Width }
        $displaySettings += [pscustomobject]@{ Key = 'Height'; Value = [string]$fit.Height }
        # Matched along with the size; a rate the mode list lacks drops KotOR to 800x600.
        if ($fit.RefreshRate -gt 1) {
            $displaySettings += [pscustomobject]@{ Key = 'RefreshRate'; Value = [string]$fit.RefreshRate }
        }
        $displaySettings += [pscustomobject]@{ Key = 'CrossroadsBorderless'; Value = '1' }
        $script:kotorWindowSize = "$($fit.Width)x$($fit.Height)"
    }
    foreach ($setting in @($displaySettings + @(
            [pscustomobject]@{ Key = 'Anisotropy'; Value = '0' },
            [pscustomobject]@{ Key = 'Frame Buffer'; Value = '0' },
            [pscustomobject]@{ Key = 'Grass'; Value = '0' }))) {
        $found = $false
        for ($index = $sectionStart + 1; $index -lt $sectionEnd; ++$index) {
            if ($lines[$index] -match (
                    '^\s*' + [regex]::Escape($setting.Key) + '\s*=')) {
                $lines[$index] = "$($setting.Key)=$($setting.Value)"
                $found = $true
                break
            }
        }
        if (-not $found) {
            $lines.Insert(
                $sectionEnd,
                "$($setting.Key)=$($setting.Value)")
            ++$sectionEnd
        }
    }

    [IO.File]::WriteAllLines(
        $settingsPath,
        $lines,
        [Text.Encoding]::Default)
}

# Install KSE (K1SE) into the game directory. Crossroads depends on it for
# engine-sourced local-player identity (D12), so it is bundled rather than a
# tester prerequisite (D15).
#
# THE ORDER HERE IS THE WHOLE SAFETY ARGUMENT. KSE installs AS binkw32.dll and
# forwards to the renamed original. binkw32.dll is a real game import: if this
# machine is ever left without one, KotOR does not launch at all -- a worse
# outcome than any sync bug, and one the player cannot diagnose because they
# never reach a menu.
#
# So: COPY the original aside, VERIFY the copy, and only then overwrite. At no
# instant does binkw32.dll fail to exist. A move-first sequence would open a
# window where a crash, a full disk, or antivirus quarantine leaves no game.
#
# We never ship the original. It is RAD Game Tools' Bink -- retail content --
# and the packager refuses to build if a copy reaches an archive. Same rule as
# the stock heartbeat under D11.
#
# UNINSTALL IS DELIBERATE, NOT AUTOMATIC (D15). This is recorded in its own
# state file rather than the per-session install record, because
# Restore-OwnedFiles deletes what it recorded every time KotOR closes. That is
# right for a temporary ghost actor and wrong for a script extender the player
# also uses for their own single-player mods. Uninstall-KSE.ps1 reverses it.
function Install-KSE {
    param([string]$Game)

    $source = Join-Path $component 'kse\binkw32.dll'
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw ('The Crossroads KotOR component is incomplete: kse\binkw32.dll ' +
               'is missing. Restart the launcher to update.')
    }

    $proxy = Join-Path $Game 'binkw32.dll'
    $real = Join-Path $Game 'binkw32_real.dll'
    $record = Join-Path $state 'kse-install-state.json'

    if (-not (Test-Path -LiteralPath $proxy -PathType Leaf)) {
        throw ('Your KotOR folder has no binkw32.dll. Crossroads will not ' +
               'touch it in that state -- verify the game files through Steam ' +
               'first.')
    }

    # Is the proxy already ours? Identify by content, not by name: both files
    # legitimately use this filename, and only their contents distinguish them.
    $proxyText = [Text.Encoding]::ASCII.GetString(
        [IO.File]::ReadAllBytes($proxy))
    $proxyIsKse = $proxyText.Contains('KSE ') -and $proxyText.Contains('STAGE19')
    $sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash

    if ($proxyIsKse) {
        if (-not (Test-Path -LiteralPath $real -PathType Leaf)) {
            throw ('KotOR has a KSE binkw32.dll but no binkw32_real.dll to ' +
                   'forward to. The game cannot start in that state. Verify ' +
                   'the game files through Steam, then rejoin.')
        }
        if ((Get-FileHash -LiteralPath $proxy -Algorithm SHA256).Hash -eq $sourceHash) {
            Write-Host 'Crossroads script extender: already current.'
            return
        }
        # Upgrade in place. The original is already safely aside, so this is a
        # single overwrite with nothing to preserve.
        Copy-Item -LiteralPath $source -Destination $proxy -Force
        Write-Host 'Crossroads script extender: updated.'
        return
    }

    # Fresh install -- but ONLY once $proxy has been positively identified as
    # the retail Bink. It used to be asserted here in a comment and never
    # checked, and the assertion is wrong in exactly the case that matters.
    #
    # THE HOLE THIS CLOSES. The refusal below catches another mod that proxies
    # binkw32.dll only if it also preserved the original under OUR spare name.
    # A third-party extender that renames the original to anything else -- and
    # there is no convention here, the name is ours -- fell straight through to
    # this point, and Crossroads then copied THEIR proxy to binkw32_real.dll,
    # recorded its hash as "the original", and installed over it. The retail
    # Bink then survived only inside their spare file, and Uninstall-KSE.ps1
    # would later restore their proxy and report the game was back to its
    # original DLL. Both installs destroyed, silently, and the report was a lie.
    #
    # `RAD Game Tools` is the discriminator, MEASURED IN BOTH DIRECTIONS on
    # 2026-08-10 rather than assumed: it is present in retail Bink and absent
    # from the KSE proxy. The obvious-looking `Bink` is present in BOTH -- the
    # proxy has to export the same names -- so it identifies nothing. The
    # packager's own ship-time gate relies on the same pair of facts.
    if (Test-Path -LiteralPath $real -PathType Leaf) {
        throw ('KotOR already has a binkw32_real.dll but its binkw32.dll is ' +
               'not KSE. Another mod uses the same mechanism, and Crossroads ' +
               'will not overwrite it.')
    }

    if (-not $proxyText.Contains('RAD Game Tools')) {
        throw ('KotOR''s binkw32.dll is neither the retail file nor the ' +
               'Crossroads script extender, so something else installed it. ' +
               'Crossroads will not overwrite it -- doing so would bury that ' +
               'mod''s file as if it were your original, and neither could be ' +
               'restored afterwards. Uninstall the other mod, or verify the ' +
               'game files through Steam, then rejoin.')
    }

    Copy-Item -LiteralPath $proxy -Destination $real -Force
    $originalHash = (Get-FileHash -LiteralPath $proxy -Algorithm SHA256).Hash
    if ((Get-FileHash -LiteralPath $real -Algorithm SHA256).Hash -ne $originalHash) {
        Remove-Item -LiteralPath $real -Force -ErrorAction SilentlyContinue
        throw ('Crossroads could not safely preserve the original ' +
               'binkw32.dll, so it changed nothing.')
    }

    Copy-Item -LiteralPath $source -Destination $proxy -Force

    [pscustomobject]@{
        game = $Game
        installed = (Get-Date).ToString('o')
        originalSha256 = $originalHash
        proxySha256 = $sourceHash
    } |
        ConvertTo-Json -Depth 3 |
        Set-Content -LiteralPath $record -Encoding UTF8

    Write-Host 'Crossroads script extender installed.' -ForegroundColor Green
    Write-Host ('  Your original binkw32.dll was preserved as ' +
                'binkw32_real.dll. It stays installed after you disconnect; ' +
                'run Uninstall-KSE.ps1 to reverse it.')
}

function Restore-OwnedFiles {
    # THE SESSION'S ROLE ENDS WITH THE SESSION (2026-10-29, owner's decision).
    # The join writes coop_role.txt -- and a guest's coop_companion.txt -- when a
    # session starts, and nothing ever removed them, so every plain launch of
    # KotOR afterwards ran in the last session's role. MEASURED on PC1: a guest
    # session on the evening of 2026-10-28 left "guest", and every single-player
    # launch the next morning started with the extender's guest gates and its
    # companion assignment armed. Cleared here, before the install-record check,
    # because this runs on every way out -- a clean close, a crash, and the next
    # join recovering an interrupted one -- and a stale role from a build older
    # than this fix has no install record to hang it on. A join writes both
    # afresh after this, so clearing early costs nothing.
    foreach ($sessionFile in @('coop_role.txt', 'coop_companion.txt')) {
        $sessionPath = Join-Path $env:LOCALAPPDATA "KSE2\$sessionFile"
        if (Test-Path -LiteralPath $sessionPath -PathType Leaf) {
            Remove-Item -LiteralPath $sessionPath -Force -ErrorAction SilentlyContinue
            if (Test-Path -LiteralPath $sessionPath -PathType Leaf) {
                Write-Host ("Could not remove $sessionPath; the next plain launch of " +
                    'KotOR will still behave as part of the last co-op session.') `
                    -ForegroundColor Yellow
            }
        }
    }
    if (-not (Test-Path -LiteralPath $installRecord)) {
        return
    }
    $record = Get-Content -LiteralPath $installRecord -Raw | ConvertFrom-Json
    $override = Join-Path $record.game 'Override'
    foreach ($file in $record.files) {
        $target = Join-Path $override $file.name
        if ($file.existed) {
            Copy-Item -LiteralPath (Join-Path $backup $file.name) `
                -Destination $target -Force
        }
        elseif (Test-Path -LiteralPath $target) {
            Remove-Item -LiteralPath $target -Force
        }
    }
    if ($record.PSObject.Properties.Name -contains 'settingsBackedUp' -and
        $record.settingsBackedUp) {
        Copy-Item -LiteralPath (Join-Path $backup 'swkotor2.ini') `
            -Destination (Join-Path $record.game 'swkotor2.ini') -Force
    }
    if ($record.PSObject.Properties.Name -contains 'gpuPreference' -and
        $record.gpuPreference) {
        $gpuPreferencePath =
            'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
        if ($record.gpuPreference.existed) {
            New-Item -Path $gpuPreferencePath -Force | Out-Null
            New-ItemProperty `
                -LiteralPath $gpuPreferencePath `
                -Name $record.gpuPreference.executable `
                -PropertyType String `
                -Value $record.gpuPreference.value `
                -Force | Out-Null
        }
        elseif (Test-Path -LiteralPath $gpuPreferencePath) {
            Remove-ItemProperty `
                -LiteralPath $gpuPreferencePath `
                -Name $record.gpuPreference.executable `
                -ErrorAction SilentlyContinue
        }
    }
    Remove-Item -LiteralPath $installRecord -Force
    if (Test-Path -LiteralPath $backup) {
        Remove-Item -LiteralPath $backup -Recurse -Force
    }
}

if (-not (Test-Path -LiteralPath $component)) {
    throw 'The Crossroads KotOR component is missing. Restart the launcher to update.'
}
if (Get-Process 'swkotor2' -ErrorAction SilentlyContinue) {
    throw 'Close KotOR before joining the Crossroads test server.'
}
# Recover automatically from an older interrupted client session. A previous
# build required users to return to its console and press Enter after closing
# KotOR, so abandoned install records may legitimately remain.
if (Test-Path -LiteralPath $installRecord) {
    Restore-OwnedFiles
    Write-Host 'Crossroads restored temporary files from the previous session.'
}
# AND THE SAVES, from a session that was killed rather than closed. Deliberately
# separate from the install record above: the saves swap happens BEFORE
# Backup-OwnedFiles writes that record, so a failure in between would leave saves
# parked with no install record to notice it. Its own record, restored on its own
# terms, and unconditionally -- even a join that is about to fail for some other
# reason must not leave a player's saves under a name they do not know.
Restore-CrossroadsSaves

# THE DESTINATION. Supplied by the launcher when it knows one, from the INI
# when it does not.
#
# The two paths are kept visibly apart rather than merged, because they have
# different fallback rules and merging them is how one quietly acquires the
# other's. A launcher-supplied endpoint is used EXACTLY as given: no LAN
# fallback, no INI overlay, no loopback substitution. The launcher already
# measured that address with the game's own status probe and chose it; second-
# guessing it here would send the player somewhere they did not select.
if (-not [string]::IsNullOrWhiteSpace($ServerHost) -and $ServerPort -gt 0) {
    $hostName = $ServerHost
    $port = [uint16]$ServerPort
    Write-Host ("Joining the server selected in the launcher: {0}:{1}" -f $hostName, $port)
    # SAID OUT LOUD, because a silently ignored argument is how a feature looks
    # switched on while doing nothing. If this ever prints, the launcher is
    # newer than this component and something it asked for is not happening.
    if ($UnknownArguments.Count -gt 0) {
        Write-Host ''
        Write-Host ('This launcher asked for something this KotOR component ' +
                    'does not know about, and it was IGNORED:') -ForegroundColor Yellow
        Write-Host ('  ' + ($UnknownArguments -join ' ')) -ForegroundColor Yellow
        Write-Host ('The join continues. Press Join once to update this game''s ' +
                    'files if a feature seems to be missing.') -ForegroundColor Yellow
        Write-Host ''
    }
}
else {
    $publicHost = Read-IniValue 'kotor2' 'server_host'
    $lanHost = Read-OptionalIniValue 'kotor2' 'server_lan_host'
    $port = [uint16](Read-IniValue 'kotor2' 'server_port')
    $hostName = ''
    if (Get-Process 'CrossroadsKotor2Server' -ErrorAction SilentlyContinue) {
        $hostName = '127.0.0.1'
    }
    elseif (Test-KotorServerHost $publicHost $port) {
        $hostName = $publicHost
    }
    elseif ($lanHost -ne $publicHost -and
        (Test-KotorServerHost $lanHost $port)) {
        $hostName = $lanHost
    }
    if (-not $hostName) {
        throw 'The Crossroads KotOR test server is not reachable.'
    }
}
$game = Get-GameDirectory $GameDirectory

# THE SESSION OPENS BEFORE THE GAME STARTS, which is the property the session
# record wants: an attempt that fails to launch is still an attempt. The save
# rule runs immediately after it, so the saves the player is allowed to load are
# in place before KotOR is given a chance to read any of them.
#
# The ordering paragraph that used to be here explained why the session had to
# open before the saves folder was SCANNED FOR AN IDENTITY. Nothing scans it any
# more -- that was register 39 -- so the constraint is gone with the code.
Open-CrossroadsSession 'kotor2' $hostName $port
Enter-CrossroadsSaveSession $game

$clientId = Get-ClientId
New-Item -ItemType Directory -Force `
    -Path $localState,$remoteState | Out-Null

# Records what is in Override so Restore-OwnedFiles can put it back, and backs up
# swkotor.ini and the GPU preference that the compatibility profile is about to
# change. With nothing installed it records our filenames as absent, so a
# leftover from a session that ended abnormally is CLEANED UP on exit rather than
# left behind.
Backup-OwnedFiles $game
# KOTOR II LEAVES THE PLAYER'S DISPLAY SETTINGS ALONE (plan 2026-11-15, step 9).
# KotOR I's join forces a borderless window at the screen's own mode, which pairs
# with KotOR I's in-extender widescreen -- switched off in the KotOR II extender --
# and turns off anisotropy, frame buffer and grass for reasons measured on KotOR I
# only. The Aspyr KotOR II build handles its own resolution. Nothing here is
# checked for KotOR II, so swkotor2.ini's [Graphics Options] is not touched.
Write-Host 'KotOR II: your display settings are left as they are.' -ForegroundColor DarkGray
# Set-KotorCompatibilityProfile $game   -- KotOR I only, see above
# Must happen before the game launches: KSE is loaded by swkotor.exe at startup
# through the binkw32 import, so installing it afterwards has no effect until the
# next run.
Install-KSE $game

# ---- DISCORD'S 32-BIT GAME HOOK -----------------------------------------------
#
# IT IS NOW DISABLED AUTOMATICALLY, AND THAT REVERSES WHAT THIS BLOCK USED TO
# SAY. It read "REPORTS. NEVER CHANGES ANYTHING. Discord is the player's own
# program and a join has no business editing another application's files."
# Changed 2026-10-22 on the owner's explicit instruction: *"yes have the join
# disable the discord hook automatically"* (D87).
#
# WHY THE OLD POSITION LOST. Reporting it was tried for weeks and did not work.
# A Discord update installs a fresh app-<version> folder carrying a new copy, so
# the warning comes back as often as Discord ships -- three times in three days
# on 2026-10-20/21/22, and the third one CRASHED A TWO-MACHINE RUN mid-session
# with the Visual C++ Runtime Error. A warning that the player must act on, in a
# console that scrolls past while the game launches, is not protection.
#
# WHAT IT LEAKS, so the trade is on the record: roughly 450 threads a second
# into a 32-bit game whenever that game has no presentable surface -- minimised,
# or alt-tabbed out of fullscreen. Each thread reserves a megabyte of stack, a
# 32-bit process has about 2 GB, and KotOR plus its modules already costs
# ~800 MB. One three-second minimise is enough.
# (FINDINGS_2026-08-26-pc1-kotor-crash.md, proven by a five-run elimination and
# reproduced on KotOR II.)
#
# WHAT IT TOUCHES, AND WHAT IT REFUSES TO TOUCH:
#   * ONLY DiscordHook.dll, the 32-BIT hook. DiscordHook64.dll is never looked
#     at, so the overlay and Clips keep working in every 64-bit game.
#   * RENAMED, NEVER DELETED. The file keeps its place with a suffix, so this
#     is reversible by hand and by Enable-DiscordGameHook.cmd.
#   * NO Discord SETTING is read or written. Their per-game overlay toggle was
#     already off for KotOR on the affected machine and the hook injected
#     anyway -- the setting governs whether the overlay DRAWS, not whether the
#     hook LOADS.
#
# DISCORD IS STOPPED AND RESTARTED, because the file cannot be renamed while it
# is held. That is intrusive and it is said out loud rather than done quietly.
#
# NON-FATAL AT EVERY STEP. No Discord, a locked file, a path shape that has
# changed, a restart that does not come back -- each leaves the join exactly as
# it was. A convenience that can stop somebody playing would be a bad trade.
try {
    $discordRoot = Join-Path $env:LOCALAPPDATA 'Discord'
    if (Test-Path -LiteralPath $discordRoot -PathType Container) {
        $hookSuffix = '.crossroads-disabled'
        $activeHooks = @(Get-ChildItem -Path $discordRoot -Recurse -Force `
            -Filter 'DiscordHook.dll' -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -match 'discord_hook' })

        if ($activeHooks.Count -eq 0) {
            Write-Host 'Discord 32-bit game hook: not present (good).'
        }
        else {
            Write-Host ''
            Write-Host 'TURNING OFF DISCORD''S 32-BIT GAME HOOK' -ForegroundColor Yellow
            Write-Host ("  Found $($activeHooks.Count) copy/copies. It leaks threads into KotOR until")
            Write-Host '  the game runs out of address space and crashes. Not a Crossroads'
            Write-Host '  fault, and a Discord update turns it back on by itself.'

            # STOPPED FIRST, or the rename fails on a held file. Only Discord's
            # own processes, by name, and only if some are running.
            $discordProcesses = @(Get-Process -Name 'Discord', `
                'DiscordSystemHelper', 'DiscordHookHelper' -ErrorAction SilentlyContinue)
            $wasRunning = $discordProcesses.Count -gt 0
            if ($wasRunning) {
                Write-Host ("  Closing Discord ($($discordProcesses.Count) processes) so the file can be renamed.")
                Stop-Process -InputObject $discordProcesses -Force -ErrorAction SilentlyContinue
                Start-Sleep -Seconds 6
            }

            $renamed = 0
            foreach ($hook in $activeHooks) {
                try {
                    Rename-Item -LiteralPath $hook.FullName `
                        -NewName ($hook.Name + $hookSuffix) -Force -ErrorAction Stop
                    $renamed++
                }
                catch {
                    Write-Host ("  Could not rename " + $hook.FullName + ': ' +
                                $_.Exception.Message) -ForegroundColor DarkGray
                }
            }
            Write-Host ("  Disabled $renamed of $($activeHooks.Count).")
            Write-Host '  Your overlay and Clips still work in 64-bit games.' -ForegroundColor DarkGray
            Write-Host '  To undo: games\kotor1\tools\Enable-DiscordGameHook.cmd' -ForegroundColor DarkGray

            # PUT BACK WHAT WE CLOSED. Leaving a player's Discord shut because
            # they pressed Join would be its own bug.
            if ($wasRunning) {
                $discordUpdater = Join-Path $discordRoot 'Update.exe'
                if (Test-Path -LiteralPath $discordUpdater -PathType Leaf) {
                    Write-Host '  Starting Discord again.'
                    Start-Process -FilePath $discordUpdater `
                        -ArgumentList '--processStart', 'Discord.exe' `
                        -ErrorAction SilentlyContinue
                }
                else {
                    Write-Host '  Could not restart Discord automatically; start it when you like.' `
                        -ForegroundColor DarkGray
                }
            }
            Write-Host ''
        }
    }
}
catch {
    # Said quietly rather than swallowed: a check that silently stops checking
    # is worse than no check, because its silence reads as "all clear".
    Write-Host ("Discord hook check skipped: " + $_.Exception.Message) `
        -ForegroundColor DarkGray
}

Write-Host ''
Write-Host 'PROJECT: CROSSROADS - KOTOR CLIENT'
Write-Host '================================='
# SAID OUT LOUD, EVERY JOIN, and the two lines are not the same kind of
# statement. The first describes a RULE and is permanent. The second describes
# what is not built yet and comes out when it is.
#
# The reason for both is the one this project keeps relearning: a player who
# cannot see somebody needs to know whether that is a fault or the current state
# of the project, and a console that says nothing invites the wrong answer.
Write-Host 'Other players appear once they are standing in the world.'
Write-Host ('Nobody is visible from the main menu, during character creation, ' +
            'or on a loading screen -- including you, to them.')
Write-Host 'Everyone in this session syncs. There is no per-machine setting.'
Write-Host ''
Write-Host 'Connecting to the online KotOR test server...'
Write-Host ('KotOR compatibility profile: ' +
    $(if ($script:kotorWindowSize) { "a borderless window filling this screen ($script:kotorWindowSize)" } else { 'windowed at your own size' }) +
    '; unstable legacy graphics effects disabled.')
Write-Host 'KotOR graphics processor: Windows default selection.'

# ---- the join ---------------------------------------------------------------
#
# THE SYNC-OFF BRANCH AND THE IDENTITY BUILD USED TO SIT HERE. Both are gone.
#
# The branch was a whole second join -- launch the game, hold the roster open,
# wait for KotOR to close -- kept beside the real one so a switch could pick
# between them. With the switch deleted there is one path, and a reader no
# longer has to work out which of two launches they are looking at.
#
# The identity build was `CrossroadsBuildIdentity.exe` reading a save to write
# `crossroadsghost.utc`, so the stand-in everybody else saw was assembled from a
# file on disk before the player had chosen anything. Register 39. What ships in
# its place is the SHIPPED TEMPLATE, installed below and identical on every
# machine, dressed live from the equipment channel once a body exists.
#
# WHAT THAT COSTS TODAY, AND IT IS DELIBERATE (Stage 1b): every stand-in wears
# the same face. Appearance and nameplates are the owner's next stage, and the
# banner above says so to the player rather than leaving them to wonder.

$override = Join-Path $game 'Override'

# cr_orig_hb.ncs is the stock KotOR heartbeat script. Our override chains to it
# so normal game behaviour still runs, so it has to be in Override -- but it is
# BioWare's file, not ours, and Crossroads never ships or transfers retail game
# assets (decision D11 in docs/DECISIONS.md). It is therefore taken from THIS
# machine's own KotOR installation, which the player owns, rather than from the
# download.
#
# The hash is the stock script as Crossroads was built and tested against. A
# mismatch means a modified installation, and the extractor refuses rather than
# writing unexpected bytes into Override.
$retailHeartbeat = Join-Path $override 'cr_orig_hb.ncs'
if (-not (Test-Path -LiteralPath $retailHeartbeat)) {
    # Resolved at the top of this script, which looks in the launcher root and
    # then beside this file -- see the note there for the defect that made the
    # single-directory version wrong.
    $extractor = $script:retailResourceScript
    if ([string]::IsNullOrEmpty($extractor)) {
        throw ('Get-KotorRetailResource.ps1 is missing from the Crossroads ' +
               "package. Looked in `"$root`" and `"$here`". " +
               'Reinstall or repair it.')
    }
    try {
        & $extractor -GameDirectory $game -ResRef 'k_def_heartbt01' `
            -ResourceType 2010 -Destination $retailHeartbeat `
            -ExpectedSha256 `
            'A9701608C46A8166C9B68A519BA1C7985EE3E354DF3A2AF1DA8B20041107A50C' |   # KotOR II's k_def_heartbt01 (scripts.bif, 735 bytes); KotOR I's was 1008B0A6...
            Out-Null
    }
    catch {
        throw ("Crossroads could not read the stock heartbeat script from " +
               "your KotOR installation, so it cannot continue.`n`n" +
               "$($_.Exception.Message)`n`n" +
               'Crossroads does not distribute game files, so it takes this ' +
               'one from your own copy of the game.')
    }
}

Copy-Item -LiteralPath (Join-Path $component 'k_def_heartbt01.ncs') `
    -Destination $override -Force

# crs_pulse.ncs -- the script KSE runs from the engine's dispatcher (~4 Hz)
# instead of waiting for a creature to stand within 25 m of the player. Copied
# only if the component carries it, so an older component still installs.
$pulsePayload = Join-Path $component 'crs_pulse.ncs'
if (Test-Path -LiteralPath $pulsePayload -PathType Leaf) {
    Copy-Item -LiteralPath $pulsePayload -Destination $override -Force
}

# crs_dress.ncs -- the appearance half, called BY NAME from crs_pulse every
# steady-state pulse.
#
# INSTALLED UNCONDITIONALLY, unlike the pulse above it, and the asymmetry is
# deliberate. The pulse is optional because an older component genuinely may not
# carry it and the join must still work. This one is not optional in the same
# way: if crs_pulse is here and this is not, the pulse calls a script that does
# not exist -- which in this engine is SILENT. No error, no log entry, no
# failure. Stand-ins appear in the right place and are never dressed, forever,
# and the only symptom is everybody wearing the template's kit.
#
# So a component carrying the pulse but not the dress is a broken package rather
# than an old one, and it is said out loud here rather than discovered by a
# tester. The packager refuses to build that pair at all
# (Assert-KotorPayloadMatchesExtender); this is the second line, for a component
# assembled some other way.
$dressPayload = Join-Path $component 'crs_dress.ncs'
if (Test-Path -LiteralPath $dressPayload -PathType Leaf) {
    Copy-Item -LiteralPath $dressPayload -Destination $override -Force
}
elseif (Test-Path -LiteralPath $pulsePayload -PathType Leaf) {
    throw ('This Crossroads component carries crs_pulse.ncs without ' +
           "crs_dress.ncs.`n`nThe two are halves of one lifecycle and the " +
           'first calls the second by name. Running with only one of them ' +
           'produces other players who appear correctly and are never dressed, ' +
           "with nothing reported anywhere.`n`n" +
           'Update Crossroads and rejoin.')
}
# crs_act.ncs -- Stage 3, the script that PERFORMS a peer's action on this
# engine. Run BY NAME from KSE's own clock, beside crs_pulse and crs_dress.
#
# INSTALLED ONLY IF THE COMPONENT CARRIES IT, unlike the dress above. The
# asymmetry is deliberate and the opposite way round: nothing calls this script
# by name from another script, so a component without it loses peer
# consequences and keeps everything else working. An older component genuinely
# may not have it, and the join must still work -- which is the pulse's rule,
# not the dress's.
$actPayload = Join-Path $component 'crs_act.ncs'
if (Test-Path -LiteralPath $actPayload -PathType Leaf) {
    Copy-Item -LiteralPath $actPayload -Destination $override -Force
}
# crs_bag.ncs -- co-op Phase 2, 2026-10-26 (D93): KSE runs it BY NAME on a co-op
# guest to make the guest's party bag match the host's. Installed if the
# component carries it, on crs_act's rule: nothing calls it from another script,
# so an older component without it loses bag-following and nothing else.
$bagPayload = Join-Path $component 'crs_bag.ncs'
if (Test-Path -LiteralPath $bagPayload -PathType Leaf) {
    Copy-Item -LiteralPath $bagPayload -Destination $override -Force
}
# crs_party.ncs -- 2026-10-26: KSE runs it BY NAME about once a second in a
# co-op session. On the host it reports which companions are in the party; on a
# guest it rebuilds the party to the host's. Installed if the component carries
# it, on crs_bag's rule; absent, KSE says so once in kse.log.
$partyPayload = Join-Path $component 'crs_party.ncs'
if (Test-Path -LiteralPath $partyPayload -PathType Leaf) {
    Copy-Item -LiteralPath $partyPayload -Destination $override -Force
}
# crs_health.ncs -- 2026-10-29: KSE runs it BY NAME twice a second in a co-op
# session. On the host it reports the party's hit points; on a guest it makes the
# party match them. Installed if the component carries it, on crs_bag's rule;
# absent, KSE says so once in kse.log.
$healthPayload = Join-Path $component 'crs_health.ncs'
if (Test-Path -LiteralPath $healthPayload -PathType Leaf) {
    Copy-Item -LiteralPath $healthPayload -Destination $override -Force
}

# ---- THE BOLT SPELL ROWS, built here rather than by a shipped tool ---------
#
# A blaster bolt is drawn by casting a spells.2da row whose projectile model is
# a bolt, and no shipping row carries one: all twelve projectile rows are
# grenades, and the five bolt models live in ammunitiontypes.2da, which only the
# combat engine reads. So the row has to be made.
#
# IT LIVES IN THIS FILE rather than in a tool beside it, and the reason is
# packaging. A NEW file has to be named in the shared packager's staging list,
# which this lane does not own -- so a feature built entirely inside the lane
# could not be shipped from inside it. The join already ships. Everything the
# feature needs now travels in files that were already travelling.
#
# DERIVED, NEVER SHIPPED. A 2DA out of the retail archives is retail game data
# and D11 says Crossroads does not redistribute it. This reads the player's own
# table, exactly as cr_orig_hb is extracted from their install rather than
# carried.
#
# OVERRIDE FIRST, ARCHIVES SECOND, and that ordering is the mod-compatibility
# story: Override replaces a table wholesale, so deriving from the base game
# would silently delete a modded table's rows. Appending to what is actually
# loaded keeps them.
#
# PADDED TO A FIXED INDEX because crs_dress.ncs is compiled once and casts these
# rows BY NUMBER on machines whose tables are different lengths.
function Read-KotorTwoDaBytes {
    param([Parameter(Mandatory = $true)][byte[]]$Bytes)

    $header = [Text.Encoding]::ASCII.GetString($Bytes, 0, 8)
    if ($header -ne '2DA V2.b') {
        throw "Not a binary 2DA V2.b (header is '$header'). ASCII 2DAs are not supported."
    }
    $p = 9
    $columns = @(); $field = ''
    while ($true) {
        $c = $Bytes[$p]; $p++
        if ($c -eq 0) { break }
        if ($c -eq 9) { $columns += $field; $field = '' } else { $field += [char]$c }
    }
    if ($field) { $columns += $field }

    $rowCount = [BitConverter]::ToUInt32($Bytes, $p); $p += 4
    $rowLabels = @()
    for ($i = 0; $i -lt $rowCount; $i++) {
        $start = $p
        while ($Bytes[$p] -ne 9) { $p++ }
        $rowLabels += [Text.Encoding]::ASCII.GetString($Bytes, $start, $p - $start)
        $p++
    }
    $offsetBase = $p
    $p += ($rowCount * $columns.Count * 2)
    $p += 2                      # the data-block size field
    $dataBase = $p

    $rows = @()
    for ($r = 0; $r -lt $rowCount; $r++) {
        $record = [ordered]@{}
        for ($c = 0; $c -lt $columns.Count; $c++) {
            $offset = [BitConverter]::ToUInt16(
                $Bytes, $offsetBase + (($r * $columns.Count) + $c) * 2)
            $i = $dataBase + $offset
            $start = $i
            while ($Bytes[$i] -ne 0) { $i++ }
            $record[$columns[$c]] =
                [Text.Encoding]::ASCII.GetString($Bytes, $start, $i - $start)
        }
        $rows += [pscustomobject]$record
    }
    return [pscustomobject]@{
        Columns = $columns; RowLabels = $rowLabels; Rows = $rows
    }
}

function Write-KotorTwoDaBytes {
    param(
        [Parameter(Mandatory = $true)][string[]]$Columns,
        [Parameter(Mandatory = $true)][string[]]$RowLabels,
        [Parameter(Mandatory = $true)][object[]]$Rows
    )

    $out = New-Object System.IO.MemoryStream
    $w = New-Object System.IO.BinaryWriter($out)
    $w.Write([Text.Encoding]::ASCII.GetBytes("2DA V2.b`n"))
    foreach ($c in $Columns) {
        $w.Write([Text.Encoding]::ASCII.GetBytes($c))
        $w.Write([byte]9)
    }
    $w.Write([byte]0)
    $w.Write([uint32]$Rows.Count)
    foreach ($l in $RowLabels) {
        $w.Write([Text.Encoding]::ASCII.GetBytes($l))
        $w.Write([byte]9)
    }

    # DEDUPLICATED, the way the retail table is. Every distinct cell value is
    # stored once and every cell holding it points at the same offset -- which
    # is not an optimisation here, it is what keeps the block inside the uint16
    # bound on a table this wide.
    $data = New-Object System.IO.MemoryStream
    $seen = @{}
    $offsets = New-Object System.Collections.Generic.List[uint16]
    foreach ($row in $Rows) {
        foreach ($c in $Columns) {
            $value = [string]$row.$c
            if ($null -eq $value) { $value = '' }
            if (-not $seen.ContainsKey($value)) {
                $seen[$value] = [int]$data.Position
                $bytes = [Text.Encoding]::ASCII.GetBytes($value)
                $data.Write($bytes, 0, $bytes.Length)
                $data.WriteByte(0)
            }
            $offsets.Add([uint16]$seen[$value])
        }
    }
    if ($data.Position -gt 65535) {
        throw ("The 2DA data block would be $($data.Position) bytes. Cell " +
               "offsets are uint16, so it must stay under 65,536 -- the engine " +
               "would read wrapped offsets and the table would be silently " +
               "wrong rather than rejected.")
    }
    foreach ($o in $offsets) { $w.Write([uint16]$o) }
    $w.Write([uint16]$data.Position)
    $bytes = $data.ToArray()
    $w.Write($bytes, 0, $bytes.Length)
    $w.Flush()
    return $out.ToArray()
}

function Install-CrossroadsBoltSpells {
    param([string]$GameDirectory, [string]$OverrideDirectory)

    $boltRowBase = 500
    $existing = Join-Path $OverrideDirectory 'spells.2da'
    if (Test-Path -LiteralPath $existing -PathType Leaf) {
        $sourceBytes = [IO.File]::ReadAllBytes($existing)
    }
    else {
        $temp = Join-Path ([IO.Path]::GetTempPath()) `
            ('crs-spells-' + [Guid]::NewGuid().ToString('N') + '.2da')
        if ([string]::IsNullOrEmpty($script:retailResourceScript)) {
            throw ('Get-KotorRetailResource.ps1 is missing from the Crossroads ' +
                   'package, and spells.2da is not in Override, so the bolt ' +
                   'rows cannot be built. Reinstall or repair it.')
        }
        & $script:retailResourceScript `
            -GameDirectory $GameDirectory -ResRef 'spells' `
            -ResourceType 2017 -Destination $temp | Out-Null
        try { $sourceBytes = [IO.File]::ReadAllBytes($temp) }
        finally { if (Test-Path -LiteralPath $temp) { [IO.File]::Delete($temp) } }
    }

    $table = Read-KotorTwoDaBytes -Bytes $sourceBytes
    $rows = [System.Collections.Generic.List[object]]::new()
    foreach ($r in $table.Rows) { $rows.Add($r) }
    $rowLabels = [System.Collections.Generic.List[string]]::new()
    foreach ($l in $table.RowLabels) { $rowLabels.Add($l) }

    if ($rows.Count -gt $boltRowBase) {
        throw ("This spells.2da already has $($rows.Count) rows, at or past the " +
               "fixed Crossroads index $boltRowBase. crs_dress.ncs casts that " +
               'row by number and cannot be told a different one.')
    }
    while ($rows.Count -lt $boltRowBase) {
        $blank = [ordered]@{}
        foreach ($c in $table.Columns) { $blank[$c] = '' }
        $rowLabels.Add([string]$rows.Count)
        $rows.Add([pscustomobject]$blank)
    }

    # One row per ammunition type, in ammunitiontypes.2da order, because that is
    # what the payload indexes by. Each carries its OWN model, so an ion blaster
    # draws an ion bolt.
    $models = @('w_laserfire_r', 'w_laserfire_b', 'w_laserfire_w',
                'w_laserfire_s', 'w_laserfire_bc')
    $labels = @('BLASTER', 'ION', 'DISRUPTOR', 'SONIC', 'BOWCASTER')
    for ($i = 0; $i -lt $models.Count; $i++) {
        $record = [ordered]@{}
        foreach ($c in $table.Columns) { $record[$c] = '' }
        $record['label']           = 'CROSSROADS_BOLT_' + $labels[$i]
        $record['forcepoints']     = '0'
        $record['goodevil']        = '-'
        $record['usertype']        = '4'
        $record['guardian']        = '0'
        $record['consular']        = '0'
        $record['sentinel']        = '0'
        $record['inate']           = '1'
        $record['maxcr']           = '3'
        $record['range']           = 'L'
        $record['conjtime']        = '0'
        $record['casttime']        = '0'
        $record['catchtime']       = '0'
        $record['proj']            = '1'
        $record['projmodel']       = $models[$i]
        # `grenade` is the only projtype in the shipping table that flies. It
        # names the projectile SYSTEM, not the trajectory -- the arc is chosen
        # by the caller's nProjectilePathType. `accelerating` is used instead
        # because the owner confirmed all five flight types read as a blaster
        # shot once the spawn point and orientation were right, and this is the
        # most literal of them.
        $record['projtype']        = 'accelerating'
        # head|hand ONLY -- `throw`, which every shipping grenade row uses, is
        # not a spawn point at all. Read out of swkotor.exe's string table.
        $record['projspwnpoint']   = 'hand'
        # A bolt is a stretched sprite that must lie along its own flight path.
        # Blank is right for a tumbling grenade and wrong for this.
        $record['projorientation'] = 'path'
        # NO impactscript. A replicated bolt is presentation; the shooter's own
        # machine already resolved the shot, and a second machine applying its
        # own damage is the consequences-applied-twice fault.
        $record['itemimmunity']    = '0'
        $record['exclusion']       = '0x02'
        $record['requireitemmask'] = '0x0000'
        $record['forbiditemmask']  = '0x0000'
        $record['hostilesetting']  = '0'
        $rowLabels.Add([string]$rows.Count)
        $rows.Add([pscustomobject]$record)
    }

    $outBytes = Write-KotorTwoDaBytes -Columns $table.Columns `
        -RowLabels $rowLabels -Rows $rows

    # PROVE THE WRITER BEFORE INSTALLING. A 2DA the engine misreads raises no
    # error at all -- it produces a spell that quietly does nothing, and this
    # one is being written into somebody's game directory.
    $check = Read-KotorTwoDaBytes -Bytes $outBytes
    for ($r = 0; $r -lt $table.Rows.Count; $r++) {
        foreach ($c in $table.Columns) {
            if ($check.Rows[$r].$c -ne $table.Rows[$r].$c) {
                throw "Bolt spell rows: original row $r column '$c' changed."
            }
        }
    }
    [IO.File]::WriteAllBytes((Join-Path $OverrideDirectory 'spells.2da'), $outBytes)
}

# KOTOR II: THE BOLT SPELL ROWS ARE NOT WRITTEN (plan 2026-11-15, step 9). They exist
# so other players' blaster bolts can be drawn, which is the combat layer -- and that
# is switched off in the KotOR II extender until its engine values are checked.
# KotOR II's spells.2da also differs from KotOR I's, and this code was checked only
# against KotOR I's, so writing it into a KotOR II game is not something to guess at.
# Said once per join; the player's spells.2da is never touched.
Write-Host ('KotOR II: other players'' blaster bolts are not drawn yet -- the ' +
            'combat layer is not in this build.') -ForegroundColor DarkGray
if ($false) {
try {
    Install-CrossroadsBoltSpells -GameDirectory $GameDirectory `
        -OverrideDirectory $override
}
catch {
    # NOT FATAL. Without the rows a peer's shooting is invisible, which is how
    # things were yesterday; with a half-written spells.2da the game may not
    # start. Losing the feature beats losing the session.
    Write-Host ('Crossroads could not build the bolt spell rows, so other ' +
                "players' blaster bolts will not be drawn this session.") `
        -ForegroundColor DarkGray
}
}   # end of the KotOR II switch-off above

$installedRemoteActor = Join-Path $override 'crossroadsghost.utc'
# EVERY STAND-IN IS BUILT FROM THIS ONE TEMPLATE, and it must be in place before
# the game launches: KotOR caches a missing ResRef for the lifetime of the
# process, so a template that arrives late never resolves at all for that run.
#
# It used to be a placeholder that `CrossroadsApplyIdentity.exe` overwrote with
# the peer's real appearance once the identity exchange completed. There is no
# exchange now, so this IS the appearance -- the same shipped commoner on every
# machine, dressed live from the equipment channel by crs_dress once a body
# exists. Stage 1b replaces this with something per-player.
Copy-Item -LiteralPath (Join-Path $component 'crossroadsghost.base.utc') `
    -Destination $installedRemoteActor -Force

# THE EIGHT SLOT TEMPLATES MUST ALSO EXIST BEFORE THE GAME LAUNCHES
# (CORE_REQUEST 2026-08-17). crs_pulse spawns slots 0-7 from crsghost<N>
# UNCONDITIONALLY, and the same missing-ResRef rule stated above applies: a body
# spawned from a name with no file never resolves for the life of the process.
# The mirror only writes a slot's template once that peer's IDENTITY arrives,
# and the roster is published without waiting for identities -- so on a machine
# that has never had these files, a roster beating the first identity packet by
# one pulse made that peer INVISIBLE for the whole session, silently.
#
# RESTORED 2026-09-08 AFTER BEING LOST TO A FORK. This block existed only in the
# copy the packager shipped; the copy this lane developed -- the one carrying
# the current payload hashes -- never had it. Two files, each holding something
# the other lacked, for three weeks. See
# games\kotor1\FINDINGS_2026-09-08-join-script-diverged.md. There is now one file.
#
# AN EXISTING FILE IS LEFT ALONE: it may hold a previous session's patched
# appearance, and the first identity corrects a stale face while nothing
# corrects a missing file. The bound of 8 must agree with the mirror's
# kAppearanceSlots and crs_pulse's `nSlot < 8`.
foreach ($slot in 0..7) {
    $slotTemplate = Join-Path $override ("crsghost$slot.utc")
    if (-not (Test-Path -LiteralPath $slotTemplate -PathType Leaf)) {
        Copy-Item -LiteralPath (Join-Path $component 'crossroadsghost.base.utc') `
            -Destination $slotTemplate -Force
    }
}

Write-Host ''
# =============================================================================
# TELL THE EXTENDER WHETHER THIS MACHINE IS A CO-OP GUEST.
#
# WHY IT HAS TO BE THE JOIN THAT DECIDES. The extender runs inside the game and
# cannot know what was joined; this script is the only thing that knows. And
# everything the co-op work does -- taking a companion, refusing a friendly NPC
# click, refusing a module change -- MUST NOT HAPPEN in single player or on the
# public servers. Without this file the extender leaves every one of those gates
# off and behaves exactly as the previous build, which is what makes the co-op
# build publishable at all.
#
# GUEST REQUIRES BOTH CONDITIONS, and each rules out a different disaster:
#
#   1. the server is classified 'coop' BY THE DIRECTORY SERVICE. Not by this
#      script and not by the server itself -- the comment in
#      Open-CrossroadsSession already explains why a client naming its own
#      classification is worthless. Without this test, joining the public RP
#      server would possess the player.
#   2. the relay is NOT running on this machine. That is the same host test the
#      endpoint resolution above already uses: a relay in this process list means
#      this is the host, and K9 says the host plays their own character.
#
# ANY OTHER COMBINATION WRITES 'host', which the extender treats as "not a
# guest". Failing towards the old behaviour is deliberate: if the directory is
# down and the classification is unknown, a player gets an ordinary session
# rather than a surprise.
$coopRolePath = Join-Path $env:LOCALAPPDATA 'KSE2\coop_role.txt'
try {
    # "IS THIS MACHINE THE HOST?" -- ANSWERED BY WHAT WAS JOINED, NOT BY WHAT
    # IS RUNNING (2026-10-28). This was `Get-Process 'CrossroadsKotor2Server'`:
    # any relay on the machine made it the host. MEASURED THAT EVENING: PC1
    # runs the operator's always-on public relay, joined PC2's co-op server,
    # and was written 'host' -- no handoff request, no guest rules, and PC2 was
    # never asked to save. It had never shown because PC1 had always hosted.
    #
    # NOW: the launcher says -CoopHost when it started this server, and a
    # server whose address is THIS machine (loopback, or one of its own
    # addresses -- a host who pressed Join on its own row) is the host's too. A
    # relay merely running here for some OTHER server proves nothing.
    $relayIsLocal = [bool]$CoopHost
    if (-not $relayIsLocal) {
        $joinedAddress = [string]$hostName
        if ($joinedAddress -match '^127\.' -or $joinedAddress -ieq 'localhost') {
            $relayIsLocal = $true
        }
        else {
            try {
                $ownAddresses = @(Get-NetIPAddress -AddressFamily IPv4 `
                    -ErrorAction Stop | ForEach-Object { [string]$_.IPAddress })
                $relayIsLocal = $ownAddresses -contains $joinedAddress
            }
            catch {
                # SAID, and failing towards 'guest' only when the directory
                # already classified this server co-op -- the same rule as
                # before, minus a guess that was wrong for the operator's PC.
                Write-Host ("Could not list this PC's addresses to tell whether " +
                    "the joined server is this PC: $($_.Exception.Message)") `
                    -ForegroundColor DarkGray
            }
        }
    }
    $isCoopServer =
        $script:crossroadsSessionClassification -eq 'coop'
    # THREE ANSWERS, NOT TWO, AND THE THIRD IS WHY. "host" used to mean both
    # "I am hosting a co-op session" and "this is an ordinary session", which
    # are different worlds: in a CO-OP session every player's body already
    # exists on every machine, because everyone loaded the same save, so no
    # stand-in should ever be built. The extender could not tell those apart and
    # kept spawning a copy of the host when a guest arrived.
    #
    # The launcher KNOWS -- it started the relay and passed -CoopHost -- so this
    # says so rather than leaving the extender to guess.
    $coopRole = if ($isCoopServer -and -not $relayIsLocal) { 'guest' }
                elseif ($CoopHost) { 'coophost' }
                else { 'host' }

    $coopRoleDir = Split-Path -Parent $coopRolePath
    if (-not (Test-Path $coopRoleDir)) {
        New-Item -ItemType Directory -Path $coopRoleDir -Force | Out-Null
    }
    # Written without a BOM. A BOM here would make the extender's "guest"
    # comparison fail against an invisible prefix -- the same way a BOM silently
    # killed every curated server row on 2026-09-28.
    [IO.File]::WriteAllText(
        $coopRolePath, "$coopRole`n", [Text.UTF8Encoding]::new($false))

    # CO-OP ONLY, and before anything below can fail: what happened last time.
    if ($coopRole -ne 'host') {
        Send-CrossroadsLastSessionReport -Role $coopRole
    }

    # A COMPANION GIVEN BY A PREVIOUS SESSION'S HOST IS NOT THIS ONE'S. Removed on
    # every join; a guest gets a fresh one with this session's save, below.
    Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'KSE2\coop_companion.txt') `
        -Force -ErrorAction SilentlyContinue
    # NOR IS A PREVIOUS SESSION'S ROSTER (2026-10-28). The mirror rewrote it only
    # while a peer was connected, so the last session's lines outlived it -- and
    # a guest that rejoins keeps its client number, so its OLD companion read as
    # current. Run 2 that day: the host thought PC2 still had Carth, gave it
    # Mission, then bound PC2's movement to Carth from the same stale line.
    Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'KSE2\peer_roster.txt') `
        -Force -ErrorAction SilentlyContinue

    if ($coopRole -eq 'guest') {
        Write-Host ''
        Write-Host 'CO-OP GUEST: you will load in controlling one of the host''s' `
            -ForegroundColor Cyan
        Write-Host 'companions. You cannot talk to friendly NPCs and you cannot' `
            -ForegroundColor Cyan
        Write-Host 'change area -- the host moves the party.' -ForegroundColor Cyan
        Write-Host ''
    }
    else {
        Write-Host ("Co-op role: host or ordinary session " +
            "(classification '$script:crossroadsSessionClassification', " +
            "this PC hosts it: $relayIsLocal) -- no co-op gates.") `
            -ForegroundColor DarkGray
    }
}
catch {
    # A role that cannot be written must not stop a join. The extender's default
    # is "not a guest", so the failure mode is an ordinary session.
    Write-Host ("Could not write the co-op role file; this session will behave " +
        "as an ordinary one. $($_.Exception.Message)") -ForegroundColor Yellow
}

# =============================================================================
# A GUEST TAKES THE HOST'S SAVE BEFORE THE GAME STARTS (D85).
#
# HERE AND NOT LATER, because the save has to be on disk before the player
# reaches the load menu. It is also the last point at which refusing costs
# nothing: the game has not been launched and no files have been moved.
#
# AND IT REFUSES RATHER THAN CONTINUING. A guest that joins without the host's
# save is in its own world with its own party -- the exact fault this exists to
# remove, measured on 2026-10-20. Launching anyway would reproduce it while
# looking like a success, which is how it survived a week in the first place.
# =============================================================================
if ($coopRole -eq 'guest') {
    $handoffServerId = ("{0}:{1}" -f $hostName, $port)
    if (-not (Request-CrossroadsHandoffSave `
            -GameId 'kotor2' -ServerId $handoffServerId -GameDirectory $game)) {
        Write-Host ''
        Write-Host 'NOT JOINING' -ForegroundColor Yellow
        Write-Host ('Co-op needs the host''s save and it did not arrive, so the ' +
                    'game was not started. Your own saves are untouched.')
        Write-Host ''
        Close-CrossroadsSession 'handoff-failed'
        try { Stop-Transcript | Out-Null } catch {}
        exit 1
    }
}

Write-Host 'Launching KotOR...'

$launchedThroughSteam = Start-KotorGame $game
Write-Host 'Load a save or start a new game; other players appear once you are'
Write-Host 'standing in the world, and only those in the same area as you.'

# HOW LONG TO WAIT FOR THE GAME TO APPEAR, AND WHY IT IS NOT FIFTEEN SECONDS.
#
# THIS COST A PLAYER A WHOLE SESSION ON 2026-08-15, silently. A third tester
# joined, their saves were parked and restored, the console printed everything
# above this line -- and then the join THREW, because swkotor.exe had not
# appeared within fifteen seconds of asking Steam to start it. Steam launches the
# game regardless, so they sat in KotOR for the rest of the evening, fully
# playable, with no mirror and no HUD, invisible to everybody and never once in
# the player count. The only trace was a console that stopped mid-way and an
# empty mirror-logs folder.
#
# FIFTEEN SECONDS IS A DIRECT-LAUNCH NUMBER APPLIED TO A STEAM LAUNCH. When this
# script starts swkotor.exe itself the process exists almost immediately. When it
# asks Steam, `-applaunch` returns at once and everything real happens afterwards
# on Steam's clock: starting Steam if it was closed, its update check, the game's
# own startup. On a warm Steam that is a few seconds, which is why this was never
# hit here; on a cold one it is routinely minutes.
#
# SO THE BOUND IS SIZED TO THE ROUTE. The timeout is kept rather than removed --
# waiting forever for a game that will never start is its own failure, and the
# steps below genuinely need a process id -- but a bound that is shorter than the
# thing it is bounding is not a safety check, it is a race.
$gameWaitSeconds = if ($launchedThroughSteam) { 240 } else { 30 }

# AND IT SAYS WHAT IT IS WAITING FOR, on a cadence. The old loop was silent, so a
# player whose join was about to fail saw a console that had simply stopped --
# indistinguishable from one that was working. This is the same rule the mirror's
# discovery loop already follows and for the same reason.
$gameDeadline = [DateTime]::UtcNow.AddSeconds($gameWaitSeconds)
$gameWaitAnnounced = $false
$gameWaitStarted = [DateTime]::UtcNow
do {
    $gameProcess = Get-Process 'swkotor2' -ErrorAction SilentlyContinue |
        Sort-Object StartTime -Descending |
        Select-Object -First 1
    if (-not $gameProcess) {
        $waited = ([DateTime]::UtcNow - $gameWaitStarted).TotalSeconds
        if ($waited -ge 10 -and -not $gameWaitAnnounced) {
            $gameWaitAnnounced = $true
            Write-Host ''
            Write-Host ('Waiting for KotOR to start (up to ' +
                        "$gameWaitSeconds seconds)...")
            if ($launchedThroughSteam) {
                Write-Host ('Steam is starting it. A cold Steam, an update ' +
                            'check or a first launch can take a few minutes; ' +
                            'this is normal.')
            }
        }
        Start-Sleep -Milliseconds 250
    }
} while (-not $gameProcess -and [DateTime]::UtcNow -lt $gameDeadline)
if (-not $gameProcess) {
    # THE MESSAGE NAMES THE ROUTE, because the two causes need different actions
    # from the player and the old one named neither.
    $how = if ($launchedThroughSteam) {
        "Crossroads asked Steam to launch it $gameWaitSeconds seconds ago and " +
        "it has not appeared.`n`nIf Steam was closed, updating, or asked you " +
        'to confirm something, start KotOR from Steam first and then press ' +
        'Join again.'
    }
    else {
        "Crossroads started swkotor2.exe $gameWaitSeconds seconds ago and it is " +
        'not running.'
    }
    throw ("KotOR did not start, so Crossroads cannot connect you to other " +
           "players.`n`n$how`n`nYour own saves are parked and will be put back " +
           'when you close the game.')
}

$injectedModules = Get-KotorInjectedModules $gameProcess.Id
if ($injectedModules -imatch '^DiscordHook\.dll$') {
    Write-Host ''
    Write-Host 'CROSSROADS STABILITY WARNING' -ForegroundColor Yellow
    Write-Host 'Discord Clips attached its capture hook to KotOR.' `
        -ForegroundColor Yellow
    Write-Host 'Disable Discord Settings > Clips, restart Discord, and restart this session.' `
        -ForegroundColor Yellow
    try { [Console]::Beep(660, 180) } catch {}
}

$hudArguments = @(
    $gameProcess.Id.ToString(),
    $hostName,
    $port.ToString()
)
# Capacity is passed ONLY when this install actually knows one, and the HUD
# prints no denominator at all when it is absent. It used to print a hardcoded
# "/ 4" regardless, which said four while the relay held sixty-four.
#
# server_capacity is optional and is the same key the launcher reads for the
# server browser, so the two cannot disagree about this install's own server.
#
# READ FROM crossroads-launcher.ini FIRST, exactly as the launcher does.
# crossroads-network.ini is UPDATER-MANAGED -- it ships inside the platform
# component, so anything hand-edited there is overwritten by the next update
# and the setting silently reverts. crossroads-launcher.ini is shipped by
# nothing and is where a local override belongs. Reading only the managed file
# here would have meant the launcher honouring an override that the HUD never
# saw, which is precisely the disagreement the comment above claims cannot
# happen.
$launcherConfigPath = Join-Path $root 'crossroads-launcher.ini'
$configuredCapacity = ''
if (Test-Path -LiteralPath $launcherConfigPath -PathType Leaf) {
    $current = ''
    foreach ($line in Get-Content -LiteralPath $launcherConfigPath) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') { $current = $Matches[1]; continue }
        if ($current -eq 'kotor2' -and $trimmed -match '^server_capacity=(.*)$') {
            $configuredCapacity = $Matches[1].Trim()
            break
        }
    }
}
if ([string]::IsNullOrWhiteSpace($configuredCapacity)) {
    $configuredCapacity = Read-OptionalIniValue 'kotor2' 'server_capacity'
}
if ($configuredCapacity -match '^\d+$' -and [int]$configuredCapacity -gt 0) {
    $hudArguments += $configuredCapacity
}
$hudProcess = Start-Process `
    -FilePath (Join-Path $component 'CrossroadsKotor2Hud.exe') `
    -ArgumentList $hudArguments -PassThru

# THE MIRROR STARTS NOW, NOT WHEN SOMEBODY ELSE TURNS UP.
#
# WHAT WAS HERE: a blocking wait on CrossroadsIdentityExchange.exe, which sat on
# the relay until a peer arrived, then handed back a 132-byte identity that
# CrossroadsApplyIdentity.exe baked into the stand-in template before the mirror
# was allowed to start. A join could therefore spend its whole session waiting
# for a second player, and the first thing it did on getting one was assemble a
# body from an identity read off a save file (register 39).
#
# WHY NOTHING REPLACES THE WAIT. Under the new lifecycle peers are not announced
# -- they are RECONCILED. crs_pulse compares who the relay says is present in
# this area against the bodies actually standing there, every pulse, and fixes
# the difference in both directions. A peer who arrives late, drops out, walks
# through a door or reloads is the same case as a peer who was never there, so
# there is nothing to wait for and nothing to be told. That repair loop is the
# part the plan calls most important and the part that did not exist before.
#
# EARLY EXIT KEPT, AND FIXED WHILE IT MOVED. The old guard here restored files
# and threw, which skipped Close-CrossroadsSession -- leaving the row open until
# the service's twelve-hour abandoned sweep, with every playtime figure derived
# from it wrong in the same direction, and an open session is also a standing
# upload permit. The block this replaces got that right and said why; this now
# does the same thing.
if (-not (Get-Process 'swkotor2' -ErrorAction SilentlyContinue)) {
    Exit-CrossroadsSaveSession
    Close-CrossroadsSession 'closed'
    Restore-OwnedFiles
    Write-Host 'KotOR closed before mirroring began. Crossroads restored its temporary files.'
    try { Stop-Transcript | Out-Null } catch {}
    exit 0
}

$gameProcess = Get-Process 'swkotor2' -ErrorAction SilentlyContinue |
    Sort-Object StartTime -Descending |
    Select-Object -First 1
$movementArguments = @(
    'network-peer',
    $gameProcess.Id.ToString(),
    $hostName,
    $port.ToString(),
    '86400',
    # NO SESSION ARGUMENT. It sat between the duration and the client id until
    # 2026-08-15 and went with the join-code mechanism. The mirror rejects the
    # old eight-argument form outright, so a mismatched pair of components
    # cannot start and silently sync nothing.
    $clientId.ToString(),
    'execute-crossroads-peer-mirror'
)
$movementExecutable =
    Join-Path $component 'CrossroadsKotor2Mirror.exe'
$movementAttempt = 0
$movementProcess = $null

# WHY: CrossroadsLiveMirror is the only component that can report whether actor
# discovery actually succeeded, and it reports it on stdout/stderr. Start-Transcript
# hooks the PowerShell host's own output stream, NOT the console handle a native
# child process writes to, so under -NoNewWindow that text reached the screen and
# was never recorded anywhere. 51 mirror restarts across 21 sessions were logged
# with no reason captured. Give each attempt its own pair of capture files and
# echo them back into the transcript so the reason survives the session.
$mirrorLogDirectory = Join-Path $state 'mirror-logs'
New-Item -ItemType Directory -Force -Path $mirrorLogDirectory | Out-Null
$mirrorRunStamp = [DateTime]::Now.ToString('yyyyMMdd-HHmmss')
$mirrorLaunchCount = 0

function Write-MirrorCapture {
    param([string]$Label, [string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Write-Host "    [$Label] (no file)"
        return
    }
    $captured = @(Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)
    if ($captured.Count -eq 0) {
        Write-Host "    [$Label] (empty)"
        return
    }
    # A long successful run emits one line per movement-state change. The
    # discovery block sits at the top and the failure reason at the bottom, so
    # keep both ends rather than truncating one of them away.
    if ($captured.Count -le 200) {
        $shown = $captured
    }
    else {
        $shown = $captured[0..119] +
            "... $($captured.Count - 180) line(s) omitted ..." +
            $captured[-60..-1]
    }
    Write-Host "    [$Label] $($captured.Count) line(s):"
    foreach ($line in $shown) {
        Write-Host "      $line"
    }
}

# ---- A GAME CRASH, HANDED TO THE NEXT SESSION'S MIRROR TO SAY (2026-10-26) ----
#
# Measured 2026-10-26 17:53: the guest's KotOR crashed loading into the Taris
# hideout, and the only record of where is Windows' own -- the Application log
# and a dump in %LOCALAPPDATA%\CrashDumps on THAT machine, which nobody reads
# from. Once the game is gone there is no mirror left to say anything, so the
# join, which outlives the game, looks for Windows' crash event for swkotor.exe
# raised during this session and writes the fault (module, offset, code) where
# the extender's files live. The NEXT session's mirror reports it over the wire
# (subject 11, game_crashed), and the host's log prints it -- enough to look the
# address up. The join still opens no socket (Stage 1 rule).
function Write-CrossroadsGameCrash {
    param([datetime]$Since, [int]$Attempts = 8)
    try {
        # WER writes the event a few seconds after the process dies.
        # REPORTED ONCE EACH: the newest crash event this machine has not already
        # handed over, by its event-log record id, so a session start looking
        # back a day and a session end looking at itself never say one twice.
        $kseDirectory = Join-Path $env:LOCALAPPDATA 'KSE2'
        if (-not (Test-Path -LiteralPath $kseDirectory -PathType Container)) { return $false }
        $reportedPath = Join-Path $kseDirectory 'game_crash_reported.txt'
        $lastReported = [long]0
        if (Test-Path -LiteralPath $reportedPath) {
            [void][long]::TryParse(((Get-Content -LiteralPath $reportedPath -TotalCount 1) -as [string]), [ref]$lastReported)
        }
        $event = $null
        for ($try = 0; $try -lt $Attempts -and $null -eq $event; ++$try) {
            $event = Get-WinEvent -FilterHashtable @{
                LogName = 'Application'; Id = 1000; StartTime = $Since
            } -ErrorAction SilentlyContinue |
                Where-Object { $_.Message -match 'Faulting application name:\s*swkotor2\.exe' -and
                               $_.RecordId -gt $lastReported } |
                Select-Object -First 1
            if ($null -eq $event -and $try + 1 -lt $Attempts) { Start-Sleep -Milliseconds 750 }
        }
        if ($null -eq $event) { return $false }
        $module = if ($event.Message -match 'Faulting module name:\s*([^,\r\n]+)') { $Matches[1].Trim() } else { 'unknown' }
        $offset = if ($event.Message -match 'Fault offset:\s*0x([0-9A-Fa-f]+)') { $Matches[1] } else { '0' }
        $code = if ($event.Message -match 'Exception code:\s*0x([0-9A-Fa-f]+)') { $Matches[1] } else { '0' }
        # The module name is one word with no spaces in practice (swkotor.exe,
        # binkw32.dll); any space is folded so the line stays four fields.
        $line = '{0} {1} {2} {3}' -f ($module -replace '\s', '_'), $offset, $code,
            [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $temporary = Join-Path $kseDirectory 'game_crash.tmp'
        Set-Content -LiteralPath $temporary -Value $line -Encoding ASCII
        Move-Item -LiteralPath $temporary -Destination (Join-Path $kseDirectory 'game_crash.txt') -Force
        Set-Content -LiteralPath $reportedPath -Value $event.RecordId -Encoding ASCII
        Write-Host ("KotOR crashed ({0} at offset 0x{1}, code 0x{2}); the next session will report it to the party." -f $module, $offset, $code) -ForegroundColor Yellow
        return $true
    }
    catch {
        return $false
    }
}

# ---- A MIRROR'S EXIT, HANDED TO THE NEXT MIRROR TO SAY (2026-10-26) ---------
#
# The one report a dead process cannot send itself. Measured twice entering the
# Taris hideout: the guest's mirror stopped and the host saw only silence, which
# reads the same as a crash, a stuck load or a pulled cable. This join restarts
# the mirror, so it knows the exit code and how long the mirror ran.
#
# IT DOES NOT SEND IT ITSELF. "The join opens no socket of its own; only the
# mirror may speak to the relay" is a settled Stage 1 rule with its own gate case
# (Test-KotorStage1Lifecycle), and a first version of this that sent a UDP
# diagnostic from here broke it. So the exit is written where the extender's
# files already live, and the NEXT mirror -- started a second later -- reads it,
# reports it on the diagnostic channel (subject 10, mirror_exited) as soon as its
# network is up, and deletes it. Best effort: a report about a failure must not
# become a second failure.
function Write-CrossroadsMirrorExit {
    param([object]$ExitCode, [double]$Seconds, [int]$Launch)
    try {
        $kseDirectory = Join-Path $env:LOCALAPPDATA 'KSE2'
        if (-not (Test-Path -LiteralPath $kseDirectory -PathType Container)) { return }
        $code = if ($null -eq $ExitCode) { 'unavailable' } else { ([int]$ExitCode).ToString() }
        $line = '{0} {1} {2} {3}' -f $code,
            [int][Math]::Round($Seconds * 1000), $Launch,
            [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $temporary = Join-Path $kseDirectory 'mirror_exit.tmp'
        $final = Join-Path $kseDirectory 'mirror_exit.txt'
        Set-Content -LiteralPath $temporary -Value $line -Encoding ASCII
        Move-Item -LiteralPath $temporary -Destination $final -Force
    }
    catch {
        if (-not $script:mirrorExitWriteFailedSaid) {
            $script:mirrorExitWriteFailedSaid = $true
            Write-Host "Could not record the mirror's exit for the next mirror to report: $($_.Exception.Message)" -ForegroundColor DarkYellow
        }
    }
}

Write-Host 'Starting Crossroads actor mirroring...'
# A CRASH FROM BEFORE THIS SESSION THAT NOTHING REPORTED (a build without this,
# or a join that was itself killed) is handed over now, looking back one day, so
# the first mirror of this session says it. One look, no waiting.
[void](Write-CrossroadsGameCrash -Since (Get-Date).AddDays(-1) -Attempts 1)
$crashWatchSince = (Get-Date).AddSeconds(-5)

# Actor discovery and placement are allowed to recover independently from the
# player's server session. A transient area load, stale actor, or rejected
# placement must never terminate the wrapper and remove the player from the
# server roster. Restarting within the server's five-second registration window
# preserves the same client identity and session.
while (Get-Process -Id $gameProcess.Id -ErrorAction SilentlyContinue) {
    ++$mirrorLaunchCount
    $mirrorOutPath = Join-Path $mirrorLogDirectory (
        "mirror-$mirrorRunStamp-{0:d3}-out.txt" -f $mirrorLaunchCount)
    $mirrorErrPath = Join-Path $mirrorLogDirectory (
        "mirror-$mirrorRunStamp-{0:d3}-err.txt" -f $mirrorLaunchCount)
    $mirrorStarted = [DateTime]::UtcNow
    $movementProcess = try {
        Start-Process `
            -FilePath $movementExecutable `
            -ArgumentList $movementArguments -NoNewWindow -PassThru `
            -RedirectStandardOutput $mirrorOutPath `
            -RedirectStandardError $mirrorErrPath
    }
    catch {
        $null
    }

    # WHY: Start-Process -PassThru hands back a Process object that has not
    # cached the OS process handle, so .ExitCode reads back as $null forever --
    # measured on this project's own binaries, not assumed. Touching .Handle once
    # makes the runtime cache it and the real exit code becomes readable. Without
    # this the mirror's exit codes (5 = discovery, 9 = ghost changed underneath,
    # 12/13 = write failure) are permanently unavailable to the wrapper.
    if ($movementProcess) {
        try { $null = $movementProcess.Handle } catch {}
    }

    if (-not $movementProcess) {
        ++$movementAttempt
        Write-Host (
            'Crossroads could not start actor mirroring. ' +
            'The server connection is staying active; retrying in one second.'
        ) -ForegroundColor Yellow
        Start-Sleep -Seconds 1
        continue
    }

    while ((Get-Process -Id $gameProcess.Id -ErrorAction SilentlyContinue) -and
        -not $movementProcess.HasExited) {
        Start-Sleep -Milliseconds 250
        $movementProcess.Refresh()
        # The save watcher rides this loop rather than owning a thread or a
        # process of its own. It rate-limits itself to one pass every ten
        # seconds and does nothing at all unless this is a public session, so on
        # every other join it costs one comparison per quarter second.
        Update-CrossroadsSaves

        # THE HOST'S HALF OF THE SAVE HANDOFF (D85), on the same loop and for
        # the same reasons.
        #
        # GATED ON BEING TOLD, not on two inferences. This read
        # `classification -eq 'coop' -and $relayIsLocal` until 2026-10-21, which
        # was a guess at something the launcher knows: it starts the relay and
        # then launches the game, so it passes -CoopHost. The old test also
        # could not survive the owner's lifetime rule -- a host connects to
        # loopback now, so the directory never classifies its session `coop` and
        # the poll would have stopped happening at all.
        #
        # AND IT NEEDS THE PUBLIC IDENTITY, not this connection's address. A
        # guest files its request against the address it used; a host looking
        # under "127.0.0.1:39131" would find nothing, forever, silently.
        #
        # AND AN EMPTY -CoopServerId NO LONGER SKIPS IT (2026-10-28). On a first
        # launch the server is not listed yet, the launcher has no name for it,
        # and the poll used to never run -- so the first guest of every new
        # server waited for a save nobody was asked for. The service now answers
        # a host for its own account's listing on this port (own_coop_endpoint),
        # so this sends the loopback endpoint when there is nothing better.
        if ($CoopHost) {
            $hostIdentity = if ([string]::IsNullOrWhiteSpace($CoopServerId)) {
                "127.0.0.1:$ServerPort"
            }
            else { $CoopServerId }
            Update-CrossroadsHandoffHost `
                -ServerId $hostIdentity -GameDirectory $game
        }
    }

    if (-not (Get-Process -Id $gameProcess.Id -ErrorAction SilentlyContinue)) {
        break
    }

    $movementProcess.WaitForExit()
    $movementProcess.Refresh()
    # WHY: [int]$null evaluates to 0 in PowerShell and does NOT throw, so the
    # previous `try { [int]$_.ExitCode } catch { $null }` silently converted an
    # UNAVAILABLE exit code into a reported 0, which reads as success. The live
    # mirror's only genuine 0 requires completing its full 86400-second run, so
    # every "exit code 0" in earlier logs actually meant "code unknown" and hid a
    # restart loop. Read the raw value and null-check it BEFORE casting.
    $movementExit = $null
    try {
        $rawMovementExit = $movementProcess.ExitCode
        if ($null -ne $rawMovementExit) {
            $movementExit = [int]$rawMovementExit
        }
    }
    catch {
        $movementExit = $null
    }
    $reportedMovementExit = if ($null -eq $movementExit) {
        'unavailable'
    }
    else {
        $movementExit.ToString()
    }
    $mirrorSeconds = [Math]::Round(
        ([DateTime]::UtcNow - $mirrorStarted).TotalSeconds, 1)
    ++$movementAttempt
    Write-CrossroadsMirrorExit -ExitCode $movementExit `
        -Seconds $mirrorSeconds -Launch $mirrorLaunchCount

    # SOME FAILURES CAN NEVER SUCCEED ON A RETRY, AND RETRYING THEM HID ONE FOR
    # A DAY. Exit 1 is "usage printed" and exit 2 is "one or more execution
    # arguments are invalid" -- both are decided entirely by the argument list,
    # which is built once before this loop and never changes. Retrying is
    # therefore guaranteed to fail in exactly the same way, forever.
    #
    # MEASURED 2026-08-14: a join ran this loop 155 times in a row, every
    # attempt dying instantly on exit 2, writing 155 pairs of log files and
    # printing 155 reassuring "retrying automatically" lines. The player is told
    # sync is starting, the wrapper says it is recovering, and nothing will ever
    # happen. That is worse than stopping, because it looks like progress.
    #
    # It does NOT end the session or close the game. The player stays connected
    # and keeps playing -- exactly what happens with sync off -- and the reason
    # is stated once, where somebody will read it.
    # EXIT 3 JOINED THIS LIST ON 2026-08-15, and it belonged here from the day
    # the list was written.
    #
    # 3 is "could not open KotOR" -- Windows refused the mirror permission to
    # read the game process. On a tester's machine that was ERROR_ACCESS_DENIED
    # because the game was running elevated and the launcher was not, and this
    # loop respawned the mirror ONCE A SECOND for as long as the game was open:
    # the same Windows error number every time, a fresh pair of empty log files
    # every time, and nothing anywhere saying what to do about it. The player
    # noticed the file spam before they noticed the message.
    #
    # It is the same shape as 1 and 2 and fails the same test: a permission
    # refusal at one second is a permission refusal at the next. Nothing about
    # waiting changes elevation or an antivirus rule. The mirror now prints what
    # the two causes are and how to fix each; this stops the loop so somebody can
    # read it.
    # 42 AND 43 JOINED IT ON 2026-10-28: the server's password ruling. 42 is
    # "the server refused the password", 43 is "the server wants one and this
    # join has none". A retry asks the same server the same question with the
    # same key and gets the same answer, so it stops and says what to do. The
    # launcher checks the password BEFORE KotOR starts, so reaching either here
    # means something changed in between -- the host set a new password, or the
    # server's row did not say it had one.
    if ($movementExit -eq 1 -or $movementExit -eq 2 -or $movementExit -eq 3 -or
        $movementExit -eq 42 -or $movementExit -eq 43) {
        $why = if ($movementExit -eq 3) {
            'Windows refused Crossroads permission to read KotOR. That is a ' +
            'permission problem on this machine -- see the reason below -- and ' +
            'it cannot clear by itself.'
        }
        elseif ($movementExit -eq 42) {
            'the server refused the password -- it is not this server''s ' +
            'password. Close KotOR, press Join in the launcher, and enter it again.'
        }
        elseif ($movementExit -eq 43) {
            'this server is protected by a password and none was given. Close ' +
            'KotOR, press Join in the launcher, and enter the password when asked.'
        }
        else {
            'this is a problem with how the mirror was invoked, not a transient ' +
            'fault.'
        }
        Write-Host (
            "[$([DateTime]::Now.ToString('HH:mm:ss'))] " +
            "Crossroads actor mirroring cannot start (exit code $reportedMovementExit) " +
            "after $mirrorSeconds second(s), and retrying cannot help: $why"
        ) -ForegroundColor Red
        Write-MirrorCapture 'mirror stdout' $mirrorOutPath
        Write-MirrorCapture 'mirror stderr' $mirrorErrPath
        Write-Host (
            'You are still connected and can keep playing; other players will ' +
            'not appear. Attempts: ' + $movementAttempt + '.') -ForegroundColor Yellow
        break
    }

    Write-Host (
        "[$([DateTime]::Now.ToString('HH:mm:ss'))] " +
        "Crossroads actor mirroring paused (exit code $reportedMovementExit) " +
        "after $mirrorSeconds second(s). " +
        'You remain connected; retrying automatically in one second.'
    ) -ForegroundColor Yellow
    Write-MirrorCapture 'mirror stdout' $mirrorOutPath
    Write-MirrorCapture 'mirror stderr' $mirrorErrPath
    Start-Sleep -Seconds 1
}

if ($movementProcess -and -not $movementProcess.HasExited) {
    Stop-Process -Id $movementProcess.Id -Force
    $movementProcess.WaitForExit()
}
# THE GAME IS GONE: if Windows recorded it crashing, hand that to the next
# session to report (see Write-CrossroadsGameCrash). A clean quit finds nothing.
[void](Write-CrossroadsGameCrash -Since $crashWatchSince)
# BEFORE the session closes: the final upload sweep needs an open session,
# because "made while connected" is enforced by the service as "there is a
# session open for you right now". This also puts the player's own saves back.
Exit-CrossroadsSaveSession
Close-CrossroadsSession 'closed'
Restore-OwnedFiles
Write-Host 'KotOR closed. Crossroads disconnected and restored its temporary files.'
try { Stop-Transcript | Out-Null } catch {}
exit 0
