@echo off
setlocal
cd /d "%~dp0"
"%~dp0ProjectCrossroadsDiagnostics.exe"
if errorlevel 1 (
  echo.
  echo The diagnostic could not finish. Leave this window open and ask Codex to inspect it.
  pause
)
exit /b %errorlevel%
