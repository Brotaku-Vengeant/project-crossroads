[CmdletBinding()]
param(
    [string]$GameDirectory = '',

    # WHERE TO JOIN, supplied by the launcher.
    #
    # These exist because the server browser can now list servers this install
    # has never been configured for. Before Stage 5 the destination could only
    # come from crossroads-network.ini, so a browser that showed ten servers
    # could only ever join one of them.
    #
    # ALL THREE DEFAULT TO THE INI when absent, so an existing invocation -- a
    # tester double-clicking, an older launcher, the diagnostics path -- keeps
    # working unchanged.
    #
    # ServerSession is a join CREDENTIAL, not an identifier: RoomProof.hpp uses
    # it as an HMAC key. The launcher passes 0 for any server that came from the
    # directory, because sending this install's session to a stranger's server
    # would hand them the credential for the network's own one. Zero is also
    # what an open community server expects: the relay treats session 0 as "no
    # join code required".
    [string]$ServerHost = '',
    [int]$ServerPort = 0,
    [string]$ServerSession = ''
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$logPath = Join-Path $root 'kotor-client-log.txt'
try {
    Start-Transcript -LiteralPath $logPath -Append -Force | Out-Null
}
catch {
    # Joining can continue even if Windows cannot create the optional log.
}
trap {
    Write-Host ''
    Write-Host 'CROSSROADS KOTOR COULD NOT CONTINUE' -ForegroundColor Red
    Write-Host '===================================' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ''
    Write-Host "Diagnostic log: $logPath"
    $runningKotor = Get-Process 'swkotor' -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if ($runningKotor) {
        Write-Host ''
        Write-Host 'Close KotOR WITHOUT SAVING. Crossroads will clean up automatically.' `
            -ForegroundColor Yellow
        while (Get-Process 'swkotor' -ErrorAction SilentlyContinue) {
            Start-Sleep -Milliseconds 500
        }
    }
    # Closed on the failure path too, and with a reason that says so. Without
    # this, every crashed or refused join would leave a session open until the
    # service's abandoned sweep closed it twelve hours later -- which would make
    # every future playtime figure wrong in the same direction.
    # THE PLAYER'S OWN SAVES COME BACK FIRST ON THIS PATH, AND NOTHING IS
    # UPLOADED. They are parked under another name for the length of a public
    # session; putting them back is a rename and takes no time, while a final
    # upload sweep is megabytes over a tunnel. A player who has just been shown a
    # red error is the one most likely to close the window rather than wait, and
    # the cost of the two choices is not symmetric: losing the last save of a
    # join that already failed is a small loss, and leaving somebody's saves
    # parked under a name they do not know is a large one.
    if (Get-Command Exit-CrossroadsSaveSession -ErrorAction SilentlyContinue) {
        Exit-CrossroadsSaveSession -RestoreOnly
    }
    if (Get-Command Close-CrossroadsSession -ErrorAction SilentlyContinue) {
        Close-CrossroadsSession 'crashed'
    }
    if (Get-Command Restore-OwnedFiles -ErrorAction SilentlyContinue) {
        Restore-OwnedFiles
        Write-Host 'KotOR files restored. This window will close automatically.'
    }
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}

$component = Join-Path $root 'components\kotor1'
$configPath = Join-Path $root 'crossroads-network.ini'
$state = Join-Path $root 'state\kotor1'
$localState = Join-Path $state 'local'
$remoteState = Join-Path $state 'remote'
$backup = Join-Path $state 'backup'
$installRecord = Join-Path $state 'install-state.json'

function Read-IniValue {
    param([string]$Section, [string]$Key)
    $current = ''
    foreach ($line in Get-Content -LiteralPath $configPath) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') {
            $current = $Matches[1]
            continue
        }
        if ($current -eq $Section -and
            $trimmed -match ('^' + [regex]::Escape($Key) + '=(.*)$')) {
            return $Matches[1].Trim()
        }
    }
    throw "Missing [$Section] $Key in crossroads-network.ini."
}

function Read-OptionalIniValue {
    param([string]$Section, [string]$Key)
    try {
        return Read-IniValue $Section $Key
    }
    catch {
        return ''
    }
}

# ---- the session record -----------------------------------------------------
#
# Tells the Crossroads service that this account started playing, and tells it
# again when they stop. Everything an account will ever show -- games played,
# and later playtime -- is derived from these two calls. See
# docs\PLAN_2026-08-13-user-records.md.
#
# NOTHING HERE MAY STOP SOMEBODY PLAYING. Every call is best-effort with a short
# timeout, every failure is logged and swallowed, and none of it is on the path
# that launches the game. A record-keeping feature that can prevent a join would
# be a terrible trade, and it is the kind of thing that only shows up when the
# service is down and everybody is trying to play at once.
#
# IT DOES NOTHING AT ALL when accounts are not configured, which is every install
# in the field. Same switch as the join gate and the launcher's sign-in control.
$script:crossroadsSessionId = ''
# What KIND of server this session is on, as the SERVICE decided it -- never as
# this script guessed. Empty until a session opens, and empty forever on an
# install with no account configured, which is every install in the field. The
# save rule reads this and nothing else.
$script:crossroadsSessionClassification = ''

function Get-CrossroadsAccountToken {
    # Written by Sign-InToCrossroads.ps1, in the per-user profile directory --
    # never beside the executable, which in a managed install is shared.
    $accountPath = Join-Path $env:LOCALAPPDATA 'Project Crossroads\account.ini'
    if (-not (Test-Path -LiteralPath $accountPath -PathType Leaf)) { return '' }
    foreach ($line in (Get-Content -LiteralPath $accountPath)) {
        if ($line.Trim() -match '^token=(.*)$') { return $Matches[1].Trim() }
    }
    return ''
}

function Invoke-CrossroadsRecords {
    param([string]$Path, [hashtable]$Body)
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $null }
    try {
        [Net.ServicePointManager]::SecurityProtocol =
            [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11
    }
    catch { }
    try {
        return Invoke-RestMethod -Uri ($serviceUrl.TrimEnd('/') + $Path) `
            -Method Post -ContentType 'application/json' -TimeoutSec 8 `
            -UseBasicParsing -Body ($Body | ConvertTo-Json -Compress)
    }
    catch {
        # The message, never the body we sent -- that carries the account token.
        Write-Host ("Crossroads could not reach the account service ($Path). " +
                    'Play continues; this session will not be recorded.') `
            -ForegroundColor DarkGray
        return $null
    }
}

function Open-CrossroadsSession {
    param([string]$GameId, [string]$ServerHost, [uint16]$ServerPort)
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return }
    # WHERE they played is recorded; WHAT KIND of server it was is not claimed
    # here. The service decides classification for itself and records
    # `unverified` when it does not recognise the address -- a client that could
    # name its own classification could call itself an official server, and
    # playtime is meant to count official servers only.
    $response = Invoke-CrossroadsRecords '/session/open' @{
        accountToken = $token
        game = $GameId
        serverId = ("{0}:{1}" -f $ServerHost, $ServerPort)
    }
    if ($response -and $response.sessionId) {
        $script:crossroadsSessionId = [string]$response.sessionId
        $script:crossroadsSessionClassification =
            [string]$response.classification
    }
}

function Close-CrossroadsSession {
    param([string]$Reason = 'closed')
    if ([string]::IsNullOrWhiteSpace($script:crossroadsSessionId)) { return }
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return }
    $sessionId = $script:crossroadsSessionId
    # CLEARED FIRST, so this is safe to call twice. It is called from the normal
    # exit AND from the failure path, and those can both run -- a second close
    # would be answered 404 by the service and print a confusing line about the
    # service being unreachable when it is fine.
    $script:crossroadsSessionId = ''
    Invoke-CrossroadsRecords '/session/close' @{
        accountToken = $token
        sessionId = $sessionId
        reason = $Reason
    } | Out-Null
}

# ---- saves on a public server ------------------------------------------------
#
# THE OWNER'S RULE: on official and community-public servers a player may use
# only saves made while connected, and only the five most recent. A sixth deletes
# the oldest. A first public join needs a fresh character. Private and co-op are
# unrestricted. See docs\PLAN_2026-08-13-user-records.md section 6.
#
# HOW THAT IS MADE TRUE ON DISK, because recording saves is not the same as
# enforcing the rule: for the length of a public session the player's own saves
# folder is PARKED under another name and an empty one is put in its place,
# holding only the saves the service has recorded. So:
#
#   - "only saves made while connected are usable" is not a check that can be
#     bypassed; the other saves are not there to load.
#   - "a first public join needs a fresh character" needs no mechanism at all.
#     Nothing is downloaded because nothing is recorded, so the folder is empty
#     and the only thing the player can do is start a new game.
#
# PARKED BY RENAME, NEVER COPIED AND NEVER DELETED. A rename is atomic, it is
# reversible, and it never has two copies of a save that could diverge. The
# player's own saves are the most valuable thing on their disk and nothing here
# writes into them, reads them destructively, or removes them.
#
# AND IT IS RESTORED EVEN IF THIS SCRIPT IS KILLED. The swap is written to a
# record file before it happens, and the next join restores from that record
# before doing anything else -- the same shape as the Override file restore, and
# for the same reason: the abnormal exit is the case that matters.
try {
    # Loaded once, here, rather than at each use. Present in every PowerShell
    # version this project targets, but not loaded by default in 5.1.
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
}
catch {
    # Without it the save rule cannot pack or unpack anything. Not fatal on its
    # own -- the join continues and Enter-CrossroadsSaveSession will fail to
    # unpack, which is reported there rather than stopping a player joining.
    Write-Host 'Crossroads could not load the compression library for saves.' `
        -ForegroundColor DarkGray
}

$script:crossroadsSavesActive = $false
$script:crossroadsSavesFolder = ''
$script:crossroadsSaveFingerprints = @{}
$script:crossroadsSaveUploaded = @{}
$script:crossroadsSaveNextTick = [DateTime]::MinValue
$saveSwapRecord = Join-Path $state 'save-swap.json'
$saveWorkRoot = Join-Path $state 'save-work'

# A slot name arrives from the SERVICE, which stores whatever a client sent as
# display text -- so it is attacker-controlled by the time it comes back, and it
# is about to become a folder name on this machine. Anything that is not a plain
# save-folder name is refused rather than repaired.
$script:crossroadsSlotPattern = '^[A-Za-z0-9][A-Za-z0-9 ._\-]{0,63}$'

# ---- player sync, DISABLED ---------------------------------------------------
#
# TURNED OFF BY THE OWNER 2026-08-13, and DISABLED rather than removed. Their
# words: "The last time we built this we did so on a fault foundation so I want to
# start from square one" and "I just want it disabled, not removed."
#
# WHAT IS OFF. Every stage that replicates a player, in the order the join used to
# run them:
#
#   1. Install-KSE            -- the binkw32 swap that lets the engine run scripts
#   2. the Override payloads  -- k_def_heartbt01.ncs, crs_pulse.ncs,
#                                crossroadsghost.utc, and the retail cr_orig_hb
#                                extraction they chain to
#   3. CrossroadsBuildIdentity-- reads a SAVE FILE to decide who you are, which is
#                                register 39 and the fault the reset was called
#                                over
#   4. CrossroadsIdentityExchange -- registers with the relay and blocks until a
#                                peer arrives
#   5. CrossroadsApplyIdentity-- builds the peer's actor into Override
#   6. CrossroadsLiveMirror   -- the pose mirror and its restart loop
#
# The HUD goes with them: it exists to display a relay roster, and with nothing
# registering there is no roster to show.
#
# WHAT REMAINS. Sign-in, the session record, the public save rule, the
# compatibility profile, and launching the game. A join is now: you are recorded
# as having played, your saves follow the server's rule, and KotOR runs with
# UNMODIFIED game files.
#
# WHY A SWITCH RATHER THAN DELETION, beyond the owner asking for it. The call
# sites are gated; the FUNCTIONS are untouched. `Test-GhostHarnessRestore.ps1`
# (13 cases) and `Test-KotorExtenderOwnership.ps1` (11 cases) lift those functions
# out of this file by parsing it, and they are the only proof that a Crossroads
# join leaves somebody's KotOR install exactly as it found it. Deleting the code
# would delete that proof -- and it is proof the rebuild will want back the first
# time it writes to Override again.
#
# DEFAULT OFF, which is the opposite of save_sync below. Setting
# `[kotor1] player_sync=on` in crossroads-launcher.ini restores the old behaviour
# in full; nothing about it has been changed, only skipped.
function Test-CrossroadsPlayerSyncEnabled {
    $launcherConfigPath = Join-Path $root 'crossroads-launcher.ini'
    $configured = ''
    if (Test-Path -LiteralPath $launcherConfigPath -PathType Leaf) {
        $current = ''
        foreach ($line in Get-Content -LiteralPath $launcherConfigPath) {
            $trimmed = $line.Trim()
            if ($trimmed -match '^\[(.+)\]$') { $current = $Matches[1]; continue }
            if ($current -eq 'kotor1' -and $trimmed -match '^player_sync=(.*)$') {
                $configured = $Matches[1].Trim()
                break
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($configured)) {
        $configured = Read-OptionalIniValue 'kotor1' 'player_sync'
    }
    # OFF unless something says otherwise, which is the whole point.
    return ($configured -match '^(?i)(on|true|1|yes)$')
}

# ---- presence: being ON the server without syncing anything ------------------
#
# WHAT THIS IS. A join now puts the player on the relay's roster and keeps them
# there, and does nothing else. No pose, no identity, no peer actor. The relay
# already separates these: `register_peer` is presence and `snapshot` is
# movement, so "connected but not synced" is something the existing protocol can
# already say -- no relay change, no rebuild.
#
# WHY IT IS SENT FROM HERE rather than by one of the components. The two
# components that used to register also mirror, and mirroring is off. Sending one
# fixed 64-byte packet needs no new binary in the tester package, and it is
# SEND-ONLY: nothing here reads a reply, so no attacker-controlled bytes are
# parsed by the launcher. That is the rule this project has about wire data, and
# it is why this is acceptable in PowerShell at all.
#
# THE MODULE FIELD IS ZERO, deliberately. The protocol defines 0 as "not known",
# and a receiver must treat it as "cannot be matched" rather than "matches
# anything". Reading the real module means reading the game's memory, which is
# the sync layer. Measured against the real relay: a peer registering with module
# 0 is admitted -- `ROSTER: client 1004 admitted in module 0 (1 held)`.
$script:crossroadsPresenceSocket = $null
$script:crossroadsPresenceSession = [uint64]0
$script:crossroadsPresenceClient = [uint32]0
$script:crossroadsPresenceHost = ''
$script:crossroadsPresencePort = 0
$script:crossroadsPresenceNext = [DateTime]::MinValue
$script:crossroadsPresenceSequence = 0

# The relay culls a peer it has not heard from for five seconds, so this must be
# comfortably under that. Two seconds gives two chances to miss a packet before
# anybody drops off a roster.
$script:crossroadsPresenceIntervalSeconds = 2

function New-CrossroadsPresencePacket {
    param([uint64]$Session, [uint32]$Client, [uint32]$Sequence)
    # The 64-byte register_peer packet, big-endian, exactly as
    # games\kotor1\shared\include\crossroads\network_protocol.h encodes it.
    # THIS IS A SECOND COPY OF THAT LAYOUT and the only defence against it
    # drifting is that Test-KotorPresence.ps1 sends it to the REAL relay binary
    # and requires an admission line back -- so a change to the format shows up
    # as a gate failure rather than as a player who silently never connects.
    $wire = New-Object byte[] 64
    $put32 = {
        param([byte[]]$b, [int]$o, [uint32]$v)
        $b[$o]     = [byte](($v -shr 24) -band 0xFF)
        $b[$o + 1] = [byte](($v -shr 16) -band 0xFF)
        $b[$o + 2] = [byte](($v -shr 8) -band 0xFF)
        $b[$o + 3] = [byte]($v -band 0xFF)
    }
    & $put32 $wire 0 ([uint32]0x4352534E)   # magic, "CRSN"
    $wire[4] = 0
    $wire[5] = 2                             # snapshot version 2
    $wire[6] = 1                             # MessageType::register_peer
    $wire[7] = 0                             # MovementState::idle
    for ($i = 0; $i -lt 8; $i++) {
        $wire[8 + $i] = [byte](($Session -shr (8 * (7 - $i))) -band 0xFF)
    }
    & $put32 $wire 16 $Client
    & $put32 $wire 20 $Sequence
    $now = [uint64]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
    for ($i = 0; $i -lt 8; $i++) {
        $wire[24 + $i] = [byte](($now -shr (8 * (7 - $i))) -band 0xFF)
    }
    # Position stays 0,0,0. Facing MUST be a unit vector: the validator requires
    # its squared length between 0.8 and 1.2, so (1,0,0).
    & $put32 $wire 44 ([BitConverter]::ToUInt32([BitConverter]::GetBytes([float]1.0), 0))
    # module 0 = not known. epoch 1 = this run of this sender.
    & $put32 $wire 56 ([uint32]0)
    & $put32 $wire 60 ([uint32]1)
    return $wire
}

function Start-CrossroadsPresence {
    param([string]$HostName, [uint16]$Port, [string]$SessionHex, [uint32]$Client)
    $session = 0
    try { $session = [Convert]::ToUInt64($SessionHex, 16) } catch { $session = 0 }
    if ($session -eq 0) {
        # NO JOIN CODE. The launcher carries zero for every server it did not
        # configure itself -- deliberately, so this install's code is never sent
        # to a stranger's server -- and the validator refuses a zero session, so
        # something non-zero has to go on the wire. 1 is the smallest legal
        # value and means exactly "I have no code".
        #
        # An OPEN relay (started with session 0) accepts any non-zero value, so
        # this works wherever a public server should work. A relay PINNED to a
        # code still refuses it, which is correct: that server wants a code and
        # this player does not have it.
        $session = 1
    }
    if ($Client -eq 0) { return }
    try {
        $script:crossroadsPresenceSocket = New-Object Net.Sockets.UdpClient
        $script:crossroadsPresenceSession = $session
        $script:crossroadsPresenceClient = $Client
        $script:crossroadsPresenceHost = $HostName
        $script:crossroadsPresencePort = $Port
        $script:crossroadsPresenceSequence = 0
        $script:crossroadsPresenceNext = [DateTime]::MinValue
    }
    catch {
        # Presence is not worth failing a join over.
        Write-Host 'Crossroads could not open its connection to the server.' `
            -ForegroundColor DarkGray
        $script:crossroadsPresenceSocket = $null
    }
}

function Update-CrossroadsPresence {
    if ($null -eq $script:crossroadsPresenceSocket) { return }
    if ([DateTime]::UtcNow -lt $script:crossroadsPresenceNext) { return }
    $script:crossroadsPresenceNext =
        [DateTime]::UtcNow.AddSeconds($script:crossroadsPresenceIntervalSeconds)
    $script:crossroadsPresenceSequence++
    try {
        # Rebuilt each time so the sequence and timestamp advance; the relay
        # holds a high-water mark per sender and a frozen sequence looks like a
        # replay.
        $packet = New-CrossroadsPresencePacket `
            -Session $script:crossroadsPresenceSession `
            -Client $script:crossroadsPresenceClient `
            -Sequence ([uint32]$script:crossroadsPresenceSequence)
        [void]$script:crossroadsPresenceSocket.Send(
            $packet, $packet.Length,
            $script:crossroadsPresenceHost, $script:crossroadsPresencePort)
    }
    catch {
        # A dropped packet is not an error worth printing every two seconds. The
        # relay culls after five seconds of silence and re-admits on the next one
        # that arrives, so a transient failure heals itself.
    }
}

function Stop-CrossroadsPresence {
    if ($null -eq $script:crossroadsPresenceSocket) { return }
    try { $script:crossroadsPresenceSocket.Close() } catch { }
    $script:crossroadsPresenceSocket = $null
    # Nothing is sent to say goodbye: the relay ages a peer out after five
    # seconds of silence, and a leave message would be one more thing to get
    # wrong for no gain.
}

function Test-CrossroadsSaveRuleEnabled {
    # ON by default, per the owner's decision 2026-08-13. The switch exists so it
    # can be turned OFF on one machine without a rebuild, and it is read from
    # crossroads-launcher.ini FIRST because crossroads-network.ini is
    # updater-managed and anything hand-edited there is overwritten by the next
    # update -- the same trap the HUD capacity setting documents further down.
    $launcherConfigPath = Join-Path $root 'crossroads-launcher.ini'
    $configured = ''
    if (Test-Path -LiteralPath $launcherConfigPath -PathType Leaf) {
        $current = ''
        foreach ($line in Get-Content -LiteralPath $launcherConfigPath) {
            $trimmed = $line.Trim()
            if ($trimmed -match '^\[(.+)\]$') { $current = $Matches[1]; continue }
            if ($current -eq 'kotor1' -and $trimmed -match '^save_sync=(.*)$') {
                $configured = $Matches[1].Trim()
                break
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($configured)) {
        $configured = Read-OptionalIniValue 'kotor1' 'save_sync'
    }
    return ($configured -notmatch '^(?i)(off|false|0|no)$')
}

function Test-CrossroadsPublicSession {
    return @('official', 'community-public') -contains
        $script:crossroadsSessionClassification
}

function Get-CrossroadsFolderFingerprint {
    param([string]$Path)
    # Name, length and last-write time of every file, in a fixed order. This is
    # what decides whether a save has stopped being written to; it is NOT a
    # content hash, because hashing six megabytes every ten seconds during play
    # is a cost with no matching benefit -- the upload hashes for real.
    $parts = Get-ChildItem -LiteralPath $Path -File -ErrorAction SilentlyContinue |
        Sort-Object Name |
        ForEach-Object { '{0}|{1}|{2}' -f $_.Name, $_.Length, $_.LastWriteTimeUtc.Ticks }
    return ($parts -join ';')
}

function Invoke-CrossroadsSaveUpload {
    param([string]$SlotName, [string]$ZipPath)
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $false }
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return $false }
    try {
        $bytes = [IO.File]::ReadAllBytes($ZipPath)
        $sha = (Get-FileHash -LiteralPath $ZipPath -Algorithm SHA256).Hash.ToLower()
        $request = [Net.HttpWebRequest]::Create(
            $serviceUrl.TrimEnd('/') + '/save/upload')
        $request.Method = 'POST'
        $request.ContentType = 'application/zip'
        # Generous compared with the session calls: this is megabytes over a
        # tunnel, not a few hundred bytes. Still bounded, because nothing here
        # may hold up a player who is trying to quit.
        $request.Timeout = 60000
        $request.ReadWriteTimeout = 60000
        # THE CREDENTIALS TRAVEL IN HEADERS because the body is the archive.
        # Never in the URL -- that is the part of a request that ends up in
        # access logs and proxy logs.
        $request.Headers.Add('X-Crossroads-Token', $token)
        $request.Headers.Add('X-Crossroads-Session', $script:crossroadsSessionId)
        $request.Headers.Add('X-Crossroads-Game', 'kotor1')
        $request.Headers.Add('X-Crossroads-Slot', $SlotName)
        $request.Headers.Add('X-Crossroads-Sha256', $sha)
        $request.ContentLength = $bytes.Length
        $stream = $request.GetRequestStream()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Close()
        $response = $request.GetResponse()
        $reader = New-Object IO.StreamReader($response.GetResponseStream())
        $answer = $reader.ReadToEnd()
        $reader.Close()
        $response.Close()
        # The service says which slots this upload pushed out of the five, and
        # they are removed from the game folder here. See
        # Remove-CrossroadsEvictedSave for why that is done at all.
        try {
            $parsed = $answer | ConvertFrom-Json
            if ($parsed -and $parsed.evictedSlots) {
                foreach ($gone in @($parsed.evictedSlots)) {
                    Remove-CrossroadsEvictedSave ([string]$gone) $SlotName
                }
            }
        }
        catch { }
        return $true
    }
    catch {
        # The message only, never the request -- that carries the account token.
        Write-Host ("Crossroads could not upload the save '$SlotName'. " +
                    'Play continues; it will be retried.') -ForegroundColor DarkGray
        return $false
    }
}

function Remove-CrossroadsEvictedSave {
    param([string]$SlotName, [string]$JustUploaded)
    # DELETING A PLAYER'S SAVE FILE WHILE THEIR GAME IS RUNNING. That is what
    # this does, so it is worth being plain about why and about every guard.
    #
    # WHY: eviction used to happen only on the service. The owner made six saves
    # in one session and KotOR listed all six, because nothing had removed
    # anything from the game folder -- so "only the five most recent are usable"
    # was true across joins and visibly false within one, and the sixth save was
    # still loadable. The owner chose to make the rule true at all times.
    #
    # THE GUARDS, and each one is load-bearing:
    #
    #  - it does nothing unless a public session is active, so it can never run
    #    against an ordinary single-player saves folder;
    #  - it deletes only inside the SESSION folder, never the parked one holding
    #    the player's own characters;
    #  - the slot name comes back from the service, which stores whatever a
    #    client sent as display text, so it is checked against the same pattern
    #    used when unpacking -- it must be a plain folder name or nothing
    #    happens;
    #  - it refuses to delete the save that was just uploaded. The service does
    #    not report a REWRITTEN slot as evicted, so this should be unreachable;
    #    it is here because the cost of that being wrong once is the player's
    #    newest save, and the check is one comparison.
    if (-not $script:crossroadsSavesActive) { return }
    if ([string]::IsNullOrWhiteSpace($SlotName)) { return }
    if ($SlotName -notmatch $script:crossroadsSlotPattern) { return }
    if ($SlotName -eq $JustUploaded) { return }

    $target = Join-Path $script:crossroadsSavesFolder $SlotName
    if (-not (Test-Path -LiteralPath $target -PathType Container)) { return }
    try {
        Remove-Item -LiteralPath $target -Recurse -Force
        $script:crossroadsSaveFingerprints.Remove($SlotName)
        $script:crossroadsSaveUploaded.Remove($SlotName)
        Write-Host ("Crossroads removed the oldest save '$SlotName' -- this " +
                    'server keeps your five most recent.') -ForegroundColor DarkGray
    }
    catch {
        # A failure here costs nothing: the save is already gone from the
        # service, so it will not come back on the next join either way.
        Write-Host ("Crossroads could not remove the evicted save '$SlotName'.") `
            -ForegroundColor DarkGray
    }
}

function Get-CrossroadsRecordedSaves {
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return @() }
    $listed = Invoke-CrossroadsRecords '/save/list' @{
        accountToken = $token
        game = 'kotor1'
    }
    if (-not $listed -or -not $listed.saves) { return @() }
    return @($listed.saves)
}

function Invoke-CrossroadsSaveFetch {
    param([string]$SaveId, [string]$Destination)
    $serviceUrl = Read-OptionalIniValue 'accounts' 'service_url'
    if ([string]::IsNullOrWhiteSpace($serviceUrl)) { return $false }
    $token = Get-CrossroadsAccountToken
    if ([string]::IsNullOrWhiteSpace($token)) { return $false }
    try {
        $request = [Net.HttpWebRequest]::Create(
            $serviceUrl.TrimEnd('/') + '/save/fetch')
        $request.Method = 'POST'
        $request.ContentType = 'application/json'
        $request.Timeout = 60000
        $request.ReadWriteTimeout = 60000
        $payload = [Text.Encoding]::UTF8.GetBytes(
            (@{ accountToken = $token; saveId = $SaveId } | ConvertTo-Json -Compress))
        $request.ContentLength = $payload.Length
        $stream = $request.GetRequestStream()
        $stream.Write($payload, 0, $payload.Length)
        $stream.Close()
        $response = $request.GetResponse()
        $target = [IO.File]::Open($Destination, [IO.FileMode]::Create)
        try { $response.GetResponseStream().CopyTo($target) }
        finally { $target.Close(); $response.Close() }
        return $true
    }
    catch {
        Write-Host 'Crossroads could not download one of your recorded saves.' `
            -ForegroundColor DarkGray
        return $false
    }
}

function Restore-CrossroadsSaves {
    # Put the player's own saves back. Safe to call at any time, including when
    # no swap ever happened, and safe to call twice.
    if (-not (Test-Path -LiteralPath $saveSwapRecord -PathType Leaf)) { return }
    $record = $null
    try {
        $record = Get-Content -LiteralPath $saveSwapRecord -Raw | ConvertFrom-Json
    }
    catch {
        # An unreadable record is not a reason to leave the player's saves
        # parked. Say so loudly -- this is the one failure in the whole feature
        # that a player would notice as "my saves are gone".
        Write-Host ('CROSSROADS COULD NOT READ ITS SAVE RECORD. If your KotOR ' +
                    'saves folder looks empty, the original is beside it under ' +
                    'a name starting "saves.crossroads".') -ForegroundColor Red
        return
    }
    if ($record -and $record.parked -and (Test-Path -LiteralPath $record.parked)) {
        # The SESSION folder goes first, then the rename back. If this is
        # interrupted between the two, the record is still on disk and the next
        # join runs this again.
        if ($record.live -and (Test-Path -LiteralPath $record.live)) {
            Remove-Item -LiteralPath $record.live -Recurse -Force `
                -ErrorAction SilentlyContinue
        }
        try {
            Move-Item -LiteralPath $record.parked -Destination $record.live -Force
            Write-Host 'Crossroads restored your own KotOR saves.'
        }
        catch {
            Write-Host ("CROSSROADS COULD NOT RESTORE YOUR SAVES AUTOMATICALLY. " +
                        "They are safe at: $($record.parked)") -ForegroundColor Red
            return
        }
    }
    Remove-Item -LiteralPath $saveSwapRecord -Force -ErrorAction SilentlyContinue
    $script:crossroadsSavesActive = $false
}

function Enter-CrossroadsSaveSession {
    param([string]$Game)
    if (-not (Test-CrossroadsPublicSession)) { return }
    if (-not (Test-CrossroadsSaveRuleEnabled)) {
        Write-Host ('The public save rule is switched off on this install; ' +
                    'your own saves are being used.') -ForegroundColor Yellow
        return
    }

    $live = Join-Path $Game 'saves'
    $parked = Join-Path $Game 'saves.crossroads-offline'
    if (Test-Path -LiteralPath $parked) {
        # A previous run parked saves and its record was lost. Refuse rather
        # than overwrite: whatever is in there is somebody's character.
        throw ("Crossroads found a parked saves folder from an earlier session " +
               "at $parked. Move or rename it before joining a public server.")
    }

    New-Item -ItemType Directory -Force -Path $saveWorkRoot | Out-Null
    # WRITTEN BEFORE THE RENAME, not after. If this script dies between the two
    # the record describes a swap that did not happen, and the restore finds no
    # parked folder and simply clears the record. The other order would leave a
    # parked folder nothing knows about.
    $record = @{ live = $live; parked = $parked
                 stamped = (Get-Date).ToString('o') } | ConvertTo-Json
    [IO.File]::WriteAllText($saveSwapRecord, $record,
        (New-Object Text.UTF8Encoding($false)))

    if (Test-Path -LiteralPath $live) {
        Move-Item -LiteralPath $live -Destination $parked -Force
    }
    New-Item -ItemType Directory -Force -Path $live | Out-Null
    $script:crossroadsSavesActive = $true
    $script:crossroadsSavesFolder = $live

    Write-Host ''
    Write-Host 'PUBLIC SERVER SAVE RULE' -ForegroundColor Cyan
    Write-Host ('On this server you can use only saves made while connected. ' +
                'Your own saves are parked and come back when you leave.')

    $recorded = Get-CrossroadsRecordedSaves
    $restoredCount = 0
    foreach ($save in $recorded) {
        $slot = [string]$save.slot
        if ($slot -notmatch $script:crossroadsSlotPattern) {
            # The service stores a slot name as text and does not constrain it to
            # something that is safe as a folder name here. Refused rather than
            # sanitised -- a repaired name is a guess, and this one becomes a
            # path on the player's disk.
            Write-Host ('Skipped a recorded save whose name cannot be used as a ' +
                        'folder.') -ForegroundColor DarkGray
            continue
        }
        $archive = Join-Path $saveWorkRoot ('fetch-' + [Guid]::NewGuid().ToString('N') + '.zip')
        if (-not (Invoke-CrossroadsSaveFetch $save.saveId $archive)) { continue }
        try {
            $target = Join-Path $live $slot
            [IO.Compression.ZipFile]::ExtractToDirectory($archive, $target)
            $restoredCount++
            # Remembered as already-sent, so the watcher does not immediately
            # upload back what it just downloaded. The service would not store a
            # duplicate anyway, but a re-zip is not byte-identical to the
            # original -- zip archives carry timestamps -- so its hash check
            # cannot be relied on to catch this. The client has to know.
            $fingerprint = Get-CrossroadsFolderFingerprint $target
            $script:crossroadsSaveFingerprints[$slot] = $fingerprint
            $script:crossroadsSaveUploaded[$slot] = $fingerprint
        }
        catch {
            Write-Host ("Crossroads could not unpack the recorded save '$slot'.") `
                -ForegroundColor DarkGray
        }
        finally {
            Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
        }
    }

    if ($restoredCount -gt 0) {
        Write-Host ("Restored $restoredCount of your recorded save(s) for this server.")
    }
    else {
        Write-Host ('You have no recorded saves on this server yet, so start a ' +
                    'NEW game. Existing characters cannot be brought onto a ' +
                    'public server.')
    }
    Write-Host ''
}

function Update-CrossroadsSaves {
    param([switch]$Final)
    if (-not $script:crossroadsSavesActive) { return }
    if (-not $Final) {
        if ([DateTime]::UtcNow -lt $script:crossroadsSaveNextTick) { return }
        $script:crossroadsSaveNextTick = [DateTime]::UtcNow.AddSeconds(10)
    }

    $folders = Get-ChildItem -LiteralPath $script:crossroadsSavesFolder `
        -Directory -ErrorAction SilentlyContinue
    foreach ($folder in $folders) {
        $slot = $folder.Name
        if ($slot -notmatch $script:crossroadsSlotPattern) { continue }
        $fingerprint = Get-CrossroadsFolderFingerprint $folder.FullName
        if ([string]::IsNullOrWhiteSpace($fingerprint)) { continue }

        if (-not $Final) {
            # QUIESCE. A KotOR save is five files written over some interval, and
            # a folder zipped mid-write produces a torn save that would fail its
            # own hash on the way back in. Upload only what looked identical on
            # two consecutive ticks; anything still changing waits.
            if ($script:crossroadsSaveFingerprints[$slot] -ne $fingerprint) {
                $script:crossroadsSaveFingerprints[$slot] = $fingerprint
                continue
            }
        }
        if ($script:crossroadsSaveUploaded[$slot] -eq $fingerprint) { continue }

        $archive = Join-Path $saveWorkRoot ('send-' + [Guid]::NewGuid().ToString('N') + '.zip')
        try {
            [IO.Compression.ZipFile]::CreateFromDirectory(
                $folder.FullName, $archive,
                [IO.Compression.CompressionLevel]::Optimal, $false)
        }
        catch {
            # Most often the game still holds a handle. Not an error: the next
            # tick tries again.
            Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
            continue
        }
        if (Invoke-CrossroadsSaveUpload $slot $archive) {
            $script:crossroadsSaveUploaded[$slot] = $fingerprint
            $script:crossroadsSaveFingerprints[$slot] = $fingerprint
        }
        Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue
    }
}

function Exit-CrossroadsSaveSession {
    param([switch]$RestoreOnly)
    if (-not $script:crossroadsSavesActive) { return }
    # THE FINAL SWEEP RUNS BEFORE THE SESSION IS CLOSED, because an upload needs
    # an open session -- that is what "made while connected" means to the
    # service, and closing first would throw away the last save of the sitting.
    # The quiesce rule is skipped here: the game has exited, so nothing is still
    # being written.
    if (-not $RestoreOnly) { Update-CrossroadsSaves -Final }
    Restore-CrossroadsSaves
    Remove-Item -LiteralPath $saveWorkRoot -Recurse -Force -ErrorAction SilentlyContinue
}

function Test-KotorServerHost {
    param(
        [string]$HostName,
        [uint16]$Port
    )
    if ([string]::IsNullOrWhiteSpace($HostName)) {
        return $false
    }
    $client = [Net.Sockets.UdpClient]::new()
    try {
        $client.Client.ReceiveTimeout = 1200
        $client.Connect($HostName, $Port)
        $nonce = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString('X16')
        $request = [Text.Encoding]::ASCII.GetBytes(
            "CRS_KOTOR_STATUS_V1 $nonce")
        [void]$client.Send($request, $request.Length)
        $remote = [Net.IPEndPoint]::new([Net.IPAddress]::Any, 0)
        $response = [Text.Encoding]::ASCII.GetString(
            $client.Receive([ref]$remote))
        return $response.StartsWith("CRS_KOTOR_STATUS_V1_ACK $nonce ")
    }
    catch {
        return $false
    }
    finally {
        $client.Dispose()
    }
}

function Get-GameDirectory {
    param([string]$ConfiguredDirectory)
    if (-not [string]::IsNullOrWhiteSpace($ConfiguredDirectory)) {
        $configured = $ConfiguredDirectory.Trim('"')
        if (-not (Test-Path -LiteralPath (Join-Path $configured 'swkotor.exe'))) {
            throw 'The KotOR folder supplied by the launcher does not contain swkotor.exe.'
        }
        return (Resolve-Path -LiteralPath $configured).Path
    }
    $default = 'C:\Program Files (x86)\Steam\steamapps\common\swkotor'
    if (Test-Path -LiteralPath (Join-Path $default 'swkotor.exe')) {
        return $default
    }
    $chosen = (Read-Host 'Paste the folder containing swkotor.exe').Trim('"')
    if (-not (Test-Path -LiteralPath (Join-Path $chosen 'swkotor.exe'))) {
        throw 'The selected folder does not contain swkotor.exe.'
    }
    return (Resolve-Path -LiteralPath $chosen).Path
}

function Get-SteamExecutable {
    $runningSteam = Get-Process 'steam' -ErrorAction SilentlyContinue |
        Where-Object { $_.Path -and (Test-Path -LiteralPath $_.Path) } |
        Select-Object -First 1
    if ($runningSteam) {
        return $runningSteam.Path
    }
    $candidates = @()
    try {
        $steamPath = (Get-ItemProperty `
            'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath
        if ($steamPath) {
            $candidates += Join-Path $steamPath 'steam.exe'
        }
    }
    catch {}
    try {
        $steamPath = (Get-ItemProperty `
            'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' `
            -ErrorAction Stop).InstallPath
        if ($steamPath) {
            $candidates += Join-Path $steamPath 'steam.exe'
        }
    }
    catch {}
    $candidates += 'C:\Program Files (x86)\Steam\steam.exe'
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    return ''
}

function Start-KotorGame {
    param([string]$Game)
    $steam = Get-SteamExecutable
    if ($steam) {
        Write-Host 'Requesting KotOR launch through Steam...'
        Start-Process -FilePath $steam `
            -ArgumentList @('-applaunch', '32370') | Out-Null
        return
    }
    Write-Host 'Steam was not detected; using the game executable directly.'
    Start-Process -FilePath (Join-Path $Game 'swkotor.exe') `
        -WorkingDirectory $Game | Out-Null
}

function Get-KotorInjectedModules {
    param([int]$ProcessId)

    # KotOR is 32-bit. Ask the built-in 32-bit Windows PowerShell host to
    # enumerate its modules so this check also works when Crossroads itself was
    # launched from 64-bit PowerShell.
    $powershell32 = Join-Path $env:WINDIR `
        'SysWOW64\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $powershell32 -PathType Leaf)) {
        return @()
    }

    $probe = @"
`$process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
if (`$process) {
    `$process.Modules | ForEach-Object { `$_.ModuleName }
}
"@
    $encoded = [Convert]::ToBase64String(
        [Text.Encoding]::Unicode.GetBytes($probe))
    return @(
        & $powershell32 -NoProfile -NonInteractive `
            -EncodedCommand $encoded 2>$null |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )
}

# How many items is the saved character wearing?
#
# WHY THIS EXISTS. CrossroadsBuildIdentity.exe caps the join identity at four
# equipment entries and raises "Join identity supports at most four visible
# equipment slots". The player sees a Python traceback followed by "Crossroads
# could not read the selected player character", which names neither the cause
# nor the remedy. On 2026-08-08 that cost twenty minutes of diagnosis on a
# machine that was working an hour earlier -- an equipment test had left the
# character wearing eight items.
#
# THE MESSAGE IS ALSO WRONG, WHICH IS WHY THE REMEDY IS NOT GUESSABLE. It says
# "visible", but build_remote_template.py iterates the entire Equip_ItemList
# with no visibility filter: implants, belts and armbands count exactly as much
# as armour does. Someone unequipping only what shows on the model strips their
# character and still fails.
#
# FAILS OPEN. Returns -1 on anything it does not understand, and the caller
# then hands the builder the save exactly as before -- so a parser bug here can
# only ever restore the old behaviour, never invent a new refusal.
function Get-EquippedItemCount {
    param([string]$PifoPath)
    try {
        $bytes = [IO.File]::ReadAllBytes($PifoPath)
        # GFF V3.2 header: 8 bytes of type/version then six offset/count pairs.
        if ($bytes.Length -lt 56) { return -1 }
        $fieldOffset       = [BitConverter]::ToUInt32($bytes, 16)
        $fieldCount        = [BitConverter]::ToUInt32($bytes, 20)
        $labelOffset       = [BitConverter]::ToUInt32($bytes, 24)
        $labelCount        = [BitConverter]::ToUInt32($bytes, 28)
        # 40/44 is FieldIndices, NOT ListIndices -- reading those returned a
        # confident 170 for a save carrying 8 items, which is the kind of wrong
        # answer a gate must never produce.
        $listIndicesOffset = [BitConverter]::ToUInt32($bytes, 48)
        $listIndicesCount  = [BitConverter]::ToUInt32($bytes, 52)

        # Labels are 16 bytes, null-padded. Find the one we want by index.
        $wanted = -1
        for ($i = 0; $i -lt $labelCount; $i++) {
            $at = $labelOffset + ($i * 16)
            if ($at + 16 -gt $bytes.Length) { return -1 }
            $label = [Text.Encoding]::ASCII.GetString($bytes, $at, 16).TrimEnd([char]0)
            if ($label -eq 'Equip_ItemList') { $wanted = $i; break }
        }
        if ($wanted -lt 0) { return 0 }   # nothing equipped at all

        # Fields are 12 bytes: type, label index, data-or-offset. Type 15 is a
        # list, whose data-or-offset is a BYTE offset into the list indices
        # block, where the first uint32 is the element count.
        for ($i = 0; $i -lt $fieldCount; $i++) {
            $at = $fieldOffset + ($i * 12)
            if ($at + 12 -gt $bytes.Length) { return -1 }
            if ([BitConverter]::ToUInt32($bytes, $at + 4) -ne $wanted) { continue }
            if ([BitConverter]::ToUInt32($bytes, $at) -ne 15) { return -1 }
            $listAt = $listIndicesOffset + [BitConverter]::ToUInt32($bytes, $at + 8)
            if ($listAt + 4 -gt $bytes.Length -or
                $listAt + 4 -gt $listIndicesOffset + $listIndicesCount) { return -1 }
            return [int][BitConverter]::ToUInt32($bytes, $listAt)
        }
        return -1
    }
    catch {
        return -1
    }
}

# Write a copy of the save whose Equip_ItemList is capped, and hand THAT to the
# identity builder.
#
# WHY A COPY, AND WHY ONLY A COUNT. The join identity is a 132-byte packet:
# a 64-byte header plus exactly four 17-byte equipment slots, completely full.
# Four is therefore a fact about identity wire v1, not a tunable, and the
# builder refuses a fifth item outright -- which stopped a player from joining
# at all on 2026-08-08 because an equipment test left them wearing nine.
#
# Refusing was the wrong response to a full packet. The packer already emits
# four slots and zero-pads when given fewer, so a TRUNCATED list produces a
# valid v1 identity that every peer in the field already reads. No wire change,
# no version bump, no both-peer compatibility work -- the format is untouched.
#
# The list's length is a single uint32 in the GFF list-indices block, so capping
# it needs one integer written, not a GFF rewrite. The entries past the cap stay
# in the file and are simply never referenced, because a GFF reader walks the
# count.
#
# THE PLAYER'S SAVE IS NEVER TOUCHED. This writes into Crossroads' own state
# directory. Editing a save to make our packet fit would be trading their data
# for our convenience.
#
# NOTHING IS LOST BY THIS. The identity is only the actor's appearance at spawn.
# Equipment is a live channel (D18): the heartbeat publishes all nine slots and
# the peer's reconciler dresses the stand-in within a beat or so. What the cap
# actually decides is which items are on the actor for that first moment -- and
# KotOR stores Equip_ItemList in slot order, so the first four are the head,
# body, hands and right weapon: the visible ones.
function New-CappedIdentitySave {
    param([string]$Source, [string]$Destination, [int]$Limit)
    $bytes = [IO.File]::ReadAllBytes($Source)
    $fieldOffset       = [BitConverter]::ToUInt32($bytes, 16)
    $fieldCount        = [BitConverter]::ToUInt32($bytes, 20)
    $labelOffset       = [BitConverter]::ToUInt32($bytes, 24)
    $labelCount        = [BitConverter]::ToUInt32($bytes, 28)
    $listIndicesOffset = [BitConverter]::ToUInt32($bytes, 48)

    $wanted = -1
    for ($i = 0; $i -lt $labelCount; $i++) {
        $at = $labelOffset + ($i * 16)
        if ($at + 16 -gt $bytes.Length) { return $false }
        $label = [Text.Encoding]::ASCII.GetString($bytes, $at, 16).TrimEnd([char]0)
        if ($label -eq 'Equip_ItemList') { $wanted = $i; break }
    }
    if ($wanted -lt 0) { return $false }

    for ($i = 0; $i -lt $fieldCount; $i++) {
        $at = $fieldOffset + ($i * 12)
        if ($at + 12 -gt $bytes.Length) { return $false }
        if ([BitConverter]::ToUInt32($bytes, $at + 4) -ne $wanted) { continue }
        if ([BitConverter]::ToUInt32($bytes, $at) -ne 15) { return $false }
        $listAt = $listIndicesOffset + [BitConverter]::ToUInt32($bytes, $at + 8)
        if ($listAt + 4 -gt $bytes.Length) { return $false }
        [Array]::Copy(
            [BitConverter]::GetBytes([uint32]$Limit), 0, $bytes, $listAt, 4)
        New-Item -ItemType Directory -Force `
            -Path (Split-Path -Parent $Destination) | Out-Null
        [IO.File]::WriteAllBytes($Destination, $bytes)
        return $true
    }
    return $false
}

function Get-PlayerSave {
    param([string]$Game)
    $candidates = Get-ChildItem -LiteralPath (Join-Path $Game 'saves') `
        -Recurse -Filter 'pifo.ifo' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
    $newestValidSave = $null
    foreach ($pifo in $candidates) {
        $saveInfo = Join-Path $pifo.DirectoryName 'savenfo.res'
        if (-not (Test-Path -LiteralPath $saveInfo)) {
            continue
        }
        if (-not $newestValidSave) {
            $newestValidSave = $pifo.FullName
        }
        $ascii = [Text.Encoding]::ASCII.GetString(
            [IO.File]::ReadAllBytes($saveInfo))
        if ($ascii.Contains('tar_m02ab')) {
            return $pifo.FullName
        }
    }
    return $newestValidSave
}

function New-GenericIdentity {
    param([string]$Path)
    [byte[]]$wire = New-Object byte[] 132
    $wire[0] = 0x43
    $wire[1] = 0x52
    $wire[2] = 0x53
    $wire[3] = 0x4E
    $wire[5] = 1
    $wire[6] = 3
    $wire[7] = 2
    $wire[15] = 1
    $wire[19] = 1
    $wire[23] = 1
    $wire[25] = 95
    $wire[27] = 2
    $wire[28] = 1
    $wire[29] = 1
    $name = [Text.Encoding]::ASCII.GetBytes('Crossroads Player')
    [Array]::Copy($name, 0, $wire, 32, $name.Length)
    $wire[64] = 2
    $clothes = [Text.Encoding]::ASCII.GetBytes('g_a_clothes01')
    [Array]::Copy($clothes, 0, $wire, 65, $clothes.Length)
    $wire[81] = 16
    $blaster = [Text.Encoding]::ASCII.GetBytes('g_w_blstrpstl001')
    [Array]::Copy($blaster, 0, $wire, 82, $blaster.Length)
    [IO.File]::WriteAllBytes($Path, $wire)
}

function Get-ClientId {
    $registry = [Microsoft.Win32.RegistryKey]::OpenBaseKey(
        [Microsoft.Win32.RegistryHive]::LocalMachine,
        [Microsoft.Win32.RegistryView]::Registry64)
    try {
        $cryptography = $registry.OpenSubKey(
            'SOFTWARE\Microsoft\Cryptography', $false)
        if (-not $cryptography) {
            throw 'Windows machine identity registry key was not found.'
        }
        try {
            $machineGuid = [string]$cryptography.GetValue('MachineGuid')
        }
        finally {
            $cryptography.Dispose()
        }
    }
    finally {
        $registry.Dispose()
    }
    if ([string]::IsNullOrWhiteSpace($machineGuid)) {
        throw 'Windows machine identity is unavailable.'
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $hash = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($machineGuid))
    }
    finally {
        $sha.Dispose()
    }
    $id = [BitConverter]::ToUInt32($hash, 0)
    return $(if ($id -eq 0) { [uint32]1 } else { $id })
}

function Backup-OwnedFiles {
    param([string]$Game)
    if (Test-Path -LiteralPath $installRecord) {
        return
    }
    $override = Join-Path $Game 'Override'
    New-Item -ItemType Directory -Force -Path $override,$backup | Out-Null
    # EVERY hash Crossroads has ever shipped for these files, not just the
    # current one.
    #
    # This gate exists to refuse an unrelated mod's file. With a single hash it
    # also refused OUR OWN PREVIOUS BUILD, because a leftover from an earlier
    # session is not the current hash and is therefore "unrelated". Measured
    # 2026-08-07: the heartbeat changed twice in one day and every machine
    # holding a leftover was blocked from joining, with a message that reads
    # like a foreign mod is installed. The tester sees the game fail to start
    # and has no way to know the offending file is ours.
    #
    # So the value is a LIST, appended to whenever a payload file changes.
    # Recognising our own history is what lets the gate keep saying no to
    # somebody else's file while still replacing ours.
    $known = @{
        'cr_orig_hb.ncs' = @(
            # Retail k_def_heartbt01, saved under our name. One value; it is
            # BioWare's file and does not change.
            '1008B0A66E742332A8B7E7BD6E92B9ECF5C686D9DCB21C7A0EC7CC67C4FBF482'
        )
        'crs_pulse.ncs' = @(
            # The reconcile work KSE drives from the script dispatcher instead
            # of from whatever creature stands near the player. Listed here for
            # the same reason the heartbeat is: this table is how the join
            # recognises its OWN leftovers, so a file it does not know about
            # would be mistaken for another mod's and refuse the join (D36).
            'A8663C04D4AFB4C936B07D1A6A0A2DDCC20EF0FD220A9D5AFDD64D945A61C5C9'
        )
        'k_def_heartbt01.ncs' = @(
            # Current: per-peer equipment, compiled with nwnnsscomp (D30).
            # Same source as the entry below it; the difference is the
            # compiler, which is the whole of that incident.
            '60F8D7501572A72110B52829A9621330AEDF8D22171721BB6D3B1592A2521B89',
            # Shipped in 202608080035 and DOES NOT EXECUTE (D30). Listed anyway,
            # and deliberately: this gate's job is to recognise our own history
            # so it can replace our files, not to judge whether a given build
            # worked. A machine left holding this one after an abnormal session
            # must still be allowed to join, or it is locked out by a message
            # that blames a foreign mod.
            'B174A84D17BF27B27273D81FE6FC55AC7F63AA6D2AA6FA52B0685C6E74F132EC',
            # 2026-08-07: + peer loadout application, single actor.
            'C71DA7141B3225686637212F349DCA6D4D72A47D6C3DAC6A3C0A5FCD85495D76',
            # 2026-08-07: + local loadout publication (read half).
            '2A76582E5FE0C07BF5711B4371B2E3161F891574D1EB5411EC06A44FD1289D39',
            # 2026-08-07 and earlier: presence-driven reconciler (D19).
            '0534505A715DC30F0D72638C356196139BEA486026A6F5E85A98DBBD88CA8680'
        )
    }
    $records = @()
    foreach ($name in @(
            'cr_orig_hb.ncs',
            'k_def_heartbt01.ncs',
            'crs_pulse.ncs',
            'crossroadsghost.utc')) {
        $target = Join-Path $override $name
        $existed = Test-Path -LiteralPath $target
        $crossroadsOwned = $false
        if ($existed -and $known.ContainsKey($name)) {
            $actual = (Get-FileHash -LiteralPath $target `
                -Algorithm SHA256).Hash
            if ($known[$name] -notcontains $actual) {
                throw ("An unrelated Override\$name is installed. Crossroads " +
                       "will not replace it.`n`nIf you are certain it is not " +
                       "from another mod, delete it and rejoin.`n" +
                       "Found SHA-256: $actual")
            }
            # Past the gate above, the hash IS one of ours.
            $crossroadsOwned = $true
        }
        # crossroadsghost.utc carries no hash list because it is generated from
        # the player's own character, so its bytes differ on every machine and
        # every session. Ownership is settled by the NAME instead: that ResRef
        # is one Crossroads invented, and stock KotOR has no such template, so
        # a file at this path cannot be anybody else's.
        if ($existed -and $name -eq 'crossroadsghost.utc') {
            $crossroadsOwned = $true
        }

        # A FILE WE RECOGNISE AS OUR OWN IS NOT THE PLAYER'S FILE, AND MUST NOT
        # BE RESTORED.
        #
        # Stock KotOR ships k_def_heartbt01 inside a BIF with nothing in
        # Override, and cr_orig_hb.ncs is a name only Crossroads writes. So a
        # recognised file here was left by US -- by a session that ended
        # abnormally, before Restore-OwnedFiles could run.
        #
        # Recording it as pre-existing made that damage permanent AND
        # self-perpetuating: the next join backed our own leftover up as if it
        # were the player's, and every clean exit afterwards faithfully put it
        # back. Measured 2026-08-08 on the development machine, which had been
        # running a 2026-08-07 Crossroads heartbeat (0534505A...) as the
        # default creature heartbeat in single-player for a day, reinstalled
        # after every session, while the installed component shipped a
        # different one. It is also why Assert-CrossroadsKotorInstall reported
        # a heartbeat mismatch after every clean session -- the tool was right
        # and the restore was wrong.
        #
        # "Nothing" is the correct previous state, and recording it makes an
        # abnormal exit self-healing instead of permanent. Both files come back
        # on the next join: cr_orig_hb.ncs is re-extracted from the player's own
        # install, k_def_heartbt01.ncs is copied from the component.
        #
        # This does NOT weaken the foreign-mod gate. An unrecognised file still
        # throws above and is never written to, backed up, or deleted.
        if ($crossroadsOwned) {
            $records += [pscustomobject]@{ name = $name; existed = $false }
            continue
        }
        if ($existed) {
            Copy-Item -LiteralPath $target `
                -Destination (Join-Path $backup $name) -Force
        }
        $records += [pscustomobject]@{ name = $name; existed = $existed }
    }
    $settingsPath = Join-Path $Game 'swkotor.ini'
    if (-not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) {
        throw 'KotOR has no swkotor.ini. Launch the game once before joining Crossroads.'
    }
    Copy-Item -LiteralPath $settingsPath `
        -Destination (Join-Path $backup 'swkotor.ini') -Force
    $gpuPreferencePath =
        'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    $gameExecutable = Join-Path $Game 'swkotor.exe'
    $existingGpuPreference = $null
    $gpuPreferenceExisted = $false
    if (Test-Path -LiteralPath $gpuPreferencePath) {
        try {
            $existingGpuPreference = Get-ItemPropertyValue `
                -LiteralPath $gpuPreferencePath `
                -Name $gameExecutable `
                -ErrorAction Stop
            $gpuPreferenceExisted = $true
        }
        catch {
            $gpuPreferenceExisted = $false
        }
    }
    [pscustomobject]@{
        game = $Game
        files = $records
        settingsBackedUp = $true
        gpuPreference = [pscustomobject]@{
            executable = $gameExecutable
            existed = $gpuPreferenceExisted
            value = $existingGpuPreference
        }
    } |
        ConvertTo-Json -Depth 4 |
        Set-Content -LiteralPath $installRecord -Encoding UTF8
}

function Set-KotorHighPerformanceGpu {
    param([string]$Game)
    $gpuPreferencePath =
        'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    New-Item -Path $gpuPreferencePath -Force | Out-Null
    New-ItemProperty `
        -LiteralPath $gpuPreferencePath `
        -Name (Join-Path $Game 'swkotor.exe') `
        -PropertyType String `
        -Value 'GpuPreference=2;' `
        -Force | Out-Null
}

function Set-KotorCompatibilityProfile {
    param([string]$Game)
    $settingsPath = Join-Path $Game 'swkotor.ini'
    $lines = [Collections.Generic.List[string]]::new()
    $lines.AddRange([string[]](Get-Content -LiteralPath $settingsPath))

    $sectionStart = -1
    for ($index = 0; $index -lt $lines.Count; ++$index) {
        if ($lines[$index].Trim() -ieq '[Graphics Options]') {
            $sectionStart = $index
            break
        }
    }
    if ($sectionStart -lt 0) {
        if ($lines.Count -gt 0 -and $lines[$lines.Count - 1] -ne '') {
            $lines.Add('')
        }
        $lines.Add('[Graphics Options]')
        $sectionStart = $lines.Count - 1
    }

    $sectionEnd = $lines.Count
    for ($index = $sectionStart + 1; $index -lt $lines.Count; ++$index) {
        if ($lines[$index].Trim() -match '^\[.+\]$') {
            $sectionEnd = $index
            break
        }
    }

    foreach ($setting in @(
            [pscustomobject]@{ Key = 'AllowWindowedMode'; Value = '1' },
            [pscustomobject]@{ Key = 'FullScreen'; Value = '0' },
            [pscustomobject]@{ Key = 'Anisotropy'; Value = '0' },
            [pscustomobject]@{ Key = 'Frame Buffer'; Value = '0' },
            [pscustomobject]@{ Key = 'Grass'; Value = '0' })) {
        $found = $false
        for ($index = $sectionStart + 1; $index -lt $sectionEnd; ++$index) {
            if ($lines[$index] -match (
                    '^\s*' + [regex]::Escape($setting.Key) + '\s*=')) {
                $lines[$index] = "$($setting.Key)=$($setting.Value)"
                $found = $true
                break
            }
        }
        if (-not $found) {
            $lines.Insert(
                $sectionEnd,
                "$($setting.Key)=$($setting.Value)")
            ++$sectionEnd
        }
    }

    [IO.File]::WriteAllLines(
        $settingsPath,
        $lines,
        [Text.Encoding]::Default)
}

# Install KSE (K1SE) into the game directory. Crossroads depends on it for
# engine-sourced local-player identity (D12), so it is bundled rather than a
# tester prerequisite (D15).
#
# THE ORDER HERE IS THE WHOLE SAFETY ARGUMENT. KSE installs AS binkw32.dll and
# forwards to the renamed original. binkw32.dll is a real game import: if this
# machine is ever left without one, KotOR does not launch at all -- a worse
# outcome than any sync bug, and one the player cannot diagnose because they
# never reach a menu.
#
# So: COPY the original aside, VERIFY the copy, and only then overwrite. At no
# instant does binkw32.dll fail to exist. A move-first sequence would open a
# window where a crash, a full disk, or antivirus quarantine leaves no game.
#
# We never ship the original. It is RAD Game Tools' Bink -- retail content --
# and the packager refuses to build if a copy reaches an archive. Same rule as
# the stock heartbeat under D11.
#
# UNINSTALL IS DELIBERATE, NOT AUTOMATIC (D15). This is recorded in its own
# state file rather than the per-session install record, because
# Restore-OwnedFiles deletes what it recorded every time KotOR closes. That is
# right for a temporary ghost actor and wrong for a script extender the player
# also uses for their own single-player mods. Uninstall-KSE.ps1 reverses it.
function Install-KSE {
    param([string]$Game)

    $source = Join-Path $component 'kse\binkw32.dll'
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw ('The Crossroads KotOR component is incomplete: kse\binkw32.dll ' +
               'is missing. Restart the launcher to update.')
    }

    $proxy = Join-Path $Game 'binkw32.dll'
    $real = Join-Path $Game 'binkw32_real.dll'
    $record = Join-Path $state 'kse-install-state.json'

    if (-not (Test-Path -LiteralPath $proxy -PathType Leaf)) {
        throw ('Your KotOR folder has no binkw32.dll. Crossroads will not ' +
               'touch it in that state -- verify the game files through Steam ' +
               'first.')
    }

    # Is the proxy already ours? Identify by content, not by name: both files
    # legitimately use this filename, and only their contents distinguish them.
    $proxyText = [Text.Encoding]::ASCII.GetString(
        [IO.File]::ReadAllBytes($proxy))
    $proxyIsKse = $proxyText.Contains('KSE ') -and $proxyText.Contains('STAGE19')
    $sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash

    if ($proxyIsKse) {
        if (-not (Test-Path -LiteralPath $real -PathType Leaf)) {
            throw ('KotOR has a KSE binkw32.dll but no binkw32_real.dll to ' +
                   'forward to. The game cannot start in that state. Verify ' +
                   'the game files through Steam, then rejoin.')
        }
        if ((Get-FileHash -LiteralPath $proxy -Algorithm SHA256).Hash -eq $sourceHash) {
            Write-Host 'Crossroads script extender: already current.'
            return
        }
        # Upgrade in place. The original is already safely aside, so this is a
        # single overwrite with nothing to preserve.
        Copy-Item -LiteralPath $source -Destination $proxy -Force
        Write-Host 'Crossroads script extender: updated.'
        return
    }

    # Fresh install -- but ONLY once $proxy has been positively identified as
    # the retail Bink. It used to be asserted here in a comment and never
    # checked, and the assertion is wrong in exactly the case that matters.
    #
    # THE HOLE THIS CLOSES. The refusal below catches another mod that proxies
    # binkw32.dll only if it also preserved the original under OUR spare name.
    # A third-party extender that renames the original to anything else -- and
    # there is no convention here, the name is ours -- fell straight through to
    # this point, and Crossroads then copied THEIR proxy to binkw32_real.dll,
    # recorded its hash as "the original", and installed over it. The retail
    # Bink then survived only inside their spare file, and Uninstall-KSE.ps1
    # would later restore their proxy and report the game was back to its
    # original DLL. Both installs destroyed, silently, and the report was a lie.
    #
    # `RAD Game Tools` is the discriminator, MEASURED IN BOTH DIRECTIONS on
    # 2026-08-10 rather than assumed: it is present in retail Bink and absent
    # from the KSE proxy. The obvious-looking `Bink` is present in BOTH -- the
    # proxy has to export the same names -- so it identifies nothing. The
    # packager's own ship-time gate relies on the same pair of facts.
    if (Test-Path -LiteralPath $real -PathType Leaf) {
        throw ('KotOR already has a binkw32_real.dll but its binkw32.dll is ' +
               'not KSE. Another mod uses the same mechanism, and Crossroads ' +
               'will not overwrite it.')
    }

    if (-not $proxyText.Contains('RAD Game Tools')) {
        throw ('KotOR''s binkw32.dll is neither the retail file nor the ' +
               'Crossroads script extender, so something else installed it. ' +
               'Crossroads will not overwrite it -- doing so would bury that ' +
               'mod''s file as if it were your original, and neither could be ' +
               'restored afterwards. Uninstall the other mod, or verify the ' +
               'game files through Steam, then rejoin.')
    }

    Copy-Item -LiteralPath $proxy -Destination $real -Force
    $originalHash = (Get-FileHash -LiteralPath $proxy -Algorithm SHA256).Hash
    if ((Get-FileHash -LiteralPath $real -Algorithm SHA256).Hash -ne $originalHash) {
        Remove-Item -LiteralPath $real -Force -ErrorAction SilentlyContinue
        throw ('Crossroads could not safely preserve the original ' +
               'binkw32.dll, so it changed nothing.')
    }

    Copy-Item -LiteralPath $source -Destination $proxy -Force

    [pscustomobject]@{
        game = $Game
        installed = (Get-Date).ToString('o')
        originalSha256 = $originalHash
        proxySha256 = $sourceHash
    } |
        ConvertTo-Json -Depth 3 |
        Set-Content -LiteralPath $record -Encoding UTF8

    Write-Host 'Crossroads script extender installed.' -ForegroundColor Green
    Write-Host ('  Your original binkw32.dll was preserved as ' +
                'binkw32_real.dll. It stays installed after you disconnect; ' +
                'run Uninstall-KSE.ps1 to reverse it.')
}

function Restore-OwnedFiles {
    if (-not (Test-Path -LiteralPath $installRecord)) {
        return
    }
    $record = Get-Content -LiteralPath $installRecord -Raw | ConvertFrom-Json
    $override = Join-Path $record.game 'Override'
    foreach ($file in $record.files) {
        $target = Join-Path $override $file.name
        if ($file.existed) {
            Copy-Item -LiteralPath (Join-Path $backup $file.name) `
                -Destination $target -Force
        }
        elseif (Test-Path -LiteralPath $target) {
            Remove-Item -LiteralPath $target -Force
        }
    }
    if ($record.PSObject.Properties.Name -contains 'settingsBackedUp' -and
        $record.settingsBackedUp) {
        Copy-Item -LiteralPath (Join-Path $backup 'swkotor.ini') `
            -Destination (Join-Path $record.game 'swkotor.ini') -Force
    }
    if ($record.PSObject.Properties.Name -contains 'gpuPreference' -and
        $record.gpuPreference) {
        $gpuPreferencePath =
            'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
        if ($record.gpuPreference.existed) {
            New-Item -Path $gpuPreferencePath -Force | Out-Null
            New-ItemProperty `
                -LiteralPath $gpuPreferencePath `
                -Name $record.gpuPreference.executable `
                -PropertyType String `
                -Value $record.gpuPreference.value `
                -Force | Out-Null
        }
        elseif (Test-Path -LiteralPath $gpuPreferencePath) {
            Remove-ItemProperty `
                -LiteralPath $gpuPreferencePath `
                -Name $record.gpuPreference.executable `
                -ErrorAction SilentlyContinue
        }
    }
    Remove-Item -LiteralPath $installRecord -Force
    if (Test-Path -LiteralPath $backup) {
        Remove-Item -LiteralPath $backup -Recurse -Force
    }
}

if (-not (Test-Path -LiteralPath $component)) {
    throw 'The Crossroads KotOR component is missing. Restart the launcher to update.'
}
if (Get-Process 'swkotor' -ErrorAction SilentlyContinue) {
    throw 'Close KotOR before joining the Crossroads test server.'
}
# Recover automatically from an older interrupted client session. A previous
# build required users to return to its console and press Enter after closing
# KotOR, so abandoned install records may legitimately remain.
if (Test-Path -LiteralPath $installRecord) {
    Restore-OwnedFiles
    Write-Host 'Crossroads restored temporary files from the previous session.'
}
# AND THE SAVES, from a session that was killed rather than closed. Deliberately
# separate from the install record above: the saves swap happens BEFORE
# Backup-OwnedFiles writes that record, so a failure in between would leave saves
# parked with no install record to notice it. Its own record, restored on its own
# terms, and unconditionally -- even a join that is about to fail for some other
# reason must not leave a player's saves under a name they do not know.
Restore-CrossroadsSaves

# THE DESTINATION. Supplied by the launcher when it knows one, from the INI
# when it does not.
#
# The two paths are kept visibly apart rather than merged, because they have
# different fallback rules and merging them is how one quietly acquires the
# other's. A launcher-supplied endpoint is used EXACTLY as given: no LAN
# fallback, no INI overlay, no loopback substitution. The launcher already
# measured that address with the game's own status probe and chose it; second-
# guessing it here would send the player somewhere they did not select.
if (-not [string]::IsNullOrWhiteSpace($ServerHost) -and $ServerPort -gt 0) {
    $hostName = $ServerHost
    $port = [uint16]$ServerPort
    $session = if ([string]::IsNullOrWhiteSpace($ServerSession)) {
        '0'
    } else {
        $ServerSession
    }
    Write-Host ("Joining the server selected in the launcher: {0}:{1}" -f $hostName, $port)
}
else {
    $publicHost = Read-IniValue 'kotor1' 'server_host'
    $lanHost = Read-OptionalIniValue 'kotor1' 'server_lan_host'
    $port = [uint16](Read-IniValue 'kotor1' 'server_port')
    $session = Read-IniValue 'kotor1' 'server_session'
    $hostName = ''
    if (Get-Process 'CrossroadsKotorServer' -ErrorAction SilentlyContinue) {
        $hostName = '127.0.0.1'
    }
    elseif (Test-KotorServerHost $publicHost $port) {
        $hostName = $publicHost
    }
    elseif ($lanHost -ne $publicHost -and
        (Test-KotorServerHost $lanHost $port)) {
        $hostName = $lanHost
    }
    if (-not $hostName) {
        throw 'The Crossroads KotOR test server is not reachable.'
    }
}
$game = Get-GameDirectory $GameDirectory

# THE SESSION OPENS HERE, EARLIER THAN IT USED TO, and the save rule runs
# immediately after it -- both BEFORE Get-PlayerSave below.
#
# WHY THE ORDER MATTERS AND IS NOT COSMETIC. Get-PlayerSave picks the character
# this join will replicate to everybody else by scanning the saves folder, and it
# does so before the game has started (register 39). On a public server the saves
# folder is about to be replaced by the recorded five. If the session opened
# after that scan, identity would be read from saves the player is not allowed to
# load -- they would appear to everyone else as a character they cannot play.
# Opening the session first is what keeps the character on screen and the
# character on the wire the same one.
#
# Opening it here is still "before the game starts", which is the property the
# session record wanted: an attempt that fails to launch is still an attempt.
Open-CrossroadsSession 'kotor1' $hostName $port
Enter-CrossroadsSaveSession $game

$playerSync = Test-CrossroadsPlayerSyncEnabled

# READ ONLY WHEN SYNC IS ON. Get-PlayerSave is stage 3: it decides which character
# is replicated to everyone else by scanning the saves folder before the game has
# started. That is register 39, the fault the reset was called over, and with sync
# off there is nothing to read it for.
$pifo = if ($playerSync) { Get-PlayerSave $game } else { $null }
$clientId = Get-ClientId
New-Item -ItemType Directory -Force `
    -Path $localState,$remoteState | Out-Null

# STILL RUNS WITH SYNC OFF, and deliberately. It records what is in Override so
# Restore-OwnedFiles can put it back, and it backs up swkotor.ini and the GPU
# preference that the compatibility profile is about to change. With nothing
# installed it records our four filenames as absent, so a leftover from an earlier
# session is CLEANED UP on exit rather than left behind -- which is the behaviour
# wanted while sync is off.
Backup-OwnedFiles $game
Set-KotorCompatibilityProfile $game
if ($playerSync) {
    # Must happen before the game launches: KSE is loaded by swkotor.exe at
    # startup through the binkw32 import, so installing it afterwards has no
    # effect until the next run.
    Install-KSE $game
}

Write-Host ''
Write-Host 'PROJECT: CROSSROADS - KOTOR CLIENT'
Write-Host '================================='
if (-not $playerSync) {
    # SAID OUT LOUD, EVERY JOIN. A player who sees no other player needs to know
    # whether that is a fault or the current state of the project, and a console
    # that says nothing invites the wrong answer.
    Write-Host 'PLAYER SYNC IS DISABLED.' -ForegroundColor Yellow
    Write-Host ('Other players will not appear. Your KotOR files are not ' +
                'modified. Your session and saves are still recorded.') `
        -ForegroundColor Yellow
}
elseif ($pifo) {
    Write-Host "Character save: $pifo"
}
else {
    Write-Host 'No existing character save was found.'
    Write-Host 'Crossroads will use a temporary generic identity until the next connection.'
}
Write-Host 'Connecting to the online KotOR test server...'
Write-Host 'KotOR compatibility profile: windowed; unstable legacy graphics effects disabled.'
Write-Host 'KotOR graphics processor: Windows default selection.'

# ---- the join, with player sync disabled ------------------------------------
#
# EVERYTHING BELOW THIS BLOCK IS THE PLAYER-SYNC PATH AND IS UNCHANGED. It is
# skipped rather than rewritten, which is what "disabled, not removed" means: the
# code that runs when `player_sync=on` is byte-for-byte the code that ran before,
# so turning it back on cannot have introduced a difference. That also keeps the
# comments explaining WHY each of those steps is shaped the way it is -- the most
# valuable part of a reverse-engineered path, and the part a rewrite loses first.
#
# This block launches the game and waits for it, and does nothing else. No
# extender, no Override payloads, no identity read from a save, no relay
# registration, no peer actor, no mirror, no HUD.
if (-not $playerSync) {
    # ON THE SERVER, AND NOTHING MORE. Opened before the game so the roster shows
    # the player from the moment they join rather than from the moment KotOR
    # finishes loading.
    Start-CrossroadsPresence -HostName $hostName -Port $port `
        -SessionHex $session -Client ([uint32]$clientId)
    Update-CrossroadsPresence

    Start-KotorGame $game
    Write-Host ''
    Write-Host 'KotOR is running. You are connected to the server.'

    $gameDeadline = [DateTime]::UtcNow.AddSeconds(15)
    do {
        $gameProcess = Get-Process 'swkotor' -ErrorAction SilentlyContinue |
            Sort-Object StartTime -Descending |
            Select-Object -First 1
        if (-not $gameProcess) {
            Start-Sleep -Milliseconds 250
        }
    } while (-not $gameProcess -and [DateTime]::UtcNow -lt $gameDeadline)
    if (-not $gameProcess) {
        throw 'KotOR did not remain open after Crossroads launched it.'
    }

    # The same fifteen-second grace the sync path uses. KotOR can drop and
    # relaunch its own process during startup on some machines, and treating the
    # first disappearance as an exit would end the session while the player was
    # still loading.
    $lastKotorSeen = [DateTime]::UtcNow
    while ($true) {
        if (Get-Process 'swkotor' -ErrorAction SilentlyContinue) {
            $lastKotorSeen = [DateTime]::UtcNow
        }
        elseif (([DateTime]::UtcNow - $lastKotorSeen).TotalSeconds -ge 15) {
            break
        }
        Start-Sleep -Milliseconds 500
        # The save watcher still runs: the public save rule is not sync and does
        # not depend on it.
        Update-CrossroadsSaves
        # And the roster is kept alive. The relay culls after five seconds of
        # silence, so this has to outlive every other pause in the loop.
        Update-CrossroadsPresence
    }

    Stop-CrossroadsPresence

    # Same order as the sync path's clean exit, and for the same reasons: the
    # final save sweep needs the session still open, and the player's own saves
    # come back before anything else.
    Exit-CrossroadsSaveSession
    Close-CrossroadsSession 'closed'
    Restore-OwnedFiles
    Write-Host 'KotOR closed. Crossroads restored its temporary files.'
    try { Stop-Transcript | Out-Null } catch {}
    exit 0
}

$localIdentity = Join-Path $localState 'local_identity.crid'
if ($pifo) {
    # Wearing more than the identity packet holds is NOT a reason to refuse a
    # join. Cap a copy and carry on; the loadout channel delivers the rest.
    $identitySave = $pifo
    $equippedCount = Get-EquippedItemCount $pifo
    if ($equippedCount -gt 4) {
        $cappedSave = Join-Path $localState 'pifo-identity.ifo'
        if (New-CappedIdentitySave -Source $pifo -Destination $cappedSave -Limit 4) {
            $identitySave = $cappedSave
            Write-Host (
                "Your character has $equippedCount items equipped. The join " +
                'identity carries 4; the rest arrive over the live equipment ' +
                'channel a moment after you load in.')
        }
        else {
            # Could not read the save's layout. Hand over the original and let
            # the builder decide, which is exactly what happened before.
            Write-Host (
                'Could not pre-read this save''s equipment list; passing it ' +
                'to the identity builder unchanged.') -ForegroundColor Yellow
        }
    }

    & (Join-Path $component 'CrossroadsBuildIdentity.exe') `
        $identitySave `
        (Join-Path $component 'crossroadsghost.base.utc') `
        (Join-Path $localState 'crossroadsghost.utc')
    if ($LASTEXITCODE -ne 0) {
        throw 'Crossroads could not read the selected player character.'
    }
}
else {
    Copy-Item -LiteralPath (Join-Path $component 'crossroadsghost.base.utc') `
        -Destination (Join-Path $localState 'crossroadsghost.utc') -Force
    New-GenericIdentity $localIdentity
}

Write-Host ''
Write-Host 'Your character is ready.'
Write-Host 'KotOR will open now. Another player may connect later.'

$override = Join-Path $game 'Override'

# cr_orig_hb.ncs is the stock KotOR heartbeat script. Our override chains to it
# so normal game behaviour still runs, so it has to be in Override -- but it is
# BioWare's file, not ours, and Crossroads never ships or transfers retail game
# assets (decision D11 in docs/DECISIONS.md). It is therefore taken from THIS
# machine's own KotOR installation, which the player owns, rather than from the
# download.
#
# The hash is the stock script as Crossroads was built and tested against. A
# mismatch means a modified installation, and the extractor refuses rather than
# writing unexpected bytes into Override.
$retailHeartbeat = Join-Path $override 'cr_orig_hb.ncs'
if (-not (Test-Path -LiteralPath $retailHeartbeat)) {
    $extractor = Join-Path $PSScriptRoot 'Get-KotorRetailResource.ps1'
    if (-not (Test-Path -LiteralPath $extractor -PathType Leaf)) {
        throw ('Get-KotorRetailResource.ps1 is missing from the Crossroads ' +
               'package. Reinstall or repair it.')
    }
    try {
        & $extractor -GameDirectory $game -ResRef 'k_def_heartbt01' `
            -ResourceType 2010 -Destination $retailHeartbeat `
            -ExpectedSha256 `
            '1008B0A66E742332A8B7E7BD6E92B9ECF5C686D9DCB21C7A0EC7CC67C4FBF482' |
            Out-Null
    }
    catch {
        throw ("Crossroads could not read the stock heartbeat script from " +
               "your KotOR installation, so it cannot continue.`n`n" +
               "$($_.Exception.Message)`n`n" +
               'Crossroads does not distribute game files, so it takes this ' +
               'one from your own copy of the game.')
    }
}

Copy-Item -LiteralPath (Join-Path $component 'k_def_heartbt01.ncs') `
    -Destination $override -Force

# crs_pulse.ncs -- the script KSE runs from the engine's dispatcher (~4 Hz)
# instead of waiting for a creature to stand within 25 m of the player. Copied
# only if the component carries it, so an older component still installs.
$pulsePayload = Join-Path $component 'crs_pulse.ncs'
if (Test-Path -LiteralPath $pulsePayload -PathType Leaf) {
    Copy-Item -LiteralPath $pulsePayload -Destination $override -Force
}
$installedRemoteActor = Join-Path $override 'crossroadsghost.utc'
# KotOR may cache a missing ResRef for the lifetime of the process. Install a
# safe actor template before launching the game so the heartbeat can always
# resolve and spawn it. The peer's customized identity replaces this template
# as soon as the exchange completes.
Copy-Item -LiteralPath (Join-Path $component 'crossroadsghost.base.utc') `
    -Destination $installedRemoteActor -Force

$remoteIdentity = Join-Path $remoteState 'remote_identity.crid'
$identityArguments = @(
    $hostName,
    $port.ToString(),
    "0x$session",
    $clientId.ToString(),
    ('"' + $localIdentity + '"'),
    ('"' + $remoteIdentity + '"'),
    '86400'
)
$identityProcess = Start-Process `
    -FilePath (Join-Path $component 'CrossroadsIdentityExchange.exe') `
    -ArgumentList $identityArguments -NoNewWindow -PassThru

Write-Host ''
Write-Host 'Launching KotOR...'
# The session was opened further up, before Get-PlayerSave, so that identity is
# read from the saves this join is actually allowed to use. See the comment
# there -- it must not be moved back down here.

Start-KotorGame $game
Write-Host 'You may load Taris - Upper City North and play while Crossroads waits.'
Write-Host 'The other player will be prepared when they connect.'

$gameDeadline = [DateTime]::UtcNow.AddSeconds(15)
do {
    $gameProcess = Get-Process 'swkotor' -ErrorAction SilentlyContinue |
        Sort-Object StartTime -Descending |
        Select-Object -First 1
    if (-not $gameProcess) {
        Start-Sleep -Milliseconds 250
    }
} while (-not $gameProcess -and [DateTime]::UtcNow -lt $gameDeadline)
if (-not $gameProcess) {
    throw 'KotOR did not remain open after Crossroads launched it.'
}

$injectedModules = Get-KotorInjectedModules $gameProcess.Id
if ($injectedModules -imatch '^DiscordHook\.dll$') {
    Write-Host ''
    Write-Host 'CROSSROADS STABILITY WARNING' -ForegroundColor Yellow
    Write-Host 'Discord Clips attached its capture hook to KotOR.' `
        -ForegroundColor Yellow
    Write-Host 'Disable Discord Settings > Clips, restart Discord, and restart this session.' `
        -ForegroundColor Yellow
    try { [Console]::Beep(660, 180) } catch {}
}

$hudArguments = @(
    $gameProcess.Id.ToString(),
    $hostName,
    $port.ToString()
)
# Capacity is passed ONLY when this install actually knows one, and the HUD
# prints no denominator at all when it is absent. It used to print a hardcoded
# "/ 4" regardless, which said four while the relay held sixty-four.
#
# server_capacity is optional and is the same key the launcher reads for the
# server browser, so the two cannot disagree about this install's own server.
#
# READ FROM crossroads-launcher.ini FIRST, exactly as the launcher does.
# crossroads-network.ini is UPDATER-MANAGED -- it ships inside the platform
# component, so anything hand-edited there is overwritten by the next update
# and the setting silently reverts. crossroads-launcher.ini is shipped by
# nothing and is where a local override belongs. Reading only the managed file
# here would have meant the launcher honouring an override that the HUD never
# saw, which is precisely the disagreement the comment above claims cannot
# happen.
$launcherConfigPath = Join-Path $root 'crossroads-launcher.ini'
$configuredCapacity = ''
if (Test-Path -LiteralPath $launcherConfigPath -PathType Leaf) {
    $current = ''
    foreach ($line in Get-Content -LiteralPath $launcherConfigPath) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') { $current = $Matches[1]; continue }
        if ($current -eq 'kotor1' -and $trimmed -match '^server_capacity=(.*)$') {
            $configuredCapacity = $Matches[1].Trim()
            break
        }
    }
}
if ([string]::IsNullOrWhiteSpace($configuredCapacity)) {
    $configuredCapacity = Read-OptionalIniValue 'kotor1' 'server_capacity'
}
if ($configuredCapacity -match '^\d+$' -and [int]$configuredCapacity -gt 0) {
    $hudArguments += $configuredCapacity
}
$hudProcess = Start-Process `
    -FilePath (Join-Path $component 'CrossroadsKotorHud.exe') `
    -ArgumentList $hudArguments -PassThru

$lastKotorSeen = [DateTime]::UtcNow
while (-not $identityProcess.HasExited) {
    if (Get-Process 'swkotor' -ErrorAction SilentlyContinue) {
        $lastKotorSeen = [DateTime]::UtcNow
    }
    elseif (([DateTime]::UtcNow - $lastKotorSeen).TotalSeconds -ge 15) {
        break
    }
    Start-Sleep -Milliseconds 500
    $identityProcess.Refresh()
    Update-CrossroadsSaves
}
if (-not (Get-Process 'swkotor' -ErrorAction SilentlyContinue)) {
    if (-not $identityProcess.HasExited) {
        Stop-Process -Id $identityProcess.Id -Force
    }
    Exit-CrossroadsSaveSession
    # CLOSED HERE TOO. This exit -- KotOR closed before the identity exchange
    # finished -- returned 0 without closing the session, so a player who quit
    # during the handshake left a row open until the service's twelve-hour
    # abandoned sweep. Every playtime figure derived from it would then have been
    # wrong in the same direction, and with saves in the picture an open session
    # is also a standing upload permit.
    Close-CrossroadsSession 'closed'
    Restore-OwnedFiles
    Write-Host 'KotOR closed. Crossroads restored its temporary files.'
    try { Stop-Transcript | Out-Null } catch {}
    exit 0
}
$identityProcess.WaitForExit()
$identityProcess.Refresh()
$identityExitCode = try {
    [int]$identityProcess.ExitCode
}
catch {
    $null
}

# The exchanged CRID is the authoritative success result. Windows PowerShell can
# expose Process.ExitCode as an empty AutomationNull value after a successful
# child process, especially when the helper shares this console. Do not reject a
# valid identity merely because that advisory property is unavailable.
$remoteIdentityReady = $false
$remoteIdentityLength = 0
$identityFileDeadline = [DateTime]::UtcNow.AddSeconds(2)
do {
    if (Test-Path -LiteralPath $remoteIdentity -PathType Leaf) {
        $remoteIdentityLength =
            (Get-Item -LiteralPath $remoteIdentity).Length
        $remoteIdentityReady = ($remoteIdentityLength -eq 132)
    }
    if (-not $remoteIdentityReady) {
        Start-Sleep -Milliseconds 100
    }
} while (-not $remoteIdentityReady -and
    [DateTime]::UtcNow -lt $identityFileDeadline)

if (-not $remoteIdentityReady) {
    $reportedExitCode = if ($null -eq $identityExitCode) {
        'unavailable'
    }
    else {
        $identityExitCode.ToString()
    }
    throw "The player identity exchange did not produce a valid 132-byte identity file (received $remoteIdentityLength bytes; helper exit code $reportedExitCode)."
}

$remoteActor = Join-Path $remoteState 'crossroadsghost.utc'
& (Join-Path $component 'CrossroadsApplyIdentity.exe') `
    $remoteIdentity `
    (Join-Path $component 'crossroadsghost.base.utc') `
    $remoteActor
if ($LASTEXITCODE -ne 0) {
    throw 'Crossroads could not prepare the other player actor.'
}

Copy-Item -LiteralPath $remoteActor `
    -Destination $installedRemoteActor -Force

Write-Host ''
Write-Host 'Another player connected. Their Crossroads actor is ready.' `
    -ForegroundColor Green
try { [Console]::Beep(660, 220) } catch {}
Write-Host ''
Write-Host 'Starting the persistent Crossroads movement connection...'
Write-Host 'Enter or reload the same area as the other player if their actor is not visible.'

if (-not (Get-Process 'swkotor' -ErrorAction SilentlyContinue)) {
    Restore-OwnedFiles
    throw 'KotOR closed before movement synchronization began.'
}

$gameProcess = Get-Process 'swkotor' -ErrorAction SilentlyContinue |
    Sort-Object StartTime -Descending |
    Select-Object -First 1
$movementArguments = @(
    'network-peer',
    $gameProcess.Id.ToString(),
    $hostName,
    $port.ToString(),
    '86400',
    "0x$session",
    $clientId.ToString(),
    'execute-crossroads-peer-mirror'
)
$movementExecutable =
    Join-Path $component 'CrossroadsLiveMirror.exe'
$movementAttempt = 0
$movementProcess = $null

# WHY: CrossroadsLiveMirror is the only component that can report whether actor
# discovery actually succeeded, and it reports it on stdout/stderr. Start-Transcript
# hooks the PowerShell host's own output stream, NOT the console handle a native
# child process writes to, so under -NoNewWindow that text reached the screen and
# was never recorded anywhere. 51 mirror restarts across 21 sessions were logged
# with no reason captured. Give each attempt its own pair of capture files and
# echo them back into the transcript so the reason survives the session.
$mirrorLogDirectory = Join-Path $state 'mirror-logs'
New-Item -ItemType Directory -Force -Path $mirrorLogDirectory | Out-Null
$mirrorRunStamp = [DateTime]::Now.ToString('yyyyMMdd-HHmmss')
$mirrorLaunchCount = 0

function Write-MirrorCapture {
    param([string]$Label, [string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Write-Host "    [$Label] (no file)"
        return
    }
    $captured = @(Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)
    if ($captured.Count -eq 0) {
        Write-Host "    [$Label] (empty)"
        return
    }
    # A long successful run emits one line per movement-state change. The
    # discovery block sits at the top and the failure reason at the bottom, so
    # keep both ends rather than truncating one of them away.
    if ($captured.Count -le 200) {
        $shown = $captured
    }
    else {
        $shown = $captured[0..119] +
            "... $($captured.Count - 180) line(s) omitted ..." +
            $captured[-60..-1]
    }
    Write-Host "    [$Label] $($captured.Count) line(s):"
    foreach ($line in $shown) {
        Write-Host "      $line"
    }
}

Write-Host 'Starting Crossroads actor mirroring...'

# Actor discovery and placement are allowed to recover independently from the
# player's server session. A transient area load, stale actor, or rejected
# placement must never terminate the wrapper and remove the player from the
# server roster. Restarting within the server's five-second registration window
# preserves the same client identity and session.
while (Get-Process -Id $gameProcess.Id -ErrorAction SilentlyContinue) {
    ++$mirrorLaunchCount
    $mirrorOutPath = Join-Path $mirrorLogDirectory (
        "mirror-$mirrorRunStamp-{0:d3}-out.txt" -f $mirrorLaunchCount)
    $mirrorErrPath = Join-Path $mirrorLogDirectory (
        "mirror-$mirrorRunStamp-{0:d3}-err.txt" -f $mirrorLaunchCount)
    $mirrorStarted = [DateTime]::UtcNow
    $movementProcess = try {
        Start-Process `
            -FilePath $movementExecutable `
            -ArgumentList $movementArguments -NoNewWindow -PassThru `
            -RedirectStandardOutput $mirrorOutPath `
            -RedirectStandardError $mirrorErrPath
    }
    catch {
        $null
    }

    # WHY: Start-Process -PassThru hands back a Process object that has not
    # cached the OS process handle, so .ExitCode reads back as $null forever --
    # measured on this project's own binaries, not assumed. Touching .Handle once
    # makes the runtime cache it and the real exit code becomes readable. Without
    # this the mirror's exit codes (5 = discovery, 9 = ghost changed underneath,
    # 12/13 = write failure) are permanently unavailable to the wrapper.
    if ($movementProcess) {
        try { $null = $movementProcess.Handle } catch {}
    }

    if (-not $movementProcess) {
        ++$movementAttempt
        Write-Host (
            'Crossroads could not start actor mirroring. ' +
            'The server connection is staying active; retrying in one second.'
        ) -ForegroundColor Yellow
        Start-Sleep -Seconds 1
        continue
    }

    while ((Get-Process -Id $gameProcess.Id -ErrorAction SilentlyContinue) -and
        -not $movementProcess.HasExited) {
        Start-Sleep -Milliseconds 250
        $movementProcess.Refresh()
        # The save watcher rides this loop rather than owning a thread or a
        # process of its own. It rate-limits itself to one pass every ten
        # seconds and does nothing at all unless this is a public session, so on
        # every other join it costs one comparison per quarter second.
        Update-CrossroadsSaves
    }

    if (-not (Get-Process -Id $gameProcess.Id -ErrorAction SilentlyContinue)) {
        break
    }

    $movementProcess.WaitForExit()
    $movementProcess.Refresh()
    # WHY: [int]$null evaluates to 0 in PowerShell and does NOT throw, so the
    # previous `try { [int]$_.ExitCode } catch { $null }` silently converted an
    # UNAVAILABLE exit code into a reported 0, which reads as success. The live
    # mirror's only genuine 0 requires completing its full 86400-second run, so
    # every "exit code 0" in earlier logs actually meant "code unknown" and hid a
    # restart loop. Read the raw value and null-check it BEFORE casting.
    $movementExit = $null
    try {
        $rawMovementExit = $movementProcess.ExitCode
        if ($null -ne $rawMovementExit) {
            $movementExit = [int]$rawMovementExit
        }
    }
    catch {
        $movementExit = $null
    }
    $reportedMovementExit = if ($null -eq $movementExit) {
        'unavailable'
    }
    else {
        $movementExit.ToString()
    }
    $mirrorSeconds = [Math]::Round(
        ([DateTime]::UtcNow - $mirrorStarted).TotalSeconds, 1)
    ++$movementAttempt
    Write-Host (
        "[$([DateTime]::Now.ToString('HH:mm:ss'))] " +
        "Crossroads actor mirroring paused (exit code $reportedMovementExit) " +
        "after $mirrorSeconds second(s). " +
        'You remain connected; retrying automatically in one second.'
    ) -ForegroundColor Yellow
    Write-MirrorCapture 'mirror stdout' $mirrorOutPath
    Write-MirrorCapture 'mirror stderr' $mirrorErrPath
    Start-Sleep -Seconds 1
}

if ($movementProcess -and -not $movementProcess.HasExited) {
    Stop-Process -Id $movementProcess.Id -Force
    $movementProcess.WaitForExit()
}
# BEFORE the session closes: the final upload sweep needs an open session,
# because "made while connected" is enforced by the service as "there is a
# session open for you right now". This also puts the player's own saves back.
Exit-CrossroadsSaveSession
Close-CrossroadsSession 'closed'
Restore-OwnedFiles
Write-Host 'KotOR closed. Crossroads disconnected and restored its temporary files.'
try { Stop-Transcript | Out-Null } catch {}
exit 0
