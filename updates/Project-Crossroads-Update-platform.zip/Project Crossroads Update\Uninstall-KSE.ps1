<#
    Uninstall-KSE.ps1 -- put KotOR's original binkw32.dll back.

    Crossroads installs the KSE script extender as binkw32.dll and preserves the
    game's original as binkw32_real.dll. It does NOT reverse that when you
    disconnect, deliberately: KSE is also useful for single-player modding, and
    a multiplayer session ending is no reason to uninstall it (decision D15).

    This script is the deliberate reversal. Run it if you want KOTOR back
    exactly as it shipped.

    ORDER, for the same reason as the install: binkw32.dll is a real game
    import, and a KotOR with no binkw32.dll does not launch at all. So the
    original is copied back OVER the proxy, and only then is the spare removed.
    At no instant does the game lack a binkw32.dll.
#>

[CmdletBinding()]
param(
    [string]$GameDirectory = ''
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Get-GameDirectory {
    param([string]$Configured)
    if (-not [string]::IsNullOrWhiteSpace($Configured)) {
        $c = $Configured.Trim('"')
        if (-not (Test-Path -LiteralPath (Join-Path $c 'swkotor.exe'))) {
            throw 'That folder does not contain swkotor.exe.'
        }
        return (Resolve-Path -LiteralPath $c).Path
    }
    $default = 'C:\Program Files (x86)\Steam\steamapps\common\swkotor'
    if (Test-Path -LiteralPath (Join-Path $default 'swkotor.exe')) {
        return $default
    }
    $chosen = (Read-Host 'Paste the folder containing swkotor.exe').Trim('"')
    if (-not (Test-Path -LiteralPath (Join-Path $chosen 'swkotor.exe'))) {
        throw 'That folder does not contain swkotor.exe.'
    }
    return (Resolve-Path -LiteralPath $chosen).Path
}

if (Get-Process 'swkotor' -ErrorAction SilentlyContinue) {
    throw 'Close KotOR before uninstalling the script extender.'
}

$game = Get-GameDirectory $GameDirectory
$proxy = Join-Path $game 'binkw32.dll'
$real = Join-Path $game 'binkw32_real.dll'
$record = Join-Path $root 'state\kotor1\kse-install-state.json'

if (-not (Test-Path -LiteralPath $real -PathType Leaf)) {
    Write-Host 'No binkw32_real.dll found -- the script extender is not installed.'
    Write-Host 'Nothing was changed.'
    exit 0
}

if (Test-Path -LiteralPath $proxy -PathType Leaf) {
    $text = [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($proxy))
    if (-not ($text.Contains('KSE ') -and $text.Contains('STAGE19'))) {
        throw ("$proxy is not the Crossroads script extender. Something else " +
               'installed it, and this script will not overwrite it.')
    }
}

# If the original's hash was recorded at install, confirm the spare still
# matches it. A mismatch means the preserved file changed underneath us, and
# restoring it blindly would install unknown bytes as a game import.
if (Test-Path -LiteralPath $record -PathType Leaf) {
    try {
        $saved = Get-Content -LiteralPath $record -Raw | ConvertFrom-Json
        if ($saved.originalSha256) {
            $actual = (Get-FileHash -LiteralPath $real -Algorithm SHA256).Hash
            if ($actual -ne $saved.originalSha256) {
                throw ('binkw32_real.dll does not match the file Crossroads ' +
                       'preserved at install time. Refusing to restore it. ' +
                       'Verify the game files through Steam instead.')
            }
        }
    }
    catch [System.Management.Automation.RuntimeException] {
        throw
    }
    catch {
        Write-Host 'Install record unreadable; continuing on the file itself.'
    }
}

# Is the spare actually the retail file? Checked BEFORE restoring it, because
# the last line of this script claims the game is back to its original DLL and
# that claim has to be true.
#
# This catches a machine where an older Crossroads buried ANOTHER mod's proxy
# as binkw32_real.dll -- the installer permitted that until 2026-08-10 and any
# install made before then may be in that state. Restoring it would put the
# other mod's file back as the game's import and report success, and the retail
# Bink would be gone from anywhere this script can find it.
#
# `RAD Game Tools` is measured, not assumed: present in retail Bink, absent
# from the KSE proxy. `Bink` alone appears in both and discriminates nothing.
$realText = [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($real))
if (-not $realText.Contains('RAD Game Tools')) {
    throw ('binkw32_real.dll is not the retail file Crossroads expected to ' +
           'preserve -- another mod''s DLL appears to have been saved in its ' +
           'place. Nothing has been changed. Verify the game files through ' +
           'Steam to restore the original, and reinstall any other mod that ' +
           'proxies binkw32.dll.')
}

Copy-Item -LiteralPath $real -Destination $proxy -Force
$restored = (Get-FileHash -LiteralPath $proxy -Algorithm SHA256).Hash
if ($restored -ne (Get-FileHash -LiteralPath $real -Algorithm SHA256).Hash) {
    throw ('The original could not be restored cleanly. binkw32_real.dll has ' +
           'been left in place -- copy it over binkw32.dll by hand before ' +
           'launching KotOR.')
}

Remove-Item -LiteralPath $real -Force
if (Test-Path -LiteralPath $record -PathType Leaf) {
    Remove-Item -LiteralPath $record -Force
}

Write-Host 'The Crossroads script extender was removed.' -ForegroundColor Green
Write-Host 'KotOR is back to its original binkw32.dll.'
