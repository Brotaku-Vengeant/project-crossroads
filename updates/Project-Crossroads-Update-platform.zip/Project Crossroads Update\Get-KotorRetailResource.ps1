[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$GameDirectory,
    [Parameter(Mandatory = $true)][string]$ResRef,
    [Parameter(Mandatory = $true)][int]$ResourceType,
    [Parameter(Mandatory = $true)][string]$Destination,
    [string]$ExpectedSha256
)

# Extract one resource from the player's own KotOR installation.
#
# WHY THIS EXISTS: Crossroads must never ship or transfer retail game assets
# (decision D11 in docs/DECISIONS.md). The KotOR override chains to the stock
# heartbeat script so normal game behaviour still runs, which means that script
# has to be present at runtime -- but it is BioWare's, not ours, so we cannot
# put it in a download. The player already owns the game, so we take it from
# their copy at setup time instead. That is the standard modding practice and
# it is the whole reason this file exists.
#
# The stock scripts are not loose on disk. They live inside the Aurora/Odyssey
# KEY/BIF archive pair: chitin.key is the index, data\*.bif hold the bytes.
# So a small reader is unavoidable.
#
# Formats implemented here (both V1, verified against a retail Steam install):
#
#   chitin.key
#     0x00  char[4]  "KEY "
#     0x04  char[4]  "V1  "
#     0x08  uint32   BIF count
#     0x0C  uint32   resource count
#     0x10  uint32   offset to file table
#     0x14  uint32   offset to key table
#     file table entry, 12 bytes: size, filename offset, filename length,
#                                 drive flags
#     key table entry,  22 bytes: ResRef[16], resource type uint16,
#                                 resource id uint32
#     The resource id packs both coordinates: the top 12 bits select the BIF,
#     the low 20 bits select the resource inside it.
#
#   data\*.bif
#     0x00  char[4]  "BIFF"
#     0x04  char[4]  "V1  "
#     0x08  uint32   variable resource count
#     0x0C  uint32   fixed resource count
#     0x10  uint32   offset to variable resource table
#     variable resource entry, 16 bytes: id, offset, size, type
#
# Resource types used by Crossroads: 2010 = NCS (compiled script).

$ErrorActionPreference = 'Stop'

function Read-U32([byte[]]$Buffer, [int]$Offset) {
    return [BitConverter]::ToUInt32($Buffer, $Offset)
}
function Read-U16([byte[]]$Buffer, [int]$Offset) {
    return [BitConverter]::ToUInt16($Buffer, $Offset)
}

$keyPath = Join-Path $GameDirectory 'chitin.key'
if (-not (Test-Path -LiteralPath $keyPath -PathType Leaf)) {
    throw ("No chitin.key in '$GameDirectory'. That is not a KotOR " +
           'installation directory.')
}

$key = [IO.File]::ReadAllBytes($keyPath)
if ($key.Length -lt 24) { throw 'chitin.key is too small to be valid.' }

$signature = [Text.Encoding]::ASCII.GetString($key, 0, 4)
$version = [Text.Encoding]::ASCII.GetString($key, 4, 4)
if ($signature -ne 'KEY ' -or $version -ne 'V1  ') {
    throw "Unsupported chitin.key format: '$signature$version' (expected 'KEY V1  ')."
}

$bifCount = Read-U32 $key 8
$resourceCount = Read-U32 $key 12
$fileTableOffset = Read-U32 $key 16
$keyTableOffset = Read-U32 $key 20

# Bounds-check the tables before walking them. This parses a file the user
# supplies the path to, so a malformed or truncated archive must produce a
# clear error rather than an out-of-range read.
if ($keyTableOffset + [int64]$resourceCount * 22 -gt $key.Length) {
    throw 'chitin.key key table runs past the end of the file.'
}
if ($fileTableOffset + [int64]$bifCount * 12 -gt $key.Length) {
    throw 'chitin.key file table runs past the end of the file.'
}

$targetRef = $ResRef.ToLowerInvariant()
$foundId = $null
for ($i = 0; $i -lt $resourceCount; $i++) {
    $entry = $keyTableOffset + $i * 22
    # ResRef is a fixed 16-byte field, null-padded rather than terminated.
    $name = [Text.Encoding]::ASCII.GetString($key, $entry, 16).TrimEnd([char]0)
    if ($name.ToLowerInvariant() -ne $targetRef) { continue }
    if ((Read-U16 $key ($entry + 16)) -ne $ResourceType) { continue }
    $foundId = Read-U32 $key ($entry + 18)
    break
}
if ($null -eq $foundId) {
    throw ("'$ResRef' (type $ResourceType) is not in this installation's " +
           'resource index.')
}

$bifIndex = [int]($foundId -shr 20)
$resourceIndex = [int]($foundId -band 0xFFFFF)
if ($bifIndex -ge $bifCount) {
    throw "Resource points at BIF $bifIndex, but only $bifCount exist."
}

$fileEntry = $fileTableOffset + $bifIndex * 12
$nameOffset = Read-U32 $key ($fileEntry + 4)
$nameLength = Read-U16 $key ($fileEntry + 8)
if ($nameOffset + $nameLength -gt $key.Length) {
    throw 'chitin.key BIF filename runs past the end of the file.'
}
# Stored with Windows separators and a trailing null.
$bifRelative = [Text.Encoding]::ASCII.GetString($key, $nameOffset, $nameLength).TrimEnd([char]0)
$bifPath = Join-Path $GameDirectory ($bifRelative -replace '/', '\')
if (-not (Test-Path -LiteralPath $bifPath -PathType Leaf)) {
    throw "The index names '$bifRelative', but that archive is missing."
}

$bifStream = [IO.File]::OpenRead($bifPath)
try {
    $header = New-Object byte[] 20
    if ($bifStream.Read($header, 0, 20) -ne 20) {
        throw "'$bifRelative' is too small to be a BIF archive."
    }
    $bifSignature = [Text.Encoding]::ASCII.GetString($header, 0, 4)
    $bifVersion = [Text.Encoding]::ASCII.GetString($header, 4, 4)
    if ($bifSignature -ne 'BIFF' -or $bifVersion -ne 'V1  ') {
        throw "Unsupported archive format in '$bifRelative': '$bifSignature$bifVersion'."
    }
    $variableCount = Read-U32 $header 8
    $variableTableOffset = Read-U32 $header 16
    if ($resourceIndex -ge $variableCount) {
        throw ("Resource index $resourceIndex is outside '$bifRelative' " +
               "(it holds $variableCount).")
    }

    $entryOffset = [int64]$variableTableOffset + [int64]$resourceIndex * 16
    if ($entryOffset + 16 -gt $bifStream.Length) {
        throw "'$bifRelative' resource table runs past the end of the file."
    }
    $bifStream.Position = $entryOffset
    $entryBytes = New-Object byte[] 16
    [void]$bifStream.Read($entryBytes, 0, 16)
    $dataOffset = Read-U32 $entryBytes 4
    $dataSize = Read-U32 $entryBytes 8

    if ([int64]$dataOffset + [int64]$dataSize -gt $bifStream.Length) {
        throw "'$bifRelative' claims a resource that runs past the end of the file."
    }

    $bifStream.Position = $dataOffset
    $payload = New-Object byte[] $dataSize
    $read = 0
    while ($read -lt $dataSize) {
        $chunk = $bifStream.Read($payload, $read, $dataSize - $read)
        if ($chunk -le 0) { throw "'$bifRelative' ended early while reading the resource." }
        $read += $chunk
    }
}
finally {
    $bifStream.Dispose()
}

# Verify before writing, so a mismatch never lands on disk. The caller passes
# the hash of the exact resource Crossroads was built against; a different one
# means a modded or unexpected installation and the caller should decide what
# to do rather than silently getting different bytes.
if ($ExpectedSha256) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $actual = [BitConverter]::ToString($sha.ComputeHash($payload)).Replace('-', '') }
    finally { $sha.Dispose() }
    if ($actual -ne $ExpectedSha256.ToUpperInvariant()) {
        throw ("'$ResRef' from this installation does not match the expected " +
               "content.`n  expected $($ExpectedSha256.ToUpperInvariant())`n" +
               "  found    $actual`nThe installation may be modified.")
    }
}

$destinationDirectory = Split-Path -Parent $Destination
if ($destinationDirectory -and -not (Test-Path -LiteralPath $destinationDirectory)) {
    New-Item -ItemType Directory -Force -Path $destinationDirectory | Out-Null
}
[IO.File]::WriteAllBytes($Destination, $payload)

[pscustomobject]@{
    ResRef  = $ResRef
    Archive = $bifRelative
    Bytes   = $payload.Length
    Path    = $Destination
}
