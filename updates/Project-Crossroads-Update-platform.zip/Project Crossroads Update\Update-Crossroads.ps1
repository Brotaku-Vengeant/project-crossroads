[CmdletBinding()]
param(
    [int]$ParentProcessId = 0,
    [switch]$AfterUpdateCheck,
    [switch]$AcceptUpdate,
    [switch]$NoLaunch,

    # Install ONE component instead of the whole package (D33).
    #
    # Empty is the legacy behaviour and stays the default: the whole managed set,
    # checked at launcher start, exactly as before. Every launcher already in the
    # field invokes this script with no -Component and must keep working
    # unchanged -- this script is the only thing that could repair a client it
    # broke, so it must never be what breaks one.
    #
    # A value names a component in the manifest's `games` map (or 'platform').
    # The launcher passes it when the player presses Join, before the join is
    # allowed.
    [string]$Component = ''
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$launcher = Join-Path $root 'ProjectCrossroadsLauncher.exe'
$channelPath = Join-Path $root 'update-channel.json'
$installedBuildPath = Join-Path $root 'crossroads-build.txt'
$logPath = Join-Path $root 'updater-log.txt'

Add-Type -AssemblyName PresentationFramework

function Write-UpdaterLog([string]$message) {
    $line = '{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $message
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

function Show-UpdateError([string]$message) {
    [System.Windows.MessageBox]::Show(
        $message,
        'Project: Crossroads - Updater',
        'OK',
        'Error') | Out-Null
}

function Start-Launcher {
    if ($NoLaunch) {
        return
    }
    if (Test-Path -LiteralPath $launcher -PathType Leaf) {
        Start-Process -FilePath $launcher -ArgumentList '--after-update-check' `
            -WorkingDirectory $root
    }
}

function Read-BuildNumber([string]$path) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return [Int64]0
    }
    $value = (Get-Content -LiteralPath $path -Raw).Trim()
    $parsed = [Int64]0
    if (-not [Int64]::TryParse($value, [ref]$parsed) -or $parsed -lt 0) {
        return [Int64]0
    }
    return $parsed
}

function Resolve-UpdateSource([string]$source, [string]$baseSource) {
    if ([IO.Path]::IsPathRooted($source)) {
        return [IO.Path]::GetFullPath($source)
    }
    $absolute = $null
    if ([Uri]::TryCreate($source, [UriKind]::Absolute, [ref]$absolute)) {
        return $absolute.AbsoluteUri
    }
    $baseUri = $null
    if ([Uri]::TryCreate($baseSource, [UriKind]::Absolute, [ref]$baseUri) -and
        $baseUri.Scheme -in @('http', 'https', 'file')) {
        return ([Uri]::new($baseUri, $source)).AbsoluteUri
    }
    return [IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $baseSource) $source))
}

function Copy-UpdateSource([string]$source, [string]$destination) {
    if (Test-Path -LiteralPath $source -PathType Leaf) {
        Copy-Item -LiteralPath $source -Destination $destination -Force
        return
    }
    $uri = $null
    if ([Uri]::TryCreate($source, [UriKind]::Absolute, [ref]$uri)) {
        if ($uri.Scheme -eq 'https') {
            Invoke-WebRequest -UseBasicParsing -Uri $uri.AbsoluteUri `
                -OutFile $destination -TimeoutSec 20
            return
        }
        if ($uri.Scheme -eq 'file') {
            Copy-Item -LiteralPath $uri.LocalPath -Destination $destination -Force
            return
        }
        throw 'The update source must use HTTPS.'
    }
    Copy-Item -LiteralPath ([IO.Path]::GetFullPath($source)) `
        -Destination $destination -Force
}

function Test-SafeRelativePath([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path) -or
        [IO.Path]::IsPathRooted($path) -or
        $path.Contains('..') -or
        $path.Contains(':')) {
        return $false
    }
    $normalized = $path.Replace('/', '\').TrimStart('\')
    return -not ($normalized -ieq 'runtime' -or
        $normalized.StartsWith('runtime\', [StringComparison]::OrdinalIgnoreCase) -or
        $normalized -ieq 'startup-log.txt' -or
        $normalized -ieq 'diagnostic-report.txt' -or
        $normalized -ieq 'network-room-code.txt' -or
        $normalized -ieq 'updater-log.txt')
}

# ---- per-component install records (D33) ------------------------------------
#
# ONE FILE PER COMPONENT, recording the build AND the exact files it owns.
#
# The build is what the launcher's Join gate compares against the manifest. The
# file list is what makes ownership knowable locally, which is what lets an
# install refuse to touch a file another component owns -- and what will let an
# uninstall remove exactly what a game put there, rather than guessing from a
# path prefix (Fallout's files are not under a components\fallout3\ prefix at
# all).
#
# Deliberately ONE file rather than a build stamp plus a separate manifest. Two
# pieces of state describing the same thing is how they come to disagree, and a
# disagreement here is invisible until an uninstall removes the wrong file.
$componentStateRoot = Join-Path $root '.crossroads-components'

function Get-ComponentStatePath([string]$id) {
    return Join-Path $componentStateRoot ($id + '.json')
}

function Read-ComponentState([string]$id) {
    $path = Get-ComponentStatePath $id
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return $null
    }
    try {
        return Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    }
    catch {
        # An unreadable record must not be treated as "nothing installed": that
        # would reinstall over files whose ownership we can no longer prove.
        throw "The installed-component record for '$id' is unreadable: $path"
    }
}

function Get-ComponentInstalledBuild([string]$id) {
    $state = Read-ComponentState $id
    if ($null -eq $state) { return [Int64]0 }
    $parsed = [Int64]0
    if (-not [Int64]::TryParse([string]$state.build, [ref]$parsed)) { return [Int64]0 }
    return $parsed
}

# Which OTHER component already owns a path, or '' if nobody does.
function Get-ConflictingOwner([string]$relative, [string]$exceptId) {
    if (-not (Test-Path -LiteralPath $componentStateRoot)) { return '' }
    $needle = $relative.Replace('\', '/').ToLowerInvariant()
    foreach ($file in (Get-ChildItem -LiteralPath $componentStateRoot -Filter '*.json' -ErrorAction SilentlyContinue)) {
        $otherId = [IO.Path]::GetFileNameWithoutExtension($file.Name)
        if ($otherId -ieq $exceptId) { continue }
        $state = Read-ComponentState $otherId
        if ($null -eq $state) { continue }
        foreach ($owned in @($state.files)) {
            if (([string]$owned).Replace('\', '/').ToLowerInvariant() -eq $needle) {
                return $otherId
            }
        }
    }
    return ''
}

if ($ParentProcessId -gt 0) {
    $deadline = [DateTime]::UtcNow.AddSeconds(15)
    while ((Get-Process -Id $ParentProcessId -ErrorAction SilentlyContinue) -and
        [DateTime]::UtcNow -lt $deadline) {
        Start-Sleep -Milliseconds 100
    }
    if (Get-Process -Id $ParentProcessId -ErrorAction SilentlyContinue) {
        Write-UpdaterLog 'The launcher did not exit in time; the update check was skipped.'
        Start-Launcher
        exit 0
    }
}

if (-not (Test-Path -LiteralPath $channelPath -PathType Leaf)) {
    Start-Launcher
    exit 0
}

try {
    $channel = Get-Content -LiteralPath $channelPath -Raw | ConvertFrom-Json
    $manifestSource = [string]$channel.manifestUrl
    if ([string]::IsNullOrWhiteSpace($manifestSource) -or
        $manifestSource -eq 'UPDATE_SOURCE_NOT_CONFIGURED') {
        Write-UpdaterLog 'No update channel is configured; continuing with the installed build.'
        Start-Launcher
        exit 0
    }

    $tempRoot = Join-Path ([IO.Path]::GetTempPath()) `
        ('project-crossroads-update-' + [Guid]::NewGuid().ToString('N'))
    $downloadRoot = Join-Path $tempRoot 'download'
    $extractRoot = Join-Path $tempRoot 'extracted'
    New-Item -ItemType Directory -Force -Path $downloadRoot, $extractRoot | Out-Null

    $manifestPath = Join-Path $downloadRoot 'update-manifest.json'
    Copy-UpdateSource $manifestSource $manifestPath
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json

    # WHICH ENTRY THIS RUN INSTALLS. Without -Component this is the top-level
    # manifest, unchanged, which is what every launcher in the field reads.
    $entry = $manifest
    if ($Component -ne '') {
        $entry = if ($Component -ieq 'platform') {
            $manifest.platform
        }
        elseif ($null -ne $manifest.games) {
            $manifest.games.$Component
        }
        else {
            $null
        }
        if ($null -eq $entry) {
            # A manifest that predates the split has no `games`. Say so plainly
            # rather than failing on a null property later, because the launcher
            # will surface this to a player who pressed Join.
            throw ("The update manifest has no component named '$Component'. " +
                   'It may predate per-game updates, or this game may not ' +
                   'publish a component.')
        }
    }

    $installedBuild = if ($Component -ne '') {
        Get-ComponentInstalledBuild $Component
    } else {
        Read-BuildNumber $installedBuildPath
    }
    $availableBuild = [Int64]$entry.build
    if ($availableBuild -le $installedBuild) {
        $what = if ($Component -ne '') { "Component '$Component'" } else { 'Build' }
        Write-UpdaterLog "$what $installedBuild is current."
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
        # A component check is invoked by the launcher and must not relaunch it.
        if ($Component -eq '') { Start-Launcher }
        exit 0
    }

    # The launcher owns the Join-time prompt, so a component install never puts
    # up its own dialog on top of it.
    $choice = if ($AcceptUpdate -or $Component -ne '') {
        'Yes'
    }
    else {
        [System.Windows.MessageBox]::Show(
            "A Project: Crossroads update is available.`n`nInstalled build: $installedBuild`nAvailable build: $availableBuild`n`nInstall it now?",
            'Project: Crossroads - Update Available',
            'YesNo',
            'Information')
    }
    if ($choice -ne 'Yes') {
        Write-UpdaterLog "Build $availableBuild was declined."
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
        Start-Launcher
        exit 0
    }

    $archiveSource = Resolve-UpdateSource ([string]$entry.packageUrl) $manifestSource
    $archivePath = Join-Path $downloadRoot 'Project-Crossroads-Update.zip'
    Copy-UpdateSource $archiveSource $archivePath
    $actualHash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash
    if ($actualHash -ine [string]$entry.sha256) {
        throw 'The downloaded update failed its SHA-256 integrity check. Nothing was installed.'
    }

    Expand-Archive -LiteralPath $archivePath -DestinationPath $extractRoot -Force
    $payloadRoot = Join-Path $extractRoot 'Project Crossroads Update'
    $payloadManifestPath = Join-Path $payloadRoot 'managed-files.json'
    if (-not (Test-Path -LiteralPath $payloadManifestPath -PathType Leaf)) {
        throw 'The downloaded update does not contain its managed-file manifest.'
    }
    $managed = Get-Content -LiteralPath $payloadManifestPath -Raw | ConvertFrom-Json
    if ([Int64]$managed.build -ne $availableBuild) {
        throw 'The update package build number does not match the published manifest.'
    }

    # THE PACKAGE MUST BE THE COMPONENT WE ASKED FOR. Same shape as the build
    # cross-check above, and for the same reason: a manifest and its payload
    # disagreeing is precisely how the wrong artifact ships. Without this, a
    # `games.kotor1` entry pointing at the fallout3 archive would install it
    # under KotOR's name and record KotOR's ownership over Fallout's files.
    if ($Component -ne '') {
        $declared = [string]$managed.component
        if ($declared -ine $Component) {
            throw ("The downloaded package declares component " +
                   "'$declared' but '$Component' was requested. Nothing was installed.")
        }
    }

    $files = @($managed.files)
    if ($files.Count -eq 0) {
        throw 'The update package contains no managed files.'
    }
    foreach ($fileEntry in $files) {
        $relative = [string]$fileEntry.path
        if (-not (Test-SafeRelativePath $relative)) {
            throw "The update contains an unsafe or protected path: $relative"
        }
        # CONFINEMENT, CLIENT SIDE (D33). The packager enforces the same rule at
        # publish time; both are needed, because the publisher's check cannot
        # protect against a tampered manifest and the client's cannot stop a bad
        # package being published. A game component overwriting the launcher, or
        # another game's files, is the failure this prevents -- and it would be
        # silent, because every file would still pass its own hash check.
        if ($Component -ne '') {
            $owner = Get-ConflictingOwner $relative $Component
            if ($owner -ne '') {
                throw ("Component '$Component' declares a file already owned by " +
                       "'$owner': $relative. Nothing was installed.")
            }
        }
        $sourceFile = Join-Path $payloadRoot $relative
        if (-not (Test-Path -LiteralPath $sourceFile -PathType Leaf)) {
            throw "The update is missing a declared file: $relative"
        }
        $fileHash = (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256).Hash
        if ($fileHash -ine [string]$fileEntry.sha256) {
            throw "The update file failed verification: $relative"
        }
    }

    $blockedProcesses = @(
        Get-Process -Name 'Fallout3', 'fose_loader', 'swkotor',
            'ProjectCrossroadsServer', 'CrossroadsKotorServer',
            'CrossroadsLiveMirror' -ErrorAction SilentlyContinue
    )
    if (-not $AcceptUpdate -and $blockedProcesses.Count -gt 0) {
        throw 'Close supported games and Crossroads servers, then reopen the launcher to install this update.'
    }

    $transactionRoot = Join-Path $root '.crossroads-update-transaction'
    $backupRoot = Join-Path $transactionRoot 'backup'
    if (Test-Path -LiteralPath $transactionRoot) {
        Remove-Item -LiteralPath $transactionRoot -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
    $installed = New-Object System.Collections.Generic.List[string]
    try {
        # $fileEntry, not $entry: $entry is now the manifest entry being
        # installed, and shadowing it here would leave it holding a file record
        # after the loop.
        foreach ($fileEntry in $files) {
            $relative = ([string]$fileEntry.path).Replace('/', '\')
            $sourceFile = Join-Path $payloadRoot $relative
            $targetFile = Join-Path $root $relative
            $backupFile = Join-Path $backupRoot $relative
            if (Test-Path -LiteralPath $targetFile -PathType Leaf) {
                New-Item -ItemType Directory -Force `
                    -Path (Split-Path -Parent $backupFile) | Out-Null
                Copy-Item -LiteralPath $targetFile -Destination $backupFile -Force
            }
            New-Item -ItemType Directory -Force `
                -Path (Split-Path -Parent $targetFile) | Out-Null
            Copy-Item -LiteralPath $sourceFile -Destination $targetFile -Force
            $installed.Add($relative)
        }
        if ($Component -ne '') {
            # Written only after every file is in place, so an interrupted
            # install leaves the OLD record standing. A record claiming a build
            # that is only half present would make the Join gate wave through a
            # component that is not actually there.
            New-Item -ItemType Directory -Force -Path $componentStateRoot | Out-Null
            $record = [ordered]@{
                component = $Component
                build = $availableBuild
                files = @($files | ForEach-Object { [string]$_.path })
            }
            [IO.File]::WriteAllText(
                (Get-ComponentStatePath $Component),
                ($record | ConvertTo-Json -Depth 5),
                [Text.UTF8Encoding]::new($false))
            Write-UpdaterLog ("Component '$Component' updated from " +
                "$installedBuild to $availableBuild ($($files.Count) files).")
        }
        else {
            [IO.File]::WriteAllText(
                $installedBuildPath,
                $availableBuild.ToString(),
                [Text.UTF8Encoding]::new($false))
            Write-UpdaterLog "Updated successfully from build $installedBuild to $availableBuild."
        }
        Remove-Item -LiteralPath $transactionRoot -Recurse -Force
    }
    catch {
        foreach ($relative in $installed) {
            $targetFile = Join-Path $root $relative
            $backupFile = Join-Path $backupRoot $relative
            if (Test-Path -LiteralPath $backupFile -PathType Leaf) {
                Copy-Item -LiteralPath $backupFile -Destination $targetFile -Force
            }
            elseif (Test-Path -LiteralPath $targetFile -PathType Leaf) {
                Remove-Item -LiteralPath $targetFile -Force
            }
        }
        throw "The update could not be installed and was rolled back. $($_.Exception.Message)"
    }

    Remove-Item -LiteralPath $tempRoot -Recurse -Force
    if (-not $AcceptUpdate -and $Component -eq '') {
        [System.Windows.MessageBox]::Show(
            "Project: Crossroads was updated to build $availableBuild.",
            'Project: Crossroads - Update Complete',
            'OK',
            'Information') | Out-Null
    }
}
catch {
    Write-UpdaterLog "Update check failed: $($_.Exception.Message)"
    # A component install is a GATE: the launcher is waiting on the exit code to
    # decide whether the player may join. It must fail loudly rather than show a
    # dialog and exit 0, which the launcher would read as success and let a
    # stale adapter connect -- the silent-mismatch class this whole change
    # exists to remove.
    if ($AcceptUpdate -or $Component -ne '') {
        throw
    }
    Show-UpdateError (
        "Crossroads could not complete its update check.`n`n$($_.Exception.Message)`n`nThe installed build was left unchanged."
    )
}

# A component install never relaunches the launcher: it is already running and
# waiting for this to finish.
if ($Component -eq '') {
    Start-Launcher
}
