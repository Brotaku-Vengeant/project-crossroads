# Advertises a player's own co-op server in the Crossroads browser.
#
# ---------------------------------------------------------------------------
# WHY THIS IS A SCRIPT AND NOT PART OF THE LAUNCHER
# ---------------------------------------------------------------------------
#
# The launcher deliberately has no HTTP client, no JSON parser and no OAuth
# surface -- D39 states that plainly and says it "is not being walked back".
# Sign-In-To-Crossroads.ps1 exists for the same reason. So the launcher starts
# this and this talks to the service.
#
# ---------------------------------------------------------------------------
# THE CONTRACT IS NOT INVENTED HERE
# ---------------------------------------------------------------------------
#
# Every field, the cadence and the expiry come from
# `docs/launcher/ACCOUNTS_AND_REGISTRATION.md`, "Registering a server": a
# heartbeat every 30 seconds carrying contract, accountToken, game, name, port,
# capacity and password; no heartbeat for 90 seconds and the row disappears.
# The service enforces its own side -- `HEARTBEAT_MIN_INTERVAL_SECONDS = 10`
# refuses anything faster, and `HEARTBEAT_EXPIRY_SECONDS = 90` is the deadline
# this cadence sits comfortably inside.
#
# THERE IS NO `host` FIELD AND ADDING ONE WOULD BE A DEFECT. The service takes
# the address from the packet source. The document's words: it "is what lets a
# host register somebody else's machine, and it turns the directory into a way
# to point every launcher on the network at a third party."
#
# THE SERVICE DECIDES WHAT KIND OF SERVER THIS IS. A registration cannot claim
# `official` or `community-public` -- self-registered rows are `coop`, by
# construction, in the service. This script could not advertise a public server
# if it tried, which is the property that keeps public servers the owner's.
#
# ---------------------------------------------------------------------------
# IT STOPS ON ITS OWN
# ---------------------------------------------------------------------------
#
# The launcher starts this beside the server and has no "stop advertising"
# button. So this watches the server PROCESS and exits when it is gone -- and
# because the row expires 90 seconds after the last heartbeat, a crashed host,
# a closed console or a killed launcher all stop being advertised without
# anybody tidying up. That is the documented behaviour: "a crashed host stops
# being advertised on its own."

[CmdletBinding()]
param(
    # The catalog id, e.g. kotor1. Travels in the heartbeat as `game`.
    [Parameter(Mandatory = $true)][string]$Game,

    # The UDP port the server is bound to.
    [Parameter(Mandatory = $true)][int]$Port,

    # What the browser will call this row.
    [Parameter(Mandatory = $true)][string]$Name,

    # What the row says it holds. The launcher passes the manifest's own
    # player limit; the service clamps it to the game's declared maximum.
    [int]$Capacity = 0,

    # The process this advertisement belongs to. When it is gone, so is this.
    [Parameter(Mandatory = $true)][string]$ServerProcessName,

    # Where crossroads-network.ini lives. Defaults to beside this script, which
    # is where a deployed install puts both.
    [string]$ConfigPath = '',

    # Seconds between heartbeats. The default is the documented 30; the service
    # refuses anything under 10 and the row expires at 90.
    [int]$IntervalSeconds = 30,

    # Stop after this many heartbeats. For gates only -- 0 means run until the
    # server exits.
    [int]$MaxHeartbeats = 0,

    # The host protected this server with a password (2026-10-28). A YES/NO,
    # NEVER THE PASSWORD: the browser shows a PASSWORD badge and asks a joining
    # player for it, and the relay checks what they prove. Nothing secret is in
    # this script or its heartbeat.
    [switch]$Password,

    # How long this window stays open after the script gives up WITHOUT ever
    # listing the server, so the reason can be read. Gates pass 0.
    [int]$HoldWindowSeconds = 60
)

$ErrorActionPreference = 'Stop'

# THE PROCESS NAME ARRIVES WITH ".exe" AND Get-Process WANTS IT WITHOUT
# (2026-10-28). The launcher passes the catalog's `processName`, which is the
# file name -- "CrossroadsKotorServer.exe" -- and `Get-Process -Name` matches
# only the bare name. So the "is the server still running?" check below failed
# on the very first pass, the script said the server had stopped and quit
# before its first heartbeat, and its window closed with it. NO CO-OP SERVER
# STARTED FROM THE LAUNCHER WAS EVER LISTED, on any PC; the gate passed because
# it handed this script 'powershell', never a name ending in .exe. Both forms
# are accepted now, and the gate passes the launcher's form.
if ($ServerProcessName -match '\.exe$') {
    $ServerProcessName = $ServerProcessName.Substring(0, $ServerProcessName.Length - 4)
}

# EVERY WAY OUT BEFORE THE FIRST LISTING SAYS WHY AND STAYS ON SCREEN. This
# runs in its own console window, which closes the moment the script ends --
# so a reason printed on the way out was a reason nobody could read, and an
# unlisted server looked exactly like a slow browser.
function Exit-Unlisted([int]$Code) {
    if ($HoldWindowSeconds -gt 0) {
        Write-Host ''
        Write-Host ("This server is NOT listed in the browser. This window closes " +
                    "in $HoldWindowSeconds seconds.") -ForegroundColor Yellow
        Start-Sleep -Seconds $HoldWindowSeconds
    }
    exit $Code
}

if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $ConfigPath = Join-Path $PSScriptRoot 'crossroads-network.ini'
}

# A CADENCE OUTSIDE THE SERVICE'S WINDOW IS REFUSED HERE RATHER THAN BY A 429.
# Below 10 seconds every heartbeat after the first is rejected and the row
# expires anyway; above 90 the row is gone between beats. Either way the
# server looks offline while running, which is the failure shape this project
# keeps paying for, so it is caught at the start where it can be read.
if ($IntervalSeconds -lt 10 -or $IntervalSeconds -gt 60) {
    Write-Host ("A heartbeat interval of $IntervalSeconds seconds is outside " +
                'the service window: faster than 10 is refused, and slower ' +
                'than 90 lets the row expire between beats.') -ForegroundColor Red
    exit 2
}

function Read-IniValue {
    param([string]$Section, [string]$Key)
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { return '' }
    $current = ''
    foreach ($line in (Get-Content -LiteralPath $ConfigPath)) {
        $text = $line.Trim()
        if ($text -match '^\[(?<name>[^\]]+)\]$') {
            $current = $Matches['name']
            continue
        }
        if ($current -ne $Section) { continue }
        if ($text -match "^$([regex]::Escape($Key))=(?<value>.*)$") {
            return $Matches['value'].Trim()
        }
    }
    return ''
}

# The same file and the same key Join-Crossroads-KotOR.ps1 reads, reached the
# same way: the per-user profile, never beside the executable.
function Get-CrossroadsAccountToken {
    $accountPath = Join-Path $env:LOCALAPPDATA 'Project Crossroads\account.ini'
    if (-not (Test-Path -LiteralPath $accountPath -PathType Leaf)) { return '' }
    foreach ($line in (Get-Content -LiteralPath $accountPath)) {
        if ($line.Trim() -match '^token=(.*)$') { return $Matches[1].Trim() }
    }
    return ''
}

$serviceUrl = Read-IniValue 'accounts' 'service_url'
if ([string]::IsNullOrWhiteSpace($serviceUrl)) {
    # NOT AN ERROR, and this is the same rule the sign-in flow follows: an
    # install with no [accounts] section is simply not configured for the
    # service. Advertising is the part that does not happen; the server itself
    # runs perfectly well unlisted, and friends can still be given its address.
    Write-Host 'No account service is configured, so this server will not be listed.'
    Exit-Unlisted 0
}

$token = Get-CrossroadsAccountToken
if ([string]::IsNullOrWhiteSpace($token)) {
    Write-Host ('Not signed in, so this server will not be listed. Sign in ' +
                'from the launcher and start the server again.')
    Exit-Unlisted 3
}

try {
    [Net.ServicePointManager]::SecurityProtocol =
        [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11
}
catch { }

$endpoint = $serviceUrl.TrimEnd('/') + '/register'
$householdEndpoint = $serviceUrl.TrimEnd('/') + '/register/household'

# ---------------------------------------------------------------------------
# ONE SERVER, REACHABLE AT HOME AND FROM OUTSIDE (2026-10-28)
# ---------------------------------------------------------------------------
#
# Players outside the host's house connect to the host's PUBLIC address, which
# the service takes from the request (never from this script) -- and the host
# forwards the UDP port on their router, the ordinary step for hosting. Players
# INSIDE the house often cannot use that address, because many routers will
# not loop a connection to their own public address back in. So this also
# sends the PC's home-network address, which the service hands only to
# requesters in the same household.
#
# THE HOME-NETWORK ADDRESS is the private IPv4 address of the adapter that
# carries this PC's default route -- the one its internet traffic leaves by.
# Lowest route metric first, and private ranges only, so a VPN adapter (Radmin
# and its kind use addresses outside the private ranges) is passed over rather
# than offered to the household.
function Get-HomeNetworkAddress {
    try {
        $routes = @(Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction Stop |
            Sort-Object { $_.RouteMetric + $_.InterfaceMetric })
        foreach ($route in $routes) {
            $addresses = @(Get-NetIPAddress -InterfaceIndex $route.InterfaceIndex `
                -AddressFamily IPv4 -ErrorAction SilentlyContinue)
            foreach ($entry in $addresses) {
                $text = [string]$entry.IPAddress
                if ($text -match '^10\.' -or
                    $text -match '^192\.168\.' -or
                    $text -match '^172\.(1[6-9]|2[0-9]|3[01])\.') {
                    return $text
                }
            }
        }
    }
    catch { }
    return ''
}

# THE HEARTBEAT GOES OVER IPv4, BY FORCE. The address the service records is
# the one players connect to, and relays and port forwards are IPv4 -- but a PC
# with IPv6 reaches the service over IPv6 by default (measured on the owner's PC
# 2026-10-28), and the service refuses a listing that arrives that way rather
# than store an address nobody can join. Windows ships curl.exe, which can be
# told -4; Invoke-RestMethod cannot.
#
# THE BODY GOES IN A FILE, NOT ON THE COMMAND LINE AND NOT DOWN A PIPE. Not the
# command line, because it carries the account token and a command line is
# visible to every other process on the machine. Not a pipe, because Windows
# PowerShell puts a UTF-8 byte-order mark in front of text piped to a program
# whenever the console is UTF-8 -- whatever $OutputEncoding says (measured
# 2026-10-28: the service received "﻿{...}" and refused it as not JSON).
# The file is written without a mark, in this user's own temp folder, and
# removed the moment curl has read it.
$curl = Join-Path $env:SystemRoot 'System32\curl.exe'
function Send-HeartbeatOverIPv4 {
    param([string]$Json)
    $bodyFile = Join-Path ([IO.Path]::GetTempPath()) ('crs-heartbeat-' + [Guid]::NewGuid().ToString('N') + '.json')
    try {
        [IO.File]::WriteAllText($bodyFile, $Json, [Text.UTF8Encoding]::new($false))
        $output = & $curl -4 -s -S --max-time 8 -X POST `
            -H 'Content-Type: application/json' --data-binary "@$bodyFile" `
            -w "`n%{http_code}" $endpoint 2>&1
        $code = $LASTEXITCODE
    }
    finally {
        [IO.File]::Delete($bodyFile)
    }
    $lines = @($output | ForEach-Object { [string]$_ })
    $status = if ($lines.Count -gt 0) { $lines[-1].Trim() } else { '' }
    return [pscustomobject]@{
        CurlExit = $code
        Status   = $status
        Body     = (($lines | Select-Object -SkipLast 1) -join "`n")
    }
}

$homeAddress = Get-HomeNetworkAddress
$body = @{
    contract     = 'crossroads-registration-v1'
    accountToken = $token
    game         = $Game
    name         = $Name
    port         = $Port
    password     = [bool]$Password
}
if ($Capacity -gt 0) { $body['capacity'] = $Capacity }
if ($homeAddress) { $body['lanHost'] = $homeAddress }
$householdBody = @{
    contract     = 'crossroads-registration-v1'
    accountToken = $token
    game         = $Game
    port         = $Port
}

Write-Host ("Advertising '$Name' on port $Port every $IntervalSeconds seconds.")
Write-Host 'It disappears from the browser 90 seconds after this stops.'
# THE ADDRESSES ARE NOT PRINTED. This console is the host's and may well be
# screenshotted; what they need to know is what to do, not the numbers.
if ($homeAddress) {
    Write-Host 'Players on your own network will connect to this PC directly.'
}
else {
    Write-Host ('No home-network address was found for this PC, so players on ' +
                'your own network will use your public address like everyone ' +
                'else. Some routers do not allow that.') -ForegroundColor Yellow
}
Write-Host ("Players outside your network need UDP port $Port forwarded to this " +
            'PC on your router.')
if (-not (Test-Path -LiteralPath $curl -PathType Leaf)) {
    Write-Host ('This copy of Windows has no curl.exe, so the listing cannot be ' +
                'forced over IPv4. If your connection uses IPv6 the service will ' +
                'refuse it, and the server stays unlisted.') -ForegroundColor Yellow
}
$householdSaid = $false

$beats = 0
$consecutiveFailures = 0
while ($true) {
    if (-not (Get-Process -Name $ServerProcessName -ErrorAction SilentlyContinue)) {
        Write-Host 'The co-op server has stopped, so advertising stops too.'
        if ($beats -eq 0) { Exit-Unlisted 4 }
        break
    }

    try {
        $json = $body | ConvertTo-Json -Compress
        if (Test-Path -LiteralPath $curl -PathType Leaf) {
            $sent = Send-HeartbeatOverIPv4 $json
            if ($sent.CurlExit -ne 0) {
                # curl's own exit code names the failure: 6 cannot resolve, 7
                # cannot connect, 28 timed out. With -4 the usual cause of the
                # first two is a PC with no IPv4 route to the internet at all.
                throw ("could not reach the Crossroads service over IPv4 " +
                       "(curl exit $($sent.CurlExit)). A co-op server is " +
                       'joined over IPv4, so this PC needs an IPv4 internet ' +
                       'connection to be listed.')
            }
            if ($sent.Status -ne '200') {
                $why = ''
                try { $why = [string](($sent.Body | ConvertFrom-Json).error) } catch { }
                throw ("the service answered $($sent.Status)" +
                       $(if ($why) { ": $why" } else { '' }))
            }
        }
        else {
            $response = Invoke-RestMethod -Uri $endpoint -Method Post `
                -ContentType 'application/json' -TimeoutSec 8 -UseBasicParsing `
                -Body $json
        }
        if ($beats -eq 0) {
            Write-Host 'Listed. Friends can now find this server in the browser.'
        }
        $consecutiveFailures = 0

        # THE SECOND CALL: over this PC's NORMAL route, so that when it is IPv6
        # the service learns the household's IPv6 network and can recognise
        # the other devices in this house (see the service's
        # register_household). Its failure costs only the LAN shortcut, so it
        # is said once and never stops the heartbeat.
        try {
            $household = Invoke-RestMethod -Uri $householdEndpoint -Method Post `
                -ContentType 'application/json' -TimeoutSec 8 -UseBasicParsing `
                -Body ($householdBody | ConvertTo-Json -Compress)
            if (-not $householdSaid -and $household.household6) {
                $householdSaid = $true
                Write-Host ('This network also uses IPv6; devices on it will ' +
                            'still be recognised as part of your household.') `
                    -ForegroundColor DarkGray
            }
        }
        catch {
            if (-not $householdSaid) {
                $householdSaid = $true
                Write-Host ('Could not tell the service which IPv6 network this ' +
                            'house is on: ' + $_.Exception.Message +
                            ' Players on your own network may connect through ' +
                            'your public address instead.') -ForegroundColor DarkGray
            }
        }
    }
    catch {
        # THE MESSAGE, NEVER THE BODY. The body carries the account token, and
        # this console belongs to a player who may well screenshot it. Same
        # rule the join script states where it posts.
        $consecutiveFailures++
        $reason = $_.Exception.Message
        # A refusal is worth saying ONCE rather than every 30 seconds. The
        # common ones are worth naming: a server limit reached means this
        # account already has one listed, which is the rule and not a fault.
        if ($consecutiveFailures -eq 1) {
            Write-Host ("Could not list this server: $reason") -ForegroundColor Yellow
            Write-Host ('The server is still running and still joinable by ' +
                        'anyone who has its address.') -ForegroundColor DarkGray
        }
    }

    $beats++
    if ($MaxHeartbeats -gt 0 -and $beats -ge $MaxHeartbeats) { break }
    Start-Sleep -Seconds $IntervalSeconds
}

exit 0
