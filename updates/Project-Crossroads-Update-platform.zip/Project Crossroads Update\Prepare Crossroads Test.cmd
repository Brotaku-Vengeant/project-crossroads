@echo off
setlocal
title Project: Crossroads Tester Setup
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Prepare-Crossroads-Tester.ps1"
if errorlevel 1 (
  echo.
  echo Setup did not finish. Read the message above, then try again.
  pause
)
exit /b %ERRORLEVEL%
