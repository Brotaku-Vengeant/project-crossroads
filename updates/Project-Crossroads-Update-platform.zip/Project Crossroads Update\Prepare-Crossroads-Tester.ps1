[CmdletBinding()]
param(
    [string]$GamePath
)

$ErrorActionPreference = 'Stop'
$packageRoot = $PSScriptRoot
$defaultSteamRoot = 'C:\Program Files (x86)\Steam\steamapps\common\Fallout 3 goty'
$registryPath = 'HKLM:\SOFTWARE\WOW6432Node\Bethesda Softworks\Fallout3'
Add-Type -AssemblyName PresentationFramework

function Stop-WithMessage([string]$message) {
    [System.Windows.MessageBox]::Show(
        $message,
        'Project: Crossroads - Tester Setup',
        'OK',
        'Error') | Out-Null
    throw $message
}

function Normalize-GameRoot([string]$path) {
    if (-not $path) {
        return $null
    }
    $resolved = [IO.Path]::GetFullPath($path).TrimEnd('\')
    if ((Split-Path -Leaf $resolved) -ieq 'Data') {
        $resolved = Split-Path -Parent $resolved
    }
    return $resolved
}

function Test-GameRoot([string]$path) {
    $root = Normalize-GameRoot $path
    return $root -and
        (Test-Path -LiteralPath (Join-Path $root 'Fallout3.exe') -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $root 'Data') -PathType Container)
}

function Select-GameRoot([string]$initialPath) {
    Add-Type -AssemblyName System.Windows.Forms
    $picker = New-Object System.Windows.Forms.FolderBrowserDialog
    $picker.Description = 'Select the Fallout 3 Game of the Year folder containing Fallout3.exe and the Data folder.'
    $picker.ShowNewFolderButton = $false
    if ($initialPath -and (Test-Path -LiteralPath $initialPath -PathType Container)) {
        $picker.SelectedPath = $initialPath
    }
    if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }
    return Normalize-GameRoot $picker.SelectedPath
}

$candidates = New-Object System.Collections.Generic.List[string]
if ($GamePath) {
    $candidates.Add((Normalize-GameRoot $GamePath))
}

$configuredPath = Join-Path $packageRoot 'runtime\Fallout3\crossroads-steam-data-path.txt'
if (Test-Path -LiteralPath $configuredPath -PathType Leaf) {
    $configuredData = (Get-Content -LiteralPath $configuredPath -Raw).Trim()
    if ($configuredData) {
        $candidates.Add((Normalize-GameRoot $configuredData))
    }
}

if (Test-Path -LiteralPath $registryPath) {
    $registered = (Get-ItemProperty -LiteralPath $registryPath `
        -Name 'Installed Path' -ErrorAction SilentlyContinue).'Installed Path'
    if ($registered) {
        $candidates.Add((Normalize-GameRoot $registered))
    }
}
$candidates.Add($defaultSteamRoot)

$steamPath = (Get-ItemProperty -LiteralPath 'HKCU:\Software\Valve\Steam' `
    -Name 'SteamPath' -ErrorAction SilentlyContinue).SteamPath
if ($steamPath) {
    $libraryFile = Join-Path $steamPath 'steamapps\libraryfolders.vdf'
    if (Test-Path -LiteralPath $libraryFile -PathType Leaf) {
        $libraryText = Get-Content -LiteralPath $libraryFile -Raw
        foreach ($match in [regex]::Matches(
            $libraryText, '"path"\s+"([^"]+)"')) {
            $library = $match.Groups[1].Value -replace '\\\\', '\'
            $candidates.Add((Join-Path $library `
                'steamapps\common\Fallout 3 goty'))
        }
    }
}

$steamRoot = $null
foreach ($candidate in $candidates) {
    if (Test-GameRoot $candidate) {
        $steamRoot = Normalize-GameRoot $candidate
        break
    }
}

if ($GamePath) {
    if (-not (Test-GameRoot $GamePath)) {
        Stop-WithMessage "The selected folder does not contain Fallout3.exe and a Data folder:`n$GamePath"
    }
    $steamRoot = Normalize-GameRoot $GamePath
}
elseif ($steamRoot) {
    $choice = [System.Windows.MessageBox]::Show(
        "Crossroads found Fallout 3 here:`n`n$steamRoot`n`nUse this folder? Choose No to browse for a different installation.",
        'Project: Crossroads - Select Fallout 3',
        'YesNoCancel',
        'Question')
    if ($choice -eq 'Cancel') {
        exit 1
    }
    if ($choice -eq 'No') {
        $steamRoot = Select-GameRoot $steamRoot
    }
}
else {
    $steamRoot = Select-GameRoot $defaultSteamRoot
}

if (-not $steamRoot -or -not (Test-GameRoot $steamRoot)) {
    Stop-WithMessage 'Select the Fallout 3 Game of the Year folder containing Fallout3.exe and the Data folder.'
}

$steamExe = Join-Path $steamRoot 'Fallout3.exe'
$steamData = Join-Path $steamRoot 'Data'
$foseDll = Join-Path $steamRoot 'fose_1_7.dll'
if (-not (Test-Path -LiteralPath $steamExe -PathType Leaf) -or
    -not (Test-Path -LiteralPath $steamData -PathType Container)) {
    Stop-WithMessage "Fallout 3 was not found at:`n$steamRoot`n`nInstall the Steam Game of the Year Edition first."
}
if (-not (Test-Path -LiteralPath $foseDll -PathType Leaf)) {
    Stop-WithMessage "FOSE's fose_1_7.dll was not found beside Fallout3.exe.`n`nThis test requires FOSE 1.2 beta 2. Install it into your Fallout 3 folder, then run this setup again."
}

$version = (Get-Item -LiteralPath $steamExe).VersionInfo.FileVersion
if ($version -notlike '1.7.0.3*') {
    Stop-WithMessage "This Fallout3.exe is version $version.`n`nThe current Crossroads test requires the exact Anniversary Patcher 1.7.0.3 build. Additional or arbitrary 4 GB/LAA-patched executables are not supported. Restore the required build, then run this setup again."
}

$runtimeRoot = Join-Path $packageRoot 'runtime\Fallout3'
New-Item -ItemType Directory -Force -Path $runtimeRoot | Out-Null

$supportFiles = @(
    'Fallout3.exe', 'atimgpud.dll', 'binkw32.dll', 'Fallout_default.ini',
    'high.ini', 'libvorbis.dll', 'libvorbisfile.dll', 'low.ini',
    'MainTitle.wav', 'medium.ini', 'steam_api.dll', 'VeryHigh.ini',
    'fose_loader.exe', 'fose_1_7.dll'
)
foreach ($name in $supportFiles) {
    $source = Join-Path $steamRoot $name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        Stop-WithMessage "Required Fallout/FOSE file is missing:`n$source"
    }
    Copy-Item -LiteralPath $source `
        -Destination (Join-Path $runtimeRoot $name) -Force
}

$runtimeData = Join-Path $runtimeRoot 'Data'
if (Test-Path -LiteralPath $runtimeData) {
    $item = Get-Item -LiteralPath $runtimeData -Force
    $target = @($item.Target)[0]
    if ($item.LinkType -ne 'Junction') {
        Stop-WithMessage "Crossroads found an unexpected runtime Data folder and refused to overwrite it:`n$runtimeData"
    }
    if ([IO.Path]::GetFullPath($target) -ne
        [IO.Path]::GetFullPath($steamData)) {
        Remove-Item -LiteralPath $runtimeData -Force
        New-Item -ItemType Junction -Path $runtimeData `
            -Target $steamData | Out-Null
    }
}
else {
    New-Item -ItemType Junction -Path $runtimeData -Target $steamData | Out-Null
}

[IO.File]::WriteAllText(
    (Join-Path $runtimeRoot 'crossroads-steam-data-path.txt'),
    [IO.Path]::GetFullPath($steamData),
    [Text.UTF8Encoding]::new($false))

Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show(
    'Setup finished. Start ProjectCrossroadsLauncher.exe and run Network Self-Test before hosting or joining.',
    'Project: Crossroads - Tester Setup',
    'OK',
    'Information') | Out-Null
