# Fetches the Crossroads server directory, validates it, and normalises it into
# the flat cache the launcher reads.
#
# WHY POWERSHELL DOES THIS AND THE LAUNCHER DOES NOT.
#
# The directory is the first Crossroads surface that faces strangers rather than
# testers: with self-registration, anyone can put bytes in it. Parsing those
# bytes in the launcher would mean a C++ JSON parser handling attacker-controlled
# input on players' machines, which is the single largest avoidable attack
# surface in the design. So the hostile parse happens here, in a memory-safe
# language, off the critical path -- and the launcher only ever reads a bounded,
# validated, local file that its own tool wrote, using the INI reader it already
# uses for its own configuration.
#
# The launcher has no HTTP client and this does not give it one.
#
# SEPARATE FROM Update-Crossroads.ps1 DELIBERATELY. That script installs
# executables and is the highest-consequence component in the project. A
# directory fetch has no business being able to break it.
#
# WHAT THIS REFUSES TO CARRY. Liveness. The document supplies discovery only --
# a name, a game, an address, a capacity. It never supplies players, latency or
# online state, and this script drops those fields if they appear. The launcher
# measures liveness itself with the game's own status probe, which is what makes
# a fabricated population impossible rather than merely discouraged.
#
# Exit codes: 0 wrote a cache, 1 could not (an existing cache is left alone).

[CmdletBinding()]
param(
    # Overrides the configured source. Accepts an https:// URL or a local path,
    # which is what the tests use.
    [string]$Source = '',

    [string]$OutputPath = '',

    [ValidateRange(1, 4096)]
    [int]$MaximumServers = 256,

    # Refuse to fetch again while the existing cache is younger than this.
    #
    # docs\launcher\SERVER_DIRECTORY.md has always stated this bound; nothing
    # enforced it, which did not matter while the only caller was a human
    # running the script by hand. The launcher now triggers a fetch on a timer,
    # so an install left open all day is a client that talks to the service on
    # a schedule -- and the floor has to live HERE, in the thing that makes the
    # request, not only in the thing that asks for it.
    [ValidateRange(0, 86400)]
    [int]$MinimumIntervalSeconds = 30,

    # Fetch regardless of how fresh the cache is. For a person who just changed
    # the directory and wants to see it, and for the validation tests, which are
    # about what the fetcher ACCEPTS rather than how often it asks.
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $root 'directory-cache.ini'
}
# The log lives beside the CACHE, not beside this script.
#
# One rule, correct in both places it runs: in a deployed install the cache is
# beside the script, so the log is too; under test the cache is in a temporary
# directory, so the log goes there instead of into the repository. The first
# version logged beside the script unconditionally and every test run left a
# runtime log in tracked source, which the pre-commit dry run caught.
$logPath = Join-Path (Split-Path -Parent $OutputPath) 'directory-log.txt'

function Write-DirectoryLog([string]$message) {
    $line = '{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $message
    try { Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8 } catch { }
}

function Read-IniValue([string]$path, [string]$section, [string]$key) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return '' }
    $current = ''
    foreach ($line in (Get-Content -LiteralPath $path)) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') { $current = $Matches[1]; continue }
        if ($current -eq $section -and
            $trimmed -match ('^' + [regex]::Escape($key) + '\s*=(.*)$')) {
            return $Matches[1].Trim()
        }
    }
    return ''
}

if ([string]::IsNullOrWhiteSpace($Source)) {
    foreach ($file in @('crossroads-network.ini', 'crossroads-launcher.ini')) {
        $value = Read-IniValue (Join-Path $root $file) 'directory' 'url'
        if (-not [string]::IsNullOrWhiteSpace($value)) { $Source = $value }
    }
}
if ([string]::IsNullOrWhiteSpace($Source)) {
    # Not an error. No directory configured means the launcher shows only each
    # game's managed server, which is exactly what it does today.
    Write-DirectoryLog 'No directory url is configured; nothing was fetched.'
    exit 0
}

# THE RATE LIMIT, checked before anything reaches the network.
#
# Exit 0, not 1: nothing failed. The cache on disk is current and the caller
# already has what it asked for, so treating this as an error would make an
# ordinary refresh look like an outage in the launcher's own labelling.
if (-not $Force -and $MinimumIntervalSeconds -gt 0 -and
    (Test-Path -LiteralPath $OutputPath -PathType Leaf)) {
    $age = ([DateTime]::UtcNow - ([IO.File]::GetLastWriteTimeUtc($OutputPath)))
    if ($age.TotalSeconds -lt $MinimumIntervalSeconds) {
        Write-DirectoryLog ('Cache is ' + [int]$age.TotalSeconds +
                            's old; skipping fetch (minimum interval ' +
                            $MinimumIntervalSeconds + 's).')
        exit 0
    }
}

# ---- fetch -------------------------------------------------------------------
$raw = $null
try {
    $uri = $null
    if ([Uri]::TryCreate($Source, [UriKind]::Absolute, [ref]$uri) -and
        $uri.Scheme -in @('http', 'https')) {
        if ($uri.Scheme -ne 'https') {
            throw 'The directory source must use HTTPS.'
        }
        $raw = (Invoke-WebRequest -UseBasicParsing -Uri $uri.AbsoluteUri `
            -TimeoutSec 15).Content
    }
    else {
        $raw = Get-Content -LiteralPath $Source -Raw
    }
}
catch {
    # AN UNREACHABLE DIRECTORY MUST NOT DESTROY THE LAST GOOD ONE. The launcher
    # labels a stale cache; it cannot label a cache that is no longer there.
    Write-DirectoryLog "Directory fetch failed, existing cache left in place: $($_.Exception.Message)"
    exit 1
}

if ($null -eq $raw -or $raw.Length -eq 0) {
    Write-DirectoryLog 'Directory source returned nothing; existing cache left in place.'
    exit 1
}
# A directory that will not fit in memory is not a directory.
if ($raw.Length -gt 2097152) {
    Write-DirectoryLog "Directory document is too large ($($raw.Length) bytes); rejected."
    exit 1
}

$document = $null
try { $document = $raw | ConvertFrom-Json }
catch {
    Write-DirectoryLog 'Directory document is not valid JSON; existing cache left in place.'
    exit 1
}

if ([string]$document.contract -ne 'crossroads-directory-v1') {
    # Never partially interpret an unknown version.
    Write-DirectoryLog ("Unknown directory contract '$($document.contract)'; " +
                        'refusing the whole document.')
    exit 1
}

# ---- validate ----------------------------------------------------------------
#
# Every row is checked, and a row that fails any check is DROPPED rather than
# repaired. Repairing attacker-supplied data means guessing what it meant.

# Control characters are the injection vector that matters here: the cache is a
# flat INI, and a name carrying CR/LF could otherwise close its own row and open
# another, inventing a server at an address of the attacker's choosing -- which
# the launcher would then probe and offer a Join for.
#
# TWO LAYERS, DELIBERATELY.
#
# A row containing any control character is REJECTED outright, because this
# script's rule everywhere else is that a bad row is dropped rather than
# repaired: repairing attacker-supplied data means guessing what it meant.
#
# And the text is stripped anyway before it is written, so a bug in the check
# above still cannot put a newline in the cache. The first version relied only
# on stripping, and the injected row happened to be dropped for exceeding the
# name length limit -- correct by luck, which is not a property worth shipping.
function Test-NoControlCharacters([string]$value) {
    if ($null -eq $value) { return $true }
    return -not ($value -match '[\p{Cc}\p{Cf}]')
}

function Remove-ControlCharacters([string]$value) {
    if ($null -eq $value) { return '' }
    return ($value -replace '[\p{Cc}\p{Cf}]', '')
}

function Test-Token([string]$value, [int]$maximumLength) {
    return ($value -cmatch '^[a-z0-9-]+$') -and ($value.Length -le $maximumLength)
}

# Hostnames and IPv4/IPv6 literals only. This is written into a file the
# launcher hands to GetAddrInfoW, so anything outside this set has no business
# reaching it.
function Test-Host([string]$value) {
    return ($value.Length -ge 1) -and ($value.Length -le 253) -and
        ($value -match '^[A-Za-z0-9\.\-:%_]+$')
}

$rows = @()
$dropped = 0
$sourceRows = @()
if ($null -ne $document.servers) { $sourceRows = @($document.servers) }

foreach ($server in $sourceRows) {
    if ($rows.Count -ge $MaximumServers) {
        $dropped += 1
        continue
    }

    # Checked BEFORE stripping, on the raw values, so a row that tried to carry
    # a control character is refused rather than quietly cleaned up.
    $rawText = @(
        [string]$server.id, [string]$server.game, [string]$server.name,
        [string]$server.classification, [string]$server.host,
        [string]$server.region, [string]$server.notes, [string]$server.owner
    )
    $clean = $true
    foreach ($value in $rawText) {
        if (-not (Test-NoControlCharacters $value)) { $clean = $false; break }
    }
    if (-not $clean) { $dropped += 1; continue }

    $id = Remove-ControlCharacters ([string]$server.id)
    $game = Remove-ControlCharacters ([string]$server.game)
    $name = (Remove-ControlCharacters ([string]$server.name)).Trim()
    $classification = Remove-ControlCharacters ([string]$server.classification)
    $serverHost = Remove-ControlCharacters ([string]$server.host)
    $region = (Remove-ControlCharacters ([string]$server.region)).Trim()
    $notes = (Remove-ControlCharacters ([string]$server.notes)).Trim()
    $owner = (Remove-ControlCharacters ([string]$server.owner)).Trim()

    $port = 0
    $capacity = 0
    [void][int]::TryParse([string]$server.port, [ref]$port)
    [void][int]::TryParse([string]$server.capacity, [ref]$capacity)

    $valid =
        (Test-Token $id 64) -and
        (Test-Token $game 32) -and
        ($name.Length -ge 1 -and $name.Length -le 48) -and
        ($classification -cin @('official', 'community-public', 'coop')) -and
        (Test-Host $serverHost) -and
        ($port -ge 1 -and $port -le 65535) -and
        ($capacity -ge 1 -and $capacity -le 64) -and
        ($region.Length -le 24) -and
        ($notes.Length -le 64) -and
        ($owner.Length -le 48)

    if (-not $valid) { $dropped += 1; continue }
    if ($rows | Where-Object { $_.id -ceq $id }) { $dropped += 1; continue }

    $rows += [pscustomobject]@{
        id = $id
        game = $game
        name = $name
        classification = $classification
        host = $serverHost
        port = $port
        capacity = $capacity
        region = $region
        notes = $notes
        password = [bool]$server.password
        owner = $owner
    }
}

# ---- normalise ---------------------------------------------------------------
$generated = 0L
[void][int64]::TryParse([string]$document.generated, [ref]$generated)

$builder = New-Object System.Text.StringBuilder
[void]$builder.AppendLine('; GENERATED FILE -- do not edit.')
[void]$builder.AppendLine('; Written by Get-CrossroadsDirectory.ps1 from the published directory.')
[void]$builder.AppendLine('; Discovery only. No field here describes whether a server is up, how many')
[void]$builder.AppendLine('; players it has, or how far away it is -- the launcher measures that itself.')
[void]$builder.AppendLine('')
[void]$builder.AppendLine('[directory]')
[void]$builder.AppendLine("contract=crossroads-directory-v1")
[void]$builder.AppendLine("generated=$generated")
[void]$builder.AppendLine("fetched=$([DateTime]::UtcNow.ToString('yyyyMMddHHmm'))")
[void]$builder.AppendLine("count=$($rows.Count)")
[void]$builder.AppendLine("dropped=$dropped")
[void]$builder.AppendLine('')

for ($index = 0; $index -lt $rows.Count; $index++) {
    $row = $rows[$index]
    [void]$builder.AppendLine("[server.$index]")
    [void]$builder.AppendLine("id=$($row.id)")
    [void]$builder.AppendLine("game=$($row.game)")
    [void]$builder.AppendLine("name=$($row.name)")
    [void]$builder.AppendLine("classification=$($row.classification)")
    [void]$builder.AppendLine("host=$($row.host)")
    [void]$builder.AppendLine("port=$($row.port)")
    [void]$builder.AppendLine("capacity=$($row.capacity)")
    [void]$builder.AppendLine("region=$($row.region)")
    [void]$builder.AppendLine("notes=$($row.notes)")
    [void]$builder.AppendLine("password=$(if ($row.password) { 1 } else { 0 })")
    [void]$builder.AppendLine("owner=$($row.owner)")
    [void]$builder.AppendLine('')
}

# Written whole, then moved into place, so the launcher never reads a half-
# written cache.
$temporary = "$OutputPath.new"
[IO.File]::WriteAllText($temporary, $builder.ToString(), [Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $temporary -Destination $OutputPath -Force

Write-DirectoryLog ("Directory cached: $($rows.Count) server(s), $dropped dropped.")
Write-Host "Directory cached: $($rows.Count) server(s), $dropped dropped."
exit 0
