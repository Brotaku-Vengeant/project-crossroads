# Signs the player in with Discord and stores the account token the registration
# heartbeat will carry.
#
# WHY POWERSHELL DOES THIS AND THE LAUNCHER DOES NOT.
#
# Same rule as Get-CrossroadsDirectory.ps1, for the same reason. The OAuth
# callback arrives over a socket that ANY local process and ANY web page the
# player visits can reach, so it is attacker-reachable by construction. Parsing
# it in the launcher would mean hand-written C++ HTTP parsing of hostile bytes on
# players' machines. It happens here instead, in a memory-safe language, and the
# launcher only ever reads a bounded local INI its own tool wrote.
#
# The launcher has no HTTP client and this does not give it one.
#
# THE PASSWORD LINE, from docs\launcher\ACCOUNTS_AND_REGISTRATION.md: the
# launcher must never render a password field and must never see a password.
# Nothing here collects one. The player authorises inside Discord's own
# interface, in their own browser, and what comes back is a single-use code.
#
# THE CLIENT SECRET IS NOT HERE AND MUST NEVER BE. This script sends the code to
# the Crossroads directory service, which holds the secret and performs the
# exchange. A secret baked into a distributed launcher is a published secret.
#
# Exit codes, because the launcher branches on them:
#   0  signed in, token written
#   1  accounts are not configured (no client id / service url) -- NOT an error
#   2  the loopback port is already in use
#   3  timed out, or the player closed the browser without authorising
#   4  the callback failed its state check and was REFUSED
#   5  the service would not exchange the code
#   6  signed out (with -SignOut)

[CmdletBinding()]
param(
    # Overrides the configured service base. HTTPS is required except on
    # loopback -- see the scheme check below for why loopback is exempt.
    [string]$ServiceUrl = '',

    [string]$ClientId = '',

    # 53682 IS NOT AN ARBITRARY DEFAULT. It is the port inside the redirect URI
    # registered with the Discord application (services\directory\README.md), and
    # Discord matches the redirect URI EXACTLY. Production cannot use another
    # port, and falling back to a free one would produce a sign-in that always
    # fails with an error from Discord rather than from us. Parameterised only so
    # the gate can run cases in parallel without fighting over one port.
    [ValidateRange(1024, 65535)]
    [int]$Port = 53682,

    # Where the token lands. Default is the per-user profile directory: never
    # beside the executable, never inside the repository.
    [string]$AccountPath = '',

    [ValidateRange(5, 900)]
    [int]$TimeoutSeconds = 300,

    # The gate drives the callback itself, so it must be able to stop this from
    # launching a real browser on the build machine.
    [switch]$NoBrowser,

    # Prints the authorize URL and exits. Lets the gate assert what would have
    # been opened without opening it.
    [switch]$ShowUrlOnly,

    [switch]$SignOut
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

# PowerShell 5.1 still negotiates TLS 1.0 by default on some hosts, and Discord
# and any modern reverse proxy refuse it. Set before the first HTTPS call or the
# exchange fails with a connection reset that reads like an outage.
try {
    [Net.ServicePointManager]::SecurityProtocol =
        [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11
}
catch { }

function Read-IniValue([string]$path, [string]$section, [string]$key) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return '' }
    $current = ''
    foreach ($line in (Get-Content -LiteralPath $path)) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') { $current = $Matches[1]; continue }
        if ($current -eq $section -and
            $trimmed -match ('^' + [regex]::Escape($key) + '\s*=(.*)$')) {
            return $Matches[1].Trim()
        }
    }
    return ''
}

if ([string]::IsNullOrWhiteSpace($AccountPath)) {
    $localAppData = $env:LOCALAPPDATA
    if ([string]::IsNullOrWhiteSpace($localAppData)) {
        # No profile directory means no safe place for a token. Refusing beats
        # writing it beside the executable, which is a shared directory in a
        # managed install.
        Write-Host 'No per-user profile directory is available, so no token can be stored safely.'
        exit 1
    }
    $AccountPath = Join-Path $localAppData 'Project Crossroads\account.ini'
}

# The log lives beside the ACCOUNT FILE for the reason the directory log lives
# beside its cache: under test that is a temporary directory, so a gate run
# leaves nothing in tracked source.
$logPath = Join-Path (Split-Path -Parent $AccountPath) 'account-log.txt'

# WHAT THIS LOG MUST NEVER CONTAIN: the authorization code, the account token,
# or the state value. The code is a credential for the length of its life, the
# token is one for its whole life, and a log is the easiest file on a machine to
# hand to somebody while asking for help. Callers pass descriptions, never
# values.
function Write-AccountLog([string]$message) {
    $line = '{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $message
    try {
        New-Item -ItemType Directory -Force `
            -Path (Split-Path -Parent $logPath) | Out-Null
        Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
    }
    catch { }
}

if ($SignOut) {
    if (Test-Path -LiteralPath $AccountPath -PathType Leaf) {
        Remove-Item -LiteralPath $AccountPath -Force
        Write-AccountLog 'Signed out; the stored token was deleted.'
        Write-Host 'Signed out of Crossroads. The stored token was deleted.'
    }
    else {
        Write-Host 'Not signed in; there was nothing to delete.'
    }
    exit 6
}

# --- configuration -----------------------------------------------------------
# ABSENT CONFIGURATION IS NOT AN ERROR, and this is what hides the feature.
#
# Until an always-on host with a hostname and TLS exists, there is nowhere for
# the exchange to happen. The launcher reads the same two keys and shows no
# sign-in button when either is missing, so an unconfigured install has no
# visible half-built feature and no support burden.
if ([string]::IsNullOrWhiteSpace($ClientId)) {
    $ClientId = Read-IniValue (Join-Path $root 'crossroads-network.ini') 'accounts' 'client_id'
}
if ([string]::IsNullOrWhiteSpace($ServiceUrl)) {
    $ServiceUrl = Read-IniValue (Join-Path $root 'crossroads-network.ini') 'accounts' 'service_url'
}
if ([string]::IsNullOrWhiteSpace($ClientId) -or [string]::IsNullOrWhiteSpace($ServiceUrl)) {
    Write-AccountLog 'Accounts are not configured; sign-in is unavailable.'
    Write-Host 'Crossroads accounts are not configured on this install, so sign-in is unavailable.'
    exit 1
}

# The client id travels in a URL we build. Anything outside this shape is either
# a typo or an attempt to inject extra query parameters into the authorize URL.
if ($ClientId -notmatch '^[0-9]{5,32}$') {
    Write-AccountLog 'The configured client id is not a plain numeric id; refusing.'
    Write-Host 'The configured Discord client id is not valid, so sign-in was cancelled.'
    exit 1
}

$serviceUri = $null
if (-not [Uri]::TryCreate($ServiceUrl.TrimEnd('/'), [UriKind]::Absolute, [ref]$serviceUri)) {
    Write-AccountLog 'The configured service url is not an absolute URI; refusing.'
    Write-Host 'The configured Crossroads account service address is not valid.'
    exit 1
}

# HTTPS OR LOOPBACK, NOTHING ELSE.
#
# The exchange request carries the authorization code, and the response carries
# the account token. Over plain http on a real network both are readable by
# anyone on the path, so this refuses it -- the same rule the directory fetcher
# applies to the document it downloads.
#
# LOOPBACK IS EXEMPT DELIBERATELY, and it is not a weakening: traffic to
# 127.0.0.1 never reaches a network interface, and the development service
# refuses to bind anything but loopback while it is using the identity stub. It
# is what makes this whole flow testable before a host exists.
$isLoopbackService = $serviceUri.IsLoopback
if ($serviceUri.Scheme -ne 'https' -and -not $isLoopbackService) {
    Write-AccountLog 'The configured service url is not https and is not loopback; refusing.'
    Write-Host 'The Crossroads account service must be reached over HTTPS. Sign-in was cancelled.'
    exit 1
}
if ($serviceUri.Scheme -notin @('http', 'https')) {
    Write-AccountLog 'The configured service url is not http(s); refusing.'
    Write-Host 'The Crossroads account service address must be an http or https URL.'
    exit 1
}

# --- the state value ---------------------------------------------------------
# THIS IS THE CSRF DEFENCE AND IT IS LOAD-BEARING.
#
# The callback listener answers anything that connects to it, which includes a
# page in the player's browser while they are on some other site. Without a
# state check, that page can call
# 127.0.0.1:53682/discord/callback?code=<attacker's code> and this script would
# exchange it and store somebody else's token -- signing the player into an
# account the attacker controls, under which servers then get registered in the
# player's name. The state is generated here, sent to Discord, and required to
# come back unchanged.
#
# RandomNumberGenerator, not Get-Random: Get-Random is a seeded PRNG and is not
# suitable for anything an attacker would want to predict.
$stateBytes = New-Object byte[] 32
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($stateBytes) } finally { $rng.Dispose() }
$state = -join ($stateBytes | ForEach-Object { $_.ToString('x2') })

$redirectUri = 'http://127.0.0.1:' + $Port + '/discord/callback'
$authorizeUrl =
    'https://discord.com/api/oauth2/authorize' +
    '?client_id=' + [Uri]::EscapeDataString($ClientId) +
    '&redirect_uri=' + [Uri]::EscapeDataString($redirectUri) +
    '&response_type=code' +
    # `identify` AND NOTHING ELSE. It yields the id and display name, which is
    # the entire contract (ACCOUNTS_AND_REGISTRATION.md: no personal data beyond
    # a Discord id and display name). Asking for email or guilds would widen
    # what a compromise of the service exposes for no feature.
    '&scope=identify' +
    '&state=' + $state

if ($ShowUrlOnly) {
    Write-Output $authorizeUrl
    exit 0
}

# --- the loopback listener ---------------------------------------------------
# TcpListener RATHER THAN HttpListener, deliberately.
#
# HttpListener needs a URL reservation for a specific-IP prefix, so
# http://127.0.0.1:53682/ fails for a non-administrator with a bare
# "Access is denied" -- and the one prefix that does not, http://localhost:,
# does not match the registered redirect URI. A raw socket also lets the byte
# caps below be real rather than trusted to a framework.
$listener = New-Object System.Net.Sockets.TcpListener(
    [System.Net.IPAddress]::Loopback, $Port)
try {
    $listener.Start()
}
catch {
    Write-AccountLog ('The callback port ' + $Port + ' is already in use; sign-in cannot start.')
    Write-Host ("Port $Port is already in use, so Crossroads cannot receive the Discord sign-in.") -ForegroundColor Yellow
    Write-Host 'Close whatever is using it and try again. Crossroads cannot use a different port,'
    Write-Host 'because the one it listens on is registered with Discord and has to match.'
    exit 2
}

# Bounds on a request nobody trustworthy necessarily sent. The real callback is
# a GET with no body, a few hundred bytes at most; these are generous by an
# order of magnitude and still refuse a socket that just keeps talking.
$maximumRequestBytes = 16384
$maximumHeaderLines = 64

function Read-CallbackRequest($client) {
    # Returns the request target ("/discord/callback?code=...") or $null.
    $stream = $client.GetStream()
    $stream.ReadTimeout = 5000
    $buffer = New-Object byte[] 2048
    $text = New-Object System.Text.StringBuilder
    $total = 0
    while ($true) {
        $read = 0
        try { $read = $stream.Read($buffer, 0, $buffer.Length) }
        catch { return $null }          # timeout or reset: not our callback
        if ($read -le 0) { break }
        $total += $read
        if ($total -gt $maximumRequestBytes) { return $null }
        [void]$text.Append(
            [System.Text.Encoding]::ASCII.GetString($buffer, 0, $read))
        $current = $text.ToString()
        # Headers end at a blank line. A GET has no body, so that is the whole
        # request and there is no reason to keep reading.
        if ($current.Contains("`r`n`r`n") -or $current.Contains("`n`n")) { break }
        if (($current -split "`n").Count -gt $maximumHeaderLines) { return $null }
    }
    $requestText = $text.ToString()
    $firstLine = ($requestText -split "`r?`n")[0]
    if ([string]::IsNullOrWhiteSpace($firstLine)) { return $null }
    $parts = $firstLine -split ' '
    if ($parts.Count -lt 2) { return $null }
    if ($parts[0] -ne 'GET') { return $null }
    return $parts[1]
}

# Parsed here rather than with System.Web.HttpUtility, which is not loaded in a
# default PowerShell 5.1 session -- reaching for it would make sign-in fail on a
# player's machine with a type-not-found error. Only three keys are ever read and
# a duplicate key is taken as the FIRST occurrence, so a callback carrying
# `state=good&state=bad` cannot smuggle a second value past the check below.
function Get-QueryValues([string]$query) {
    $values = @{}
    if ([string]::IsNullOrEmpty($query)) { return $values }
    foreach ($pair in ($query.TrimStart('?') -split '&')) {
        if ([string]::IsNullOrEmpty($pair)) { continue }
        $split = $pair.IndexOf('=')
        if ($split -lt 1) { continue }
        $name = [Uri]::UnescapeDataString($pair.Substring(0, $split))
        $value = [Uri]::UnescapeDataString($pair.Substring($split + 1))
        if (-not $values.ContainsKey($name)) { $values[$name] = $value }
    }
    return $values
}

function Send-CallbackResponse($client, [int]$status, [string]$statusText, [string]$bodyText) {
    $body = [System.Text.Encoding]::UTF8.GetBytes(
        "<!doctype html><meta charset=`"utf-8`"><title>Project Crossroads</title>" +
        "<body style=`"font-family:Segoe UI,sans-serif;padding:2rem`"><p>" +
        $bodyText + '</p></body>')
    $header = [System.Text.Encoding]::ASCII.GetBytes(
        "HTTP/1.1 $status $statusText`r`n" +
        "Content-Type: text/html; charset=utf-8`r`n" +
        "Content-Length: $($body.Length)`r`n" +
        "Cache-Control: no-store`r`n" +
        "Connection: close`r`n`r`n")
    try {
        $stream = $client.GetStream()
        $stream.Write($header, 0, $header.Length)
        $stream.Write($body, 0, $body.Length)
        $stream.Flush()
    }
    catch { }
}

if (-not $NoBrowser) {
    Write-Host 'Opening your browser to sign in with Discord...'
    Write-Host 'Crossroads never sees your password. You authorise inside Discord itself.'
    try { Start-Process $authorizeUrl | Out-Null }
    catch {
        Write-AccountLog 'Could not open a browser for the authorize URL.'
        Write-Host 'Crossroads could not open your browser. Sign-in was cancelled.' -ForegroundColor Yellow
        $listener.Stop()
        exit 3
    }
}
else {
    # -NoBrowser PRINTS THE URL, and the state inside it, on purpose.
    #
    # Nothing opened a browser, so the only way to finish the flow is for
    # whoever asked for this mode to visit the URL themselves -- a person
    # debugging by hand, or the gate driving the callback. It is stdout of a
    # process they started and not the log file, which still never carries the
    # state; and the value is useless once the listener below stops.
    Write-Output $authorizeUrl
}
Write-AccountLog 'Waiting for the Discord callback on loopback.'

$deadline = (Get-Date).AddSeconds($TimeoutSeconds)
$code = ''
$outcome = 'timeout'
try {
    while ((Get-Date) -lt $deadline) {
        if (-not $listener.Pending()) { Start-Sleep -Milliseconds 200; continue }
        $client = $listener.AcceptTcpClient()
        try {
            $target = Read-CallbackRequest $client
            if ($null -eq $target) {
                Send-CallbackResponse $client 400 'Bad Request' 'Bad request.'
                continue
            }
            $uri = $null
            [void][Uri]::TryCreate(
                'http://127.0.0.1' + $target, [UriKind]::Absolute, [ref]$uri)
            if ($null -eq $uri -or $uri.AbsolutePath -ne '/discord/callback') {
                # Browsers ask for /favicon.ico and anything else on the machine
                # may knock. Answer and keep waiting rather than treating the
                # first stray connection as a failed sign-in.
                Send-CallbackResponse $client 404 'Not Found' 'Not found.'
                continue
            }
            $query = Get-QueryValues $uri.Query
            $returnedState = [string]$query['state']
            $returnedCode = [string]$query['code']
            $returnedError = [string]$query['error']

            # THE STATE CHECK, before anything else is believed.
            #
            # Compared with a fixed-time comparison so the answer does not leak
            # how much of the value was right. The cost is nothing and the
            # alternative is a habit that is wrong somewhere it matters more.
            $stateOk = $false
            if (-not [string]::IsNullOrEmpty($returnedState) -and
                $returnedState.Length -eq $state.Length) {
                $difference = 0
                for ($i = 0; $i -lt $state.Length; $i++) {
                    $difference = $difference -bor
                        ([int][char]$state[$i] -bxor [int][char]$returnedState[$i])
                }
                $stateOk = ($difference -eq 0)
            }
            if (-not $stateOk) {
                Send-CallbackResponse $client 400 'Bad Request' `
                    'This sign-in did not come from Project Crossroads and was refused.'
                Write-AccountLog 'A callback arrived with a missing or wrong state value and was REFUSED.'
                $outcome = 'state'
                break
            }
            if (-not [string]::IsNullOrEmpty($returnedError)) {
                Send-CallbackResponse $client 200 'OK' `
                    'Sign-in was cancelled. You can close this tab.'
                Write-AccountLog 'Discord reported the authorisation was declined or failed.'
                $outcome = 'declined'
                break
            }
            # A code is a credential; its SHAPE is checked, its value is never
            # logged. Discord issues short alphanumeric codes.
            if ($returnedCode -notmatch '^[A-Za-z0-9._~-]{8,512}$') {
                Send-CallbackResponse $client 400 'Bad Request' `
                    'The sign-in reply was malformed and was refused.'
                Write-AccountLog 'The callback carried no usable authorization code.'
                $outcome = 'declined'
                break
            }
            Send-CallbackResponse $client 200 'OK' `
                'Signed in. You can close this tab and return to Project Crossroads.'
            $code = $returnedCode
            $outcome = 'code'
            break
        }
        finally {
            $client.Close()
        }
    }
}
finally {
    # One callback and the door closes. Leaving it open would keep an
    # attacker-reachable socket alive for the rest of the session.
    $listener.Stop()
}

switch ($outcome) {
    'timeout' {
        Write-AccountLog 'Sign-in timed out with no callback.'
        Write-Host 'Sign-in timed out. Nothing was changed.' -ForegroundColor Yellow
        exit 3
    }
    'declined' {
        Write-Host 'Sign-in was cancelled. Nothing was changed.' -ForegroundColor Yellow
        exit 3
    }
    'state' {
        Write-Host 'A sign-in reply arrived that Crossroads did not ask for, so it was refused.' -ForegroundColor Red
        Write-Host 'Nothing was changed. This is the expected result if a web page tried to sign you in.'
        exit 4
    }
}

# --- the exchange ------------------------------------------------------------
# The code goes to the Crossroads service, never to Discord from here: the
# service is the only party holding the client secret.
$exchangeUrl = $serviceUri.AbsoluteUri.TrimEnd('/') + '/auth/exchange'
Write-AccountLog 'Handing the code to the account service for exchange.'
$response = $null
try {
    $response = Invoke-RestMethod -Uri $exchangeUrl -Method Post `
        -ContentType 'application/json' -TimeoutSec 30 -UseBasicParsing `
        -Body (@{ code = $code; redirectUri = $redirectUri } |
            ConvertTo-Json -Compress)
}
catch {
    # The message is logged; the code is not, and the exception can carry a
    # response body, so only the status line is taken from it.
    Write-AccountLog ('The account service refused the exchange: ' +
        $_.Exception.Message)
    Write-Host 'Crossroads could not complete the sign-in. Nothing was changed.' -ForegroundColor Yellow
    exit 5
}
finally {
    $code = ''
}

$token = ''
$displayName = ''
if ($null -ne $response) {
    $token = [string]$response.accountToken
    $displayName = [string]$response.displayName
}
if ([string]::IsNullOrWhiteSpace($token)) {
    Write-AccountLog 'The account service returned no token.'
    Write-Host 'Crossroads could not complete the sign-in. Nothing was changed.' -ForegroundColor Yellow
    exit 5
}
# The token is opaque to us but it is about to be written into an INI the
# launcher parses, so its shape is checked rather than assumed. Anything with a
# newline in it could add a line to that file.
if ($token -notmatch '^[A-Za-z0-9._~+/=-]{8,512}$') {
    Write-AccountLog 'The account service returned a token of an unexpected shape; refusing to store it.'
    Write-Host 'Crossroads could not complete the sign-in. Nothing was changed.' -ForegroundColor Yellow
    exit 5
}

# THE DISPLAY NAME IS ATTACKER-CONTROLLED TEXT. Anyone can set their own Discord
# display name, and it lands in a file the launcher reads and draws. Control
# characters are the vector that matters: a CR or LF would let a name add a line
# to this INI -- the same defect the directory fetcher exists to prevent -- so
# they are stripped at the point the value ENTERS the file rather than trusted to
# be handled later. Capped at 48 to match the registration contract.
$cleanName = ''
foreach ($character in $displayName.ToCharArray()) {
    if ([int][char]$character -ge 32 -and [int][char]$character -ne 127) {
        $cleanName += $character
    }
}
$cleanName = $cleanName.Trim()
if ($cleanName.Length -gt 48) { $cleanName = $cleanName.Substring(0, 48) }
if ([string]::IsNullOrWhiteSpace($cleanName)) { $cleanName = 'Crossroads Player' }

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $AccountPath) | Out-Null
$lines = @(
    '; Written by Sign-InToCrossroads.ps1. Do not edit by hand.',
    '; This file holds a credential. It is per-user and is deleted by sign-out.',
    '[account]',
    ('displayName=' + $cleanName),
    ('token=' + $token),
    ('signedInAt=' + (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))
)
# WRITTEN WITHOUT A BYTE-ORDER MARK, and this is not a style preference.
#
# The launcher reads this file with GetPrivateProfileStringW, which does not
# understand a UTF-8 BOM: the first section header comes back as garbage and
# every lookup returns empty. `Set-Content -Encoding UTF8` under PowerShell 5.1
# writes one, so using it here produced a launcher that reported NOT SIGNED IN
# after a completely successful sign-in -- measured 2026-08-12, and the reason
# Test-AccountSignIn.ps1 now drives the real launcher against this exact file
# instead of trusting that two programs agree about it.
#
# Every other Crossroads INI is BOM-less for the same reason; config\crossroads-
# network.ini starts with a bare '['.
[IO.File]::WriteAllText($AccountPath,
    (($lines -join "`r`n") + "`r`n"),
    (New-Object Text.UTF8Encoding($false)))

Write-AccountLog ('Signed in as ' + $cleanName + '.')
Write-Host ''
Write-Host ('Signed in to Crossroads as ' + $cleanName + '.') -ForegroundColor Green
Write-Host 'Crossroads stored a token and your display name. It never saw your password.'
exit 0
