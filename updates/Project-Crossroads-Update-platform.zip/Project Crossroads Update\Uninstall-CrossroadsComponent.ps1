[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Component,

    # A game's own teardown, for the files that are NOT updater-managed.
    # KotOR installs a proxy DLL and Override scripts into the GAME directory,
    # which this script has no business knowing about -- Join-Crossroads-KotOR.ps1
    # put them there and Uninstall-KSE.ps1 takes them back out. The adapter
    # supplies the path; this script just runs it first.
    [string]$GameTeardown = '',

    [switch]$Force
)

<#
.SYNOPSIS
    Remove one game's Crossroads component: its updater-managed files, and
    optionally the changes that game made inside its own installation.

.DESCRIPTION
    REMOVES EXACTLY WHAT WAS INSTALLED, FROM A RECORD, NEVER BY PATTERN.
    .crossroads-components\<id>.json lists the precise files that component
    wrote, which is the entire reason stage 2 records the file list rather than
    just a build number. A pattern would be wrong in both directions here:
    Fallout's managed files are NOT under a components\fallout3\ prefix -- they
    sit loose at components\ root and in profiles\ -- so a prefix sweep would
    both miss them and, if widened, delete files belonging to the platform or to
    another game.

    ORDER IS DELIBERATE. The game's own teardown runs FIRST, while the component
    is still present, because a teardown may need the very files this is about to
    remove: Uninstall-KSE.ps1 restores a retail binkw32.dll that the KotOR
    component is what delivered. Removing the component first would leave a game
    permanently modified with the tool that fixes it already deleted.

    THE RECORD IS DELETED LAST. If this is interrupted, the record still
    describes what is on disk, so running it again finishes the job. Deleting the
    record first would strand the remaining files with nothing left that knows
    they exist -- unowned, and invisible to every check.
#>

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$componentStateRoot = Join-Path $root '.crossroads-components'
$statePath = Join-Path $componentStateRoot ($Component + '.json')
$logPath = Join-Path $root 'updater-log.txt'

function Write-UninstallLog([string]$message) {
    $line = '{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $message
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

# Same guard the installer uses. A record is not a trusted input just because we
# wrote it -- it is a file on a player's disk, and this deletes what it names.
function Test-SafeRelativePath([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path) -or
        [IO.Path]::IsPathRooted($path) -or
        $path.Contains('..') -or
        $path.Contains(':')) {
        return $false
    }
    $normalized = $path.Replace('/', '\').TrimStart('\')
    return -not ($normalized -ieq 'runtime' -or
        $normalized.StartsWith('runtime\', [StringComparison]::OrdinalIgnoreCase) -or
        $normalized -ieq 'startup-log.txt' -or
        $normalized -ieq 'diagnostic-report.txt' -or
        # network-room-code.txt was here until 2026-08-15. It held a Fallout
        # join code written by the retired safe launcher; join codes are gone,
        # nothing writes the file, and a name kept in this list is a name that
        # cannot be uninstalled.
        $normalized -ieq 'updater-log.txt')
}

if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) {
    Write-Host "Component '$Component' is not installed; nothing to remove."
    exit 0
}

$state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
$declared = @($state.files)
if ($declared.Count -eq 0) {
    throw ("The record for '$Component' lists no files. Refusing to act on it " +
           'rather than guessing what it owns.')
}

# A record naming a different component means the state directory has been
# tampered with or hand-edited. Refuse: the whole safety of this script rests on
# the record describing the component it is named for.
if ($state.component -and ([string]$state.component) -ine $Component) {
    throw ("The record at $statePath declares component " +
           "'$($state.component)' but is named '$Component'. Refusing.")
}

foreach ($relative in $declared) {
    if (-not (Test-SafeRelativePath ([string]$relative))) {
        throw ("The record for '$Component' contains an unsafe or protected " +
               "path: $relative. Nothing was removed.")
    }
}

if (-not $Force) {
    Add-Type -AssemblyName PresentationFramework
    $answer = [System.Windows.MessageBox]::Show(
        ("Remove Crossroads files for '$Component'?`n`n" +
         "$($declared.Count) file(s) installed by Crossroads will be deleted." +
         $(if ($GameTeardown -ne '') {
             "`n`nChanges Crossroads made inside the game itself will also be undone."
           } else { '' }) +
         "`n`nYour game and your saves are not touched."),
        'Project: Crossroads - Remove Game Files',
        'YesNo',
        'Warning')
    if ($answer -ne 'Yes') {
        Write-Host 'Cancelled.'
        exit 0
    }
}

# ---- 1. the game's own teardown, while the component is still present -------
if ($GameTeardown -ne '') {
    if (-not (Test-Path -LiteralPath $GameTeardown -PathType Leaf)) {
        throw "The game teardown script is missing: $GameTeardown"
    }
    Write-UninstallLog "Component '$Component': running game teardown $GameTeardown"
    & $GameTeardown
    if ($LASTEXITCODE -ne 0 -and $null -ne $LASTEXITCODE) {
        throw ("The game's own uninstall step failed, so the Crossroads files " +
               'were left in place. Nothing was removed.')
    }
}

# ---- 2. the updater-managed files ------------------------------------------
$removed = 0
$absent = 0
foreach ($relative in $declared) {
    $target = Join-Path $root (([string]$relative).Replace('/', '\'))
    if (Test-Path -LiteralPath $target -PathType Leaf) {
        Remove-Item -LiteralPath $target -Force
        $removed++
    }
    else {
        $absent++
    }
}

# Prune directories this component emptied, deepest first so a parent is only
# considered after its children are gone. Only ever removes directories that are
# ALREADY empty, so a directory shared with another component survives.
$directories = $declared |
    ForEach-Object { Split-Path -Parent (Join-Path $root (([string]$_).Replace('/', '\'))) } |
    Sort-Object -Unique |
    Sort-Object { $_.Length } -Descending
foreach ($directory in $directories) {
    while ($directory -and
           $directory.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) -and
           -not ($directory -ieq $root) -and
           (Test-Path -LiteralPath $directory -PathType Container) -and
           @(Get-ChildItem -LiteralPath $directory -Force).Count -eq 0) {
        Remove-Item -LiteralPath $directory -Force
        $directory = Split-Path -Parent $directory
    }
}

# ---- 3. the record, last ----------------------------------------------------
Remove-Item -LiteralPath $statePath -Force

Write-UninstallLog ("Component '$Component' removed: $removed file(s) deleted, " +
    "$absent already absent.")
Write-Host "Removed component '$Component': $removed file(s) deleted, $absent already absent."
exit 0
