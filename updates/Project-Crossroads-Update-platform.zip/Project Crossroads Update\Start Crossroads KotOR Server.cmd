@echo off
title Project: Crossroads - KotOR Test Server
"%~dp0CrossroadsKotorServer.exe"
echo.
echo The Crossroads KotOR server has stopped.
pause
