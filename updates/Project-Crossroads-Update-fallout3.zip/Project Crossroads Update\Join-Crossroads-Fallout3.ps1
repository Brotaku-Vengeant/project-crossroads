# Join a Crossroads Fallout 3 server.
#
# This is the fallout3 component's CLIENT, in the same sense that
# Join-Crossroads-KotOR.ps1 is kotor1's: the launcher finds it beside itself,
# hands it a server, and it does everything between that and the player being in
# a multiplayer game.
#
#   1. check the install is the build this lane's addresses were read out of
#   2. install the stand-in plugin, reversibly, backing up the load order first
#   3. launch Fallout 3 with the Crossroads client injected, pointed at the
#      server the launcher chose
#
# ---------------------------------------------------------------------------
# WHAT IT DELIBERATELY DOES NOT DO
# ---------------------------------------------------------------------------
#
# IT READS NOTHING ABOUT THE PLAYER'S CHARACTER. Not here, not at launch, not at
# the main menu. That is the fault that reset this project's sync work once
# already (D58): identity was read from a save file on disk before the player
# had started playing, so the character replicated to everyone was never the one
# they chose. The client cannot do it either -- a snapshot requires a live cell,
# and a player at the main menu has none.
#
# IT WRITES NO SERVER ADDRESS TO DISK. The destination travels as arguments and
# lives exactly as long as the process does, so a player who joins somebody's
# server once does not silently repoint their own configuration. Same rule the
# KotOR join script follows, for the same reason.
#
# IT DOES NOT TOUCH RETAIL FILES. One plugin is copied into Data and one line is
# added to the load order, after backing that file up with a timestamp.
# Uninstall-Crossroads-Fallout3.ps1 is the deliberate reversal and it is the
# player's to run.

[CmdletBinding()]
param(
    # Where the server is. Supplied by the launcher from the row the player
    # picked; there is no default and no fallback, because a join with nowhere
    # to go should say so rather than guess.
    [Parameter(Mandatory = $true)]
    [string]$ServerHost,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 65535)]
    [int]$ServerPort,

    # 0 is the correct default and is NOT an unset value: the relay defaults to
    # it and the hub starts with it. Register 58 is what a mismatch costs -- a
    # relay discarding every packet before the peer table while looking healthy
    # from every angle -- so this is printed on the way past rather than assumed.
    [UInt64]$ServerSession = 0,

    [string]$GameDirectory,

    # Diagnostics only. -NoLaunch does everything except start the game, which is
    # what a packaging test wants; -KeepConsole leaves the injector's window up.
    [switch]$NoLaunch,
    [switch]$KeepConsole
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

# WHERE THIS SCRIPT'S PAYLOAD LIVES, and it is two places on purpose.
#
# In a package, the launcher finds this script BESIDE ITSELF -- that is what
# FindFalloutTools looks for -- while the binaries it needs sit under
# components\fallout3\, where the updater manages them per component (D33).
# In this lane's own tree they are all in one build directory.
#
# Looking in both, in that order, means the same script runs in a real install
# and in a development build without a switch to get wrong. Failing to find a
# file is reported by name later, rather than being papered over here.
$payloadRoots = @(
    (Join-Path $here 'components\fallout3'),
    $here
)

function Resolve-Payload([string]$name) {
    foreach ($root in $payloadRoots) {
        $candidate = Join-Path $root $name
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    return $null
}

function Write-Step([string]$text) {
    Write-Host ("== {0}" -f $text) -ForegroundColor Cyan
}
function Write-Detail([string]$text) {
    Write-Host ("   {0}" -f $text) -ForegroundColor DarkGray
}

# --- 1. find the game -------------------------------------------------------
if (-not $GameDirectory) {
    $GameDirectory = 'C:\Program Files (x86)\Steam\steamapps\common\Fallout 3 goty'
}
$gameExe = Join-Path $GameDirectory 'Fallout3.exe'
if (-not (Test-Path -LiteralPath $gameExe -PathType Leaf)) {
    throw "Fallout 3 was not found at $gameExe. Nothing has been changed."
}

# THE BUILD IS CHECKED HERE AS WELL AS IN THE CLIENT, and that is not
# duplication. The client refuses to call engine code on a build its addresses
# were not read out of -- correctly, silently, and after the game has already
# started. Checking it first means a player on the wrong build is told so
# before their game launches, instead of playing a session in which nothing
# works for a reason nothing on screen explains.
$bytes = [IO.File]::ReadAllBytes($gameExe)
$lfanew = [BitConverter]::ToInt32($bytes, 0x3C)
$timestamp = [BitConverter]::ToUInt32($bytes, $lfanew + 8)
$imageSize = [BitConverter]::ToUInt32($bytes, $lfanew + 0x50)
$expectedTimestamp = 0x60A80E56
$expectedImageSize = 0x0111F000
if ($timestamp -ne $expectedTimestamp -or $imageSize -ne $expectedImageSize) {
    throw (
        "This Fallout 3 is not the build Crossroads supports.`n" +
        ("  found:    timestamp 0x{0:X8}, image size 0x{1:X8}`n" -f $timestamp, $imageSize) +
        ("  expected: timestamp 0x{0:X8}, image size 0x{1:X8}`n" -f $expectedTimestamp, $expectedImageSize) +
        "Nothing has been changed. Crossroads currently supports the English Steam build only."
    )
}
Write-Step 'Fallout 3 install'
Write-Detail $GameDirectory
Write-Detail ("build 0x{0:X8} -- supported" -f $timestamp)

# --- 2. the stand-in plugin -------------------------------------------------
#
# WHY A PLUGIN IS NEEDED AT ALL. Other players are shown as actors this project
# authored, and creating an actor is a script function -- no function in the
# shipped binary has been identified and RTTI-confirmed for it, and this lane
# does not call functions it has not confirmed. The plugin's quest script does
# the spawning; the client tells it what to do by writing a global variable,
# which is a memory write rather than an engine call.
$plugin = 'ProjectCrossroadsStandInPool.esp'
$pluginSource = Resolve-Payload $plugin
if (-not $pluginSource) {
    throw "$plugin is missing from the Crossroads install. Restart the launcher to check for updates."
}

$dataDirectory = Join-Path $GameDirectory 'Data'
if (-not (Test-Path -LiteralPath $dataDirectory -PathType Container)) {
    throw "Fallout 3's Data folder is missing: $dataDirectory"
}
$pluginTarget = Join-Path $dataDirectory $plugin

$needsCopy = $true
if (Test-Path -LiteralPath $pluginTarget -PathType Leaf) {
    # COMPARED BY HASH, NOT BY PRESENCE. An older copy of this plugin left by a
    # previous build would be silently kept by a Test-Path check, and its script
    # is the half that changes.
    $existing = (Get-FileHash -LiteralPath $pluginTarget -Algorithm SHA256).Hash
    $incoming = (Get-FileHash -LiteralPath $pluginSource -Algorithm SHA256).Hash
    $needsCopy = $existing -ne $incoming
}

Write-Step 'Stand-in plugin'
if ($needsCopy) {
    Copy-Item -LiteralPath $pluginSource -Destination $pluginTarget -Force
    Write-Detail "installed $plugin"
} else {
    Write-Detail "$plugin is already current"
}

# The load order. Backed up before every edit, every time.
$loadOrder = Join-Path $env:LOCALAPPDATA 'Fallout3\plugins.txt'
if (-not (Test-Path -LiteralPath $loadOrder -PathType Leaf)) {
    throw (
        "Fallout 3's load order file was not found at $loadOrder.`n" +
        "Run Fallout 3 once on its own first, then try again. The plugin was copied and can be removed with Uninstall-Crossroads-Fallout3.ps1."
    )
}

$lines = @(Get-Content -LiteralPath $loadOrder)
if ($lines -notcontains $plugin) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    Copy-Item -LiteralPath $loadOrder -Destination "$loadOrder.$stamp.bak" -Force
    Add-Content -LiteralPath $loadOrder -Value $plugin -Encoding UTF8
    Write-Detail "enabled $plugin in the load order (backup: plugins.txt.$stamp.bak)"
} else {
    Write-Detail "$plugin is already enabled"
}

# --- 3. who we are on the wire ----------------------------------------------
#
# RANDOM PER LAUNCH, and it stopped being derived from the machine on
# 2026-08-21 because the owner found the hole in that within a minute of having
# it explained.
#
# It used to be a hash of COMPUTERNAME and USERNAME, on the reasoning that two
# machines would differ. Owner:
#
#   "if by some random happenstance two players decided to connect on PC's that
#    both somehow managed to be named 'BobsPC' they would have the same client
#    ID?"
#
# Yes. And it is not a far-fetched pairing -- plenty of Windows installs are a
# user called `User` on a PC called `Gaming-PC`. Two players colliding that way
# fight over a single row in the relay's table, and the symptom is a peer that
# flickers rather than anything that names the cause. The old scheme ALSO
# collided for two copies of the game on one machine, which is the case a
# developer hits first.
#
# Random from a cryptographic source fixes both, and stability was buying
# nothing: the id is an ASSERTION rather than a credential -- the relay has no
# authentication and says so in its own header -- so it cannot identify anybody
# across sessions no matter how stable it is. A peer that goes quiet ages out of
# the relay in five seconds, so a fresh id on every launch costs nothing either.
#
# It is PRINTED below, so a roster line can still be matched to the machine that
# produced it while a session is running.
$idBytes = New-Object byte[] 4
[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($idBytes)
$clientId = [BitConverter]::ToUInt32($idBytes, 0)
# 0 is not addressable and the protocol refuses it outright.
if ($clientId -eq 0) { $clientId = 1 }

foreach ($required in @('CrossroadsFallout3Client.dll', 'CrossroadsTickProbeHost.exe')) {
    if (-not (Resolve-Payload $required)) {
        throw "$required is missing from the Crossroads install. Restart the launcher to check for updates."
    }
}
$injector = Resolve-Payload 'CrossroadsTickProbeHost.exe'

# The injector resolves -dll BESIDE ITSELF, so the client must be found in the
# same directory the injector was -- not merely somewhere on the search path.
$clientDirectory = Split-Path -Parent $injector
if (-not (Test-Path -LiteralPath (Join-Path $clientDirectory 'CrossroadsFallout3Client.dll') -PathType Leaf)) {
    throw "CrossroadsFallout3Client.dll is not beside CrossroadsTickProbeHost.exe in $clientDirectory."
}

# THE STATUS FILE GOES BESIDE THE CLIENT, NOT INTO THE GAME FOLDER. It is the
# only thing that will explain a bad session, and writing diagnostics into
# somebody's Fallout install is how a game directory fills up with files nobody
# can attribute.
$statusPath = Join-Path $clientDirectory 'crossroads-fallout3-client.txt'

Write-Step 'Joining'
Write-Detail ("server:  {0}:{1}" -f $ServerHost, $ServerPort)
Write-Detail ("session: 0x{0:X16}" -f $ServerSession)
Write-Detail ("client:  {0}" -f $clientId)
Write-Detail ("status:  {0}" -f $statusPath)

if ($NoLaunch) {
    Write-Host 'NoLaunch: everything is installed and nothing was started.' -ForegroundColor Yellow
    return
}

$arguments = @(
    $gameExe,
    '-dll', 'CrossroadsFallout3Client.dll',
    '-status', $statusPath,
    '-statusvar', 'CROSSROADS_FO3_STATUS',
    '-env', ("CROSSROADS_FO3_HOST={0}" -f $ServerHost),
    '-env', ("CROSSROADS_FO3_PORT={0}" -f $ServerPort),
    '-env', ("CROSSROADS_FO3_SESSION={0}" -f $ServerSession),
    '-env', ("CROSSROADS_FO3_CLIENT={0}" -f $clientId),
    # ARMED, and this is the one place in this lane where that is the default.
    # A probe defaults to unarmed because its job is to measure; a player
    # pressing Join is asking for multiplayer, and a client that joins and moves
    # nobody is not a safer version of that -- it is a broken one.
    '-env', 'CROSSROADS_FO3_ARM=1'
)

& $injector @arguments
$exit = $LASTEXITCODE

if ($exit -ne 0) {
    Write-Host ''
    Write-Host ("The Crossroads client exited with code {0}." -f $exit) -ForegroundColor Red
    Write-Host ("Its status file says what it got as far as: {0}" -f $statusPath) -ForegroundColor Red
}

if ($KeepConsole) {
    Write-Host ''
    Read-Host 'Press Enter to close'
}

exit $exit
