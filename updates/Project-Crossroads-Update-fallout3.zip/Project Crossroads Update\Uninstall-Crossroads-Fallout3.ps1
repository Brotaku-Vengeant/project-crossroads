# Take Crossroads back out of Fallout 3.
#
# THE DELIBERATE REVERSAL, and it is the player's to run -- the same shape as
# Uninstall-KSE.ps1 on the KotOR side. Joining a server installs one plugin and
# adds one line to the load order; this removes both and nothing else.
#
# IT DOES NOT RESTORE A BACKUP of plugins.txt, on purpose. The join script backs
# that file up before every edit, but restoring one would also undo whatever the
# player did to their load order in between -- installing other mods, reordering
# things -- and silently reverting somebody's unrelated work is worse than the
# problem this solves. It removes our line and leaves theirs alone.
#
# WHAT IT CANNOT UNDO, stated plainly: stand-in bodies that were spawned during
# a session and saved into a save file. Those are references to this plugin, so
# removing the plugin makes them vanish rather than leaving them standing -- but
# a save written while they existed still carries the space they occupied. If
# that matters, the safe order is to load a save from before the session.

[CmdletBinding()]
param(
    [string]$GameDirectory = 'C:\Program Files (x86)\Steam\steamapps\common\Fallout 3 goty'
)

$ErrorActionPreference = 'Stop'

$plugin = 'ProjectCrossroadsStandInPool.esp'
$dataDirectory = Join-Path $GameDirectory 'Data'
$pluginPath = Join-Path $dataDirectory $plugin
$loadOrder = Join-Path $env:LOCALAPPDATA 'Fallout3\plugins.txt'

# NEVER TOUCH A SHIPPED MASTER, even if one is somehow named on the way in.
$retail = @('Fallout3.esm', 'Anchorage.esm', 'BrokenSteel.esm',
            'PointLookout.esm', 'ThePitt.esm', 'Zeta.esm')
if ($retail -contains $plugin) {
    throw "refusing to remove a retail file"
}

$removed = $false

if (Test-Path -LiteralPath $pluginPath -PathType Leaf) {
    Remove-Item -LiteralPath $pluginPath -Force
    Write-Host "removed $pluginPath" -ForegroundColor Green
    $removed = $true
} else {
    Write-Host "$plugin was not installed" -ForegroundColor DarkGray
}

if (Test-Path -LiteralPath $loadOrder -PathType Leaf) {
    $lines = @(Get-Content -LiteralPath $loadOrder)
    if ($lines -contains $plugin) {
        $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
        Copy-Item -LiteralPath $loadOrder -Destination "$loadOrder.$stamp.bak" -Force
        ($lines | Where-Object { $_ -ne $plugin }) |
            Set-Content -LiteralPath $loadOrder -Encoding UTF8
        Write-Host "removed $plugin from the load order (backup: plugins.txt.$stamp.bak)" `
            -ForegroundColor Green
        $removed = $true
    } else {
        Write-Host "$plugin was not in the load order" -ForegroundColor DarkGray
    }
}

Write-Host ''
if ($removed) {
    Write-Host 'Fallout 3 is back to what it was without Crossroads.' -ForegroundColor Green
} else {
    Write-Host 'Nothing to remove -- Crossroads was not installed here.' -ForegroundColor Yellow
}
